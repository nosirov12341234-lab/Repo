"""
Pips AI – Entry Point
Run: python main.py
"""
import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.redis import RedisStorage
from redis.asyncio import from_url as redis_from_url

from config.settings import settings
from models.models import build_engine, build_session_factory, create_all_tables

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def main():
    # DB setup
    engine = build_engine(settings.DATABASE_URL)
    session_factory = build_session_factory(engine)
    await create_all_tables(engine)

    # Redis
    redis = redis_from_url(settings.REDIS_URL, decode_responses=True)

    # Bot + Dispatcher
    storage = RedisStorage(redis=redis)
    bot = Bot(token=settings.BOT_TOKEN)
    dp = Dispatcher(storage=storage)

    # TODO: routers ni bu yerga ulash (keyingi bosqichlarda)
    # dp.include_router(user_router)
    # dp.include_router(admin_router)

    logger.info("Pips AI bot ishga tushdi...")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    asyncio.run(main())
