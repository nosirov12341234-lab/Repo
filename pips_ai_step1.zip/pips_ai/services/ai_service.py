"""
Pips AI – Gemini API Service
============================
• Key Pool  : cheksiz miqdordagi Gemini API kalitlarini boshqaradi
• Round-Robin: har bir so'rov uchun navbatdagi kalitni oladi (Redis atomik)
• 429 Guard  : rate-limited kalitni bloklaydi va zudlik bilan keyingisini ishlatadi
• Retry logic: max_retries=len(active_keys) ga teng, loop o'z-o'zidan to'xtaydi
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone, timedelta
from typing import AsyncGenerator, List, Optional

import redis.asyncio as aioredis
from google import genai
from google.genai import types as genai_types
from google.api_core.exceptions import ResourceExhausted, InvalidArgument
from sqlalchemy import select, update, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from models.models import GeminiKey, KeyStatus, ChatHistory, MessageRole

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

GEMINI_MODEL = "gemini-2.5-flash"
RATE_LIMIT_COOLDOWN_SECONDS = 60        # 429 alandan keyin ushlab turish muddati
EXHAUSTED_COOLDOWN_SECONDS = 3600       # Kunlik limit to'lganda ushlab turish
REDIS_COUNTER_KEY = "pips:gemini:rr_index"   # Round-robin pointer

# ---------------------------------------------------------------------------
# GeminiKeyPool
# ---------------------------------------------------------------------------

class GeminiKeyPool:
    """
    Thread-safe, async Gemini API key pool.

    Ishlatish tartibi:
        pool = GeminiKeyPool(session_factory, redis_client)
        await pool.initialize()
        response = await pool.generate(messages, system_prompt)
    """

    def __init__(
        self,
        session_factory: async_sessionmaker,
        redis: aioredis.Redis,
    ) -> None:
        self._session_factory = session_factory
        self._redis = redis

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _get_active_keys(self, session: AsyncSession) -> List[GeminiKey]:
        """DB'dan hozir ishlash mumkin bo'lgan kalitlarni qaytaradi."""
        now = datetime.now(timezone.utc)
        stmt = select(GeminiKey).where(
            or_(
                GeminiKey.status == KeyStatus.ACTIVE,
                and_(
                    GeminiKey.status == KeyStatus.RATE_LIMITED,
                    GeminiKey.rate_limited_until <= now,
                ),
            )
        ).order_by(GeminiKey.id)
        result = await session.execute(stmt)
        keys = result.scalars().all()

        # Rate-limit muddati o'tgan kalitlarni qayta faollashtir
        for k in keys:
            if k.status == KeyStatus.RATE_LIMITED and k.rate_limited_until and k.rate_limited_until <= now:
                k.status = KeyStatus.ACTIVE
                k.rate_limited_until = None
        await session.commit()
        return [k for k in keys if k.status == KeyStatus.ACTIVE]

    async def _pick_key(self, session: AsyncSession) -> Optional[GeminiKey]:
        """Round-Robin: Redis atomik counter yordamida navbatdagi kalitni tanlaydi."""
        active_keys = await self._get_active_keys(session)
        if not active_keys:
            return None

        count = len(active_keys)
        # INCR atomik – parallel requestlarda ham xavfsiz
        raw_index = await self._redis.incr(REDIS_COUNTER_KEY)
        chosen = active_keys[(raw_index - 1) % count]
        return chosen

    async def _mark_rate_limited(self, session: AsyncSession, key_id: int) -> None:
        """429 olgan kalitni vaqtincha bloklaydi."""
        until = datetime.now(timezone.utc) + timedelta(seconds=RATE_LIMIT_COOLDOWN_SECONDS)
        await session.execute(
            update(GeminiKey)
            .where(GeminiKey.id == key_id)
            .values(
                status=KeyStatus.RATE_LIMITED,
                rate_limited_until=until,
                error_count=GeminiKey.error_count + 1,
            )
        )
        await session.commit()
        logger.warning("GeminiKey id=%d rate-limited until %s", key_id, until.isoformat())

    async def _mark_exhausted(self, session: AsyncSession, key_id: int) -> None:
        """Kunlik kvota to'lgan kalitni bloklaydi."""
        until = datetime.now(timezone.utc) + timedelta(seconds=EXHAUSTED_COOLDOWN_SECONDS)
        await session.execute(
            update(GeminiKey)
            .where(GeminiKey.id == key_id)
            .values(
                status=KeyStatus.EXHAUSTED,
                rate_limited_until=until,
                error_count=GeminiKey.error_count + 1,
            )
        )
        await session.commit()
        logger.warning("GeminiKey id=%d daily quota exhausted. Blocked for 1h.", key_id)

    async def _mark_invalid(self, session: AsyncSession, key_id: int) -> None:
        """Yaroqsiz (o'chirilgan/noto'g'ri) kalitni doimiy bloklaydi."""
        await session.execute(
            update(GeminiKey)
            .where(GeminiKey.id == key_id)
            .values(status=KeyStatus.INVALID, error_count=GeminiKey.error_count + 1)
        )
        await session.commit()
        logger.error("GeminiKey id=%d marked INVALID.", key_id)

    async def _record_usage(self, session: AsyncSession, key_id: int) -> None:
        await session.execute(
            update(GeminiKey)
            .where(GeminiKey.id == key_id)
            .values(
                usage_count=GeminiKey.usage_count + 1,
                last_used_at=datetime.now(timezone.utc),
            )
        )
        await session.commit()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def generate(
        self,
        messages: List[dict],
        system_prompt: Optional[str] = None,
        max_retries: int = 10,
        temperature: float = 0.9,
    ) -> str:
        """
        AI javobini qaytaradi.

        :param messages: [{"role": "user"|"model", "parts": [{"text": "..."}]}]
        :param system_prompt: Tizim xabari (persona/task)
        :param max_retries: Kalit almashtirish maksimal urinish soni
        :param temperature: Kreativlik darajasi
        :returns: AI tomonidan yozilgan matn
        :raises RuntimeError: Hech qanday ishlaydigan kalit qolmasa
        """
        tried_key_ids: set[int] = set()

        async with self._session_factory() as session:
            for attempt in range(max_retries):
                key_obj = await self._pick_key(session)

                if key_obj is None:
                    raise RuntimeError(
                        "Barcha Gemini API kalitlari vaqtincha ishlamayapti. "
                        "Iltimos, keyinroq urinib ko'ring."
                    )

                if key_obj.id in tried_key_ids:
                    # Barcha mavjud kalitlarni sinab ko'rdik
                    break
                tried_key_ids.add(key_obj.id)

                try:
                    client = genai.Client(api_key=key_obj.key)

                    # Tizim xabarini config orqali uzatamiz
                    config = genai_types.GenerateContentConfig(
                        temperature=temperature,
                        max_output_tokens=2048,
                        system_instruction=system_prompt or "",
                    )

                    # Gemini SDK uchun content formatini to'g'rilash
                    contents = [
                        genai_types.Content(
                            role=msg["role"],
                            parts=[genai_types.Part(text=p["text"]) for p in msg["parts"]],
                        )
                        for msg in messages
                    ]

                    response = await asyncio.to_thread(
                        client.models.generate_content,
                        model=GEMINI_MODEL,
                        contents=contents,
                        config=config,
                    )

                    await self._record_usage(session, key_obj.id)
                    return response.text

                except ResourceExhausted as exc:
                    # HTTP 429 – rate limit yoki kunlik kvota
                    err_str = str(exc).lower()
                    if "quota" in err_str or "daily" in err_str:
                        await self._mark_exhausted(session, key_obj.id)
                    else:
                        await self._mark_rate_limited(session, key_obj.id)
                    logger.info(
                        "Attempt %d/%d: key id=%d rate-limited, rotating...",
                        attempt + 1, max_retries, key_obj.id,
                    )
                    continue  # Keyingi kalit bilan davom et

                except InvalidArgument as exc:
                    await self._mark_invalid(session, key_obj.id)
                    logger.error("Key id=%d invalid: %s", key_obj.id, exc)
                    continue

                except Exception as exc:
                    logger.exception(
                        "Unexpected error on key id=%d attempt %d: %s",
                        key_obj.id, attempt + 1, exc,
                    )
                    # Noma'lum xato – keyingi kalitga o'tmaymiz, qayta urinamiz
                    await asyncio.sleep(1)
                    continue

        raise RuntimeError(
            f"Barcha {len(tried_key_ids)} ta Gemini API kaliti sinab ko'rildi, "
            "hech biri ishlamadi."
        )

    async def generate_stream(
        self,
        messages: List[dict],
        system_prompt: Optional[str] = None,
        temperature: float = 0.9,
    ) -> AsyncGenerator[str, None]:
        """
        Streaming javob generatori (typing effekti uchun).
        Faqat bitta kalit bilan ishlaydi; xato bo'lsa exception ko'taradi.
        """
        async with self._session_factory() as session:
            key_obj = await self._pick_key(session)
            if key_obj is None:
                raise RuntimeError("Ishlaydigan Gemini API kaliti topilmadi.")

            client = genai.Client(api_key=key_obj.key)
            config = genai_types.GenerateContentConfig(
                temperature=temperature,
                max_output_tokens=2048,
                system_instruction=system_prompt or "",
            )
            contents = [
                genai_types.Content(
                    role=msg["role"],
                    parts=[genai_types.Part(text=p["text"]) for p in msg["parts"]],
                )
                for msg in messages
            ]

            try:
                for chunk in client.models.generate_content_stream(
                    model=GEMINI_MODEL,
                    contents=contents,
                    config=config,
                ):
                    if chunk.text:
                        yield chunk.text
                await self._record_usage(session, key_obj.id)
            except ResourceExhausted:
                await self._mark_rate_limited(session, key_obj.id)
                raise


# ---------------------------------------------------------------------------
# Context (suhbat tarixi) yordamchi funksiyalari
# ---------------------------------------------------------------------------

async def build_message_history(
    session: AsyncSession,
    account_id: int,
    peer_id: str,
    limit: int = 20,
) -> List[dict]:
    """
    DB'dan oxirgi `limit` ta xabarni o'qib, Gemini format (role/parts)ga o'giradi.
    """
    stmt = (
        select(ChatHistory)
        .where(
            ChatHistory.account_id == account_id,
            ChatHistory.peer_id == peer_id,
        )
        .order_by(ChatHistory.created_at.desc())
        .limit(limit)
    )
    result = await session.execute(stmt)
    rows: List[ChatHistory] = list(reversed(result.scalars().all()))

    messages = []
    for row in rows:
        role = "user" if row.role == MessageRole.USER else "model"
        messages.append({"role": role, "parts": [{"text": row.content}]})
    return messages


async def save_message(
    session: AsyncSession,
    account_id: int,
    peer_id: str,
    peer_name: Optional[str],
    role: MessageRole,
    content: str,
    tg_message_id: Optional[int] = None,
) -> ChatHistory:
    """Yangi xabarni suhbat tarixiga yozadi."""
    record = ChatHistory(
        account_id=account_id,
        peer_id=peer_id,
        peer_name=peer_name,
        role=role,
        content=content,
        tg_message_id=tg_message_id,
    )
    session.add(record)
    await session.commit()
    await session.refresh(record)
    return record


async def clear_chat_history(
    session: AsyncSession,
    account_id: int,
    peer_id: str,
) -> int:
    """Berilgan peer bilan bo'lgan barcha suhbat tarixini o'chiradi."""
    from sqlalchemy import delete as sa_delete
    result = await session.execute(
        sa_delete(ChatHistory).where(
            ChatHistory.account_id == account_id,
            ChatHistory.peer_id == peer_id,
        )
    )
    await session.commit()
    return result.rowcount


# ---------------------------------------------------------------------------
# Admin yordamchi: kalitlarni ommaviy yuklash (Bulk Upload)
# ---------------------------------------------------------------------------

async def bulk_add_gemini_keys(
    session: AsyncSession,
    raw_keys: str,
) -> dict[str, int]:
    """
    Ko'p qatorli (har qatorda bir kalit) matnni parse qilib DB ga yozadi.
    :returns: {"added": N, "duplicates": M}
    """
    lines = [ln.strip() for ln in raw_keys.splitlines() if ln.strip()]
    added = 0
    duplicates = 0

    for key_str in lines:
        existing = await session.execute(
            select(GeminiKey).where(GeminiKey.key == key_str)
        )
        if existing.scalar_one_or_none():
            duplicates += 1
            continue
        session.add(GeminiKey(key=key_str, status=KeyStatus.ACTIVE))
        added += 1

    await session.commit()
    logger.info("Bulk upload: +%d keys, %d duplicates skipped.", added, duplicates)
    return {"added": added, "duplicates": duplicates}


async def purge_invalid_keys(session: AsyncSession) -> int:
    """INVALID holатidagi barcha kalitlarni DB'dan o'chiradi."""
    from sqlalchemy import delete as sa_delete
    result = await session.execute(
        sa_delete(GeminiKey).where(GeminiKey.status == KeyStatus.INVALID)
    )
    await session.commit()
    logger.info("Purged %d invalid Gemini keys.", result.rowcount)
    return result.rowcount
