"""
Pips AI – Configuration
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Bot
    BOT_TOKEN: str = "8414221407:AAHmmB-erfwJ8FElbYJizSuh8_SGspkxYTM"
    ADMIN_IDS: list[int] = [8516819733]

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://pips:pips@localhost:5432/pips_ai"

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"

    # Celery
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"

    # App
    MAX_ACCOUNTS_PER_USER: int = 3
    DEFAULT_DAILY_STARS_COST: int = 0     # 0 = bepul
    CONTEXT_HISTORY_LIMIT: int = 20       # AI uchun suhbat tarixi chuqurligi

    # Userbot reply delays (anti-ban)
    REPLY_DELAY_MIN: float = 3.0
    REPLY_DELAY_MAX: float = 7.0


settings = Settings()
