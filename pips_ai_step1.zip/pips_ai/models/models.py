"""
Pips AI - Database Models
SQLAlchemy 2.x Async ORM
"""

from __future__ import annotations

import enum
from datetime import datetime
from typing import List, Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.ext.asyncio import AsyncAttrs, AsyncEngine, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------

class Base(AsyncAttrs, DeclarativeBase):
    """Shared declarative base with async attribute support."""
    pass


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class AccountStatus(str, enum.Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    BANNED = "banned"
    DISCONNECTED = "disconnected"


class MessageRole(str, enum.Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class PostStatus(str, enum.Enum):
    PENDING = "pending"
    SENT = "sent"
    FAILED = "failed"
    CANCELLED = "cancelled"


class KeyStatus(str, enum.Enum):
    ACTIVE = "active"
    RATE_LIMITED = "rate_limited"       # Temporary 429 block
    EXHAUSTED = "exhausted"             # Daily quota full
    INVALID = "invalid"                 # Bad key / deleted


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

class User(Base):
    __tablename__ = "users"

    # Primary key = Telegram user_id
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)
    username: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)
    full_name: Mapped[str] = mapped_column(String(256), nullable=False)
    language_code: Mapped[Optional[str]] = mapped_column(String(8), nullable=True)

    # Stars balance and daily cost
    stars_balance: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    is_premium: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Access control
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)
    is_subscribed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    last_active_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    accounts: Mapped[List["Account"]] = relationship(
        "Account", back_populates="owner", cascade="all, delete-orphan", lazy="selectin"
    )
    scheduled_posts: Mapped[List["ScheduledPost"]] = relationship(
        "ScheduledPost", back_populates="owner", cascade="all, delete-orphan", lazy="dynamic"
    )

    def __repr__(self) -> str:
        return f"<User id={self.id} username={self.username!r}>"


# ---------------------------------------------------------------------------
# Accounts  (Pyrogram userbot sessions)
# ---------------------------------------------------------------------------

class Account(Base):
    __tablename__ = "accounts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    owner_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )

    # Telegram identity
    phone: Mapped[str] = mapped_column(String(20), nullable=False)
    tg_user_id: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True, unique=True)
    tg_username: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    tg_full_name: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)

    # Session (Pyrogram StringSession)
    session_string: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Persona / AI behaviour
    persona_name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    persona_prompt: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    task_prompt: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Triggers (comma-separated keywords or JSON list stored as text)
    trigger_keywords: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Proxy (e.g. "socks5://user:pass@host:port")
    proxy_url: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)

    # Operational state
    status: Mapped[AccountStatus] = mapped_column(
        Enum(AccountStatus), default=AccountStatus.DISCONNECTED, nullable=False, index=True
    )
    is_sleeping: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    sleep_start_hour: Mapped[int] = mapped_column(Integer, default=23, nullable=False)   # 23:00
    sleep_end_hour: Mapped[int] = mapped_column(Integer, default=8, nullable=False)      # 08:00

    # Stats
    total_messages_sent: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    owner: Mapped["User"] = relationship("User", back_populates="accounts")
    chat_histories: Mapped[List["ChatHistory"]] = relationship(
        "ChatHistory", back_populates="account", cascade="all, delete-orphan", lazy="dynamic"
    )
    scheduled_posts: Mapped[List["ScheduledPost"]] = relationship(
        "ScheduledPost", back_populates="account", cascade="all, delete-orphan", lazy="dynamic"
    )

    __table_args__ = (
        UniqueConstraint("owner_id", "phone", name="uq_account_owner_phone"),
        Index("ix_accounts_owner_status", "owner_id", "status"),
    )

    def __repr__(self) -> str:
        return f"<Account id={self.id} phone={self.phone!r} status={self.status}>"


# ---------------------------------------------------------------------------
# Gemini API Keys
# ---------------------------------------------------------------------------

class GeminiKey(Base):
    __tablename__ = "gemini_keys"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    key: Mapped[str] = mapped_column(String(256), nullable=False, unique=True)
    alias: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)

    status: Mapped[KeyStatus] = mapped_column(
        Enum(KeyStatus), default=KeyStatus.ACTIVE, nullable=False, index=True
    )

    # Rate-limit bookkeeping
    rate_limited_until: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Round-robin position helper (updated atomically via Redis, stored for persistence)
    usage_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    error_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    last_used_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    def __repr__(self) -> str:
        return f"<GeminiKey id={self.id} alias={self.alias!r} status={self.status}>"


# ---------------------------------------------------------------------------
# Chat History  (per-account, per-peer conversation context)
# ---------------------------------------------------------------------------

class ChatHistory(Base):
    __tablename__ = "chat_history"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    account_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("accounts.id", ondelete="CASCADE"), nullable=False, index=True
    )

    # Telegram peer identifier (user_id or group_id as string to handle both)
    peer_id: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    peer_name: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)

    role: Mapped[MessageRole] = mapped_column(
        Enum(MessageRole), nullable=False
    )
    content: Mapped[str] = mapped_column(Text, nullable=False)

    # Original Telegram message id (for deduplication)
    tg_message_id: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False, index=True
    )

    # Relationships
    account: Mapped["Account"] = relationship("Account", back_populates="chat_histories")

    __table_args__ = (
        Index("ix_chathistory_account_peer_ts", "account_id", "peer_id", "created_at"),
    )

    def __repr__(self) -> str:
        return (
            f"<ChatHistory id={self.id} account={self.account_id} "
            f"peer={self.peer_id!r} role={self.role}>"
        )


# ---------------------------------------------------------------------------
# Scheduled Posts
# ---------------------------------------------------------------------------

class ScheduledPost(Base):
    __tablename__ = "scheduled_posts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    owner_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    account_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("accounts.id", ondelete="CASCADE"), nullable=False, index=True
    )

    # Destination: Telegram chat_id (group, channel, user)
    target_chat_id: Mapped[str] = mapped_column(String(64), nullable=False)
    target_chat_title: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)

    # Content
    content: Mapped[str] = mapped_column(Text, nullable=False)
    media_file_id: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)

    # AI generation prompt (optional – if set, AI generates content at send time)
    ai_generate_prompt: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Scheduling
    scheduled_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    status: Mapped[PostStatus] = mapped_column(
        Enum(PostStatus), default=PostStatus.PENDING, nullable=False, index=True
    )
    celery_task_id: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)

    # Result
    sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # Relationships
    owner: Mapped["User"] = relationship("User", back_populates="scheduled_posts")
    account: Mapped["Account"] = relationship("Account", back_populates="scheduled_posts")

    __table_args__ = (
        Index("ix_scheduled_posts_status_time", "status", "scheduled_at"),
    )

    def __repr__(self) -> str:
        return (
            f"<ScheduledPost id={self.id} target={self.target_chat_id!r} "
            f"at={self.scheduled_at} status={self.status}>"
        )


# ---------------------------------------------------------------------------
# Config (key-value store for admin settings)
# ---------------------------------------------------------------------------

class AppConfig(Base):
    __tablename__ = "app_config"

    key: Mapped[str] = mapped_column(String(128), primary_key=True)
    value: Mapped[str] = mapped_column(Text, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    def __repr__(self) -> str:
        return f"<AppConfig key={self.key!r} value={self.value!r}>"


# ---------------------------------------------------------------------------
# Required Subscription Channels
# ---------------------------------------------------------------------------

class RequiredChannel(Base):
    __tablename__ = "required_channels"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[str] = mapped_column(String(64), nullable=False, unique=True)
    title: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    invite_link: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    added_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    def __repr__(self) -> str:
        return f"<RequiredChannel id={self.id} title={self.title!r}>"


# ---------------------------------------------------------------------------
# Engine / Session factory helpers
# ---------------------------------------------------------------------------

def build_engine(database_url: str) -> AsyncEngine:
    return create_async_engine(
        database_url,
        echo=False,
        pool_size=20,
        max_overflow=10,
        pool_pre_ping=True,
    )


def build_session_factory(engine: AsyncEngine) -> async_sessionmaker:
    return async_sessionmaker(engine, expire_on_commit=False)


async def create_all_tables(engine: AsyncEngine) -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
