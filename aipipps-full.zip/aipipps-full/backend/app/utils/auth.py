import os, random, string
from datetime import datetime, timedelta
from jose import jwt, JWTError
from fastapi import HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

SECRET_KEY = os.getenv("SECRET_KEY", "change_this_secret")
ALGORITHM = "HS256"
bearer = HTTPBearer(auto_error=False)


def create_token(user_id: int, phone: str, is_admin: bool = False) -> str:
    payload = {
        "sub": str(user_id),
        "phone": phone,
        "is_admin": is_admin,
        "exp": datetime.utcnow() + timedelta(days=30),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError:
        raise HTTPException(status_code=401, detail="Token yaroqsiz")


def generate_otp() -> str:
    return ''.join(random.choices(string.digits, k=6))


async def get_current_user(creds: HTTPAuthorizationCredentials = Depends(bearer)):
    if not creds:
        raise HTTPException(status_code=401, detail="Token kerak")
    return decode_token(creds.credentials)


async def get_admin_user(user=Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(status_code=403, detail="Admin huquqi kerak")
    return user
