"""
AI PIPS — Unified AI Provider System
Qo'shish uchun shablon:
1. Yangi provider class yoz (BaseAIProvider dan meros)
2. PROVIDERS dict ga qo'sh
3. Admin paneldan API key va model_id kiritiladi — shu bo'ldi!
"""
import httpx
import os
from abc import ABC, abstractmethod
from typing import AsyncGenerator


# ─── BASE SHABLON ──────────────────────────────────────────────────────────────
class BaseAIProvider(ABC):
    """Har bir AI provider shu classdan meros oladi"""

    def __init__(self, api_key: str, model_id: str, base_url: str = ""):
        self.api_key = api_key
        self.model_id = model_id
        self.base_url = base_url

    @abstractmethod
    async def chat(self, messages: list, system: str = "") -> str:
        """Oddiy chat — javob qaytaradi"""
        pass

    @abstractmethod
    async def stream(self, messages: list, system: str = "") -> AsyncGenerator[str, None]:
        """Stream chat — har bir token kelganda yield qiladi"""
        pass

    def format_messages(self, messages: list) -> list:
        """Xabarlarni standart formatga o'tkazish"""
        return [{"role": m["role"], "content": m["content"]} for m in messages]


# ─── GEMINI (DEFAULT) ──────────────────────────────────────────────────────────
class GeminiProvider(BaseAIProvider):
    BASE = "https://generativelanguage.googleapis.com/v1beta"

    async def chat(self, messages: list, system: str = "") -> str:
        contents = []
        if system:
            contents.append({"role": "user", "parts": [{"text": f"[System]: {system}"}]})
            contents.append({"role": "model", "parts": [{"text": "Tushundim, davom eting."}]})
        for m in messages:
            role = "user" if m["role"] == "user" else "model"
            contents.append({"role": role, "parts": [{"text": m["content"]}]})

        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(
                f"{self.BASE}/models/{self.model_id}:generateContent?key={self.api_key}",
                json={"contents": contents, "generationConfig": {"maxOutputTokens": 2048, "temperature": 0.7}}
            )
            r.raise_for_status()
            data = r.json()
            return data["candidates"][0]["content"]["parts"][0]["text"]

    async def stream(self, messages: list, system: str = "") -> AsyncGenerator[str, None]:
        # Gemini streaming
        contents = []
        if system:
            contents.append({"role": "user", "parts": [{"text": f"[System]: {system}"}]})
            contents.append({"role": "model", "parts": [{"text": "OK"}]})
        for m in messages:
            role = "user" if m["role"] == "user" else "model"
            contents.append({"role": role, "parts": [{"text": m["content"]}]})

        async with httpx.AsyncClient(timeout=60) as client:
            async with client.stream(
                "POST",
                f"{self.BASE}/models/{self.model_id}:streamGenerateContent?key={self.api_key}&alt=sse",
                json={"contents": contents}
            ) as resp:
                async for line in resp.aiter_lines():
                    if line.startswith("data: "):
                        import json
                        try:
                            chunk = json.loads(line[6:])
                            text = chunk["candidates"][0]["content"]["parts"][0].get("text", "")
                            if text:
                                yield text
                        except Exception:
                            pass


# ─── ANTHROPIC (CLAUDE) ────────────────────────────────────────────────────────
class AnthropicProvider(BaseAIProvider):

    async def chat(self, messages: list, system: str = "") -> str:
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        body = {
            "model": self.model_id,
            "max_tokens": 2048,
            "messages": self.format_messages(messages),
        }
        if system:
            body["system"] = system

        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post("https://api.anthropic.com/v1/messages", headers=headers, json=body)
            r.raise_for_status()
            return r.json()["content"][0]["text"]

    async def stream(self, messages: list, system: str = "") -> AsyncGenerator[str, None]:
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        body = {
            "model": self.model_id,
            "max_tokens": 2048,
            "stream": True,
            "messages": self.format_messages(messages),
        }
        if system:
            body["system"] = system

        async with httpx.AsyncClient(timeout=60) as client:
            async with client.stream("POST", "https://api.anthropic.com/v1/messages", headers=headers, json=body) as resp:
                async for line in resp.aiter_lines():
                    if line.startswith("data: "):
                        import json
                        try:
                            chunk = json.loads(line[6:])
                            if chunk.get("type") == "content_block_delta":
                                yield chunk["delta"].get("text", "")
                        except Exception:
                            pass


# ─── OPENAI (GPT) ──────────────────────────────────────────────────────────────
class OpenAIProvider(BaseAIProvider):

    async def chat(self, messages: list, system: str = "") -> str:
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.extend(self.format_messages(messages))

        base = self.base_url or "https://api.openai.com/v1"
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}

        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(
                f"{base}/chat/completions",
                headers=headers,
                json={"model": self.model_id, "messages": msgs, "max_tokens": 2048}
            )
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]

    async def stream(self, messages: list, system: str = "") -> AsyncGenerator[str, None]:
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.extend(self.format_messages(messages))

        base = self.base_url or "https://api.openai.com/v1"
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}

        async with httpx.AsyncClient(timeout=60) as client:
            async with client.stream(
                "POST", f"{base}/chat/completions",
                headers=headers,
                json={"model": self.model_id, "messages": msgs, "stream": True}
            ) as resp:
                async for line in resp.aiter_lines():
                    if line.startswith("data: ") and line != "data: [DONE]":
                        import json
                        try:
                            chunk = json.loads(line[6:])
                            delta = chunk["choices"][0]["delta"].get("content", "")
                            if delta:
                                yield delta
                        except Exception:
                            pass


# ─── DEEPSEEK ──────────────────────────────────────────────────────────────────
class DeepSeekProvider(OpenAIProvider):
    """DeepSeek OpenAI-compatible API ishlatadi"""

    async def chat(self, messages: list, system: str = "") -> str:
        self.base_url = self.base_url or "https://api.deepseek.com"
        return await super().chat(messages, system)

    async def stream(self, messages: list, system: str = "") -> AsyncGenerator[str, None]:
        self.base_url = self.base_url or "https://api.deepseek.com"
        async for chunk in super().stream(messages, system):
            yield chunk


# ─── MISTRAL ───────────────────────────────────────────────────────────────────
class MistralProvider(OpenAIProvider):
    """Mistral ham OpenAI-compatible"""

    async def chat(self, messages: list, system: str = "") -> str:
        self.base_url = "https://api.mistral.ai/v1"
        return await super().chat(messages, system)

    async def stream(self, messages: list, system: str = "") -> AsyncGenerator[str, None]:
        self.base_url = "https://api.mistral.ai/v1"
        async for chunk in super().stream(messages, system):
            yield chunk


# ─── GROQ (tez, bepul) ─────────────────────────────────────────────────────────
class GroqProvider(OpenAIProvider):
    async def chat(self, messages: list, system: str = "") -> str:
        self.base_url = "https://api.groq.com/openai/v1"
        return await super().chat(messages, system)

    async def stream(self, messages: list, system: str = "") -> AsyncGenerator[str, None]:
        self.base_url = "https://api.groq.com/openai/v1"
        async for chunk in super().stream(messages, system):
            yield chunk


# ─── OLLAMA (VPS DA O'ZINGIZDA) ────────────────────────────────────────────────
class OllamaProvider(OpenAIProvider):
    """VPS da o'rnatilgan Ollama (Llama, Mistral, va boshqalar)"""

    async def chat(self, messages: list, system: str = "") -> str:
        self.base_url = self.base_url or "http://localhost:11434/v1"
        self.api_key = "ollama"  # Ollama key talab qilmaydi
        return await super().chat(messages, system)

    async def stream(self, messages: list, system: str = "") -> AsyncGenerator[str, None]:
        self.base_url = self.base_url or "http://localhost:11434/v1"
        self.api_key = "ollama"
        async for chunk in super().stream(messages, system):
            yield chunk


# ─── YANGI PROVIDER QO'SHISH SHABLON ──────────────────────────────────────────
# class YangiAIProvider(BaseAIProvider):
#     async def chat(self, messages, system=""):
#         # API ga so'rov yuborish
#         # Javobni qaytarish
#         pass
#     async def stream(self, messages, system=""):
#         # Streaming javob
#         yield ""


# ─── PROVIDER REGISTRY ────────────────────────────────────────────────────────
PROVIDER_MAP = {
    "gemini":    GeminiProvider,
    "anthropic": AnthropicProvider,
    "openai":    OpenAIProvider,
    "deepseek":  DeepSeekProvider,
    "mistral":   MistralProvider,
    "groq":      GroqProvider,
    "ollama":    OllamaProvider,
    # Yangi qo'shilganda shu yerga ham qo'sh:
    # "yangi": YangiAIProvider,
}


def get_provider(provider_name: str, api_key: str, model_id: str, base_url: str = "") -> BaseAIProvider:
    """Provider name bo'yicha to'g'ri classni qaytaradi"""
    cls = PROVIDER_MAP.get(provider_name.lower())
    if not cls:
        raise ValueError(f"Noma'lum provider: {provider_name}. Mavjudlar: {list(PROVIDER_MAP.keys())}")
    return cls(api_key=api_key, model_id=model_id, base_url=base_url)
