from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from app.database import init_db
from app.routers import auth, ai, telegram, github, google, admin


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(title="AI PIPS API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router,     prefix="/api/auth",     tags=["Auth"])
app.include_router(ai.router,       prefix="/api/ai",       tags=["AI Chat"])
app.include_router(telegram.router, prefix="/api/telegram", tags=["Telegram"])
app.include_router(github.router,   prefix="/api/github",   tags=["GitHub"])
app.include_router(google.router,   prefix="/api/google",   tags=["Google"])
app.include_router(admin.router,    prefix="/api/admin",    tags=["Admin"])


@app.get("/")
async def root():
    return {"status": "ok", "app": "AI PIPS", "docs": "/docs"}
