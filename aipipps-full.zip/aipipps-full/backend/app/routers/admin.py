from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional
import os

from app.database import get_db, AIProvider, User
from app.utils.auth import get_admin_user

router = APIRouter()


class AddModelRequest(BaseModel):
    name: str
    provider: str          # gemini | anthropic | openai | deepseek | mistral | groq | ollama
    model_id: str
    api_key: str
    base_url: str = ""
    is_active: bool = True
    is_default: bool = False


class UpdateModelRequest(BaseModel):
    name: Optional[str] = None
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    is_active: Optional[bool] = None
    is_default: Optional[bool] = None


# ─── AI MODELS ────────────────────────────────────────────────────────────────

@router.get("/models")
async def get_models(db: AsyncSession = Depends(get_db), admin=Depends(get_admin_user)):
    result = await db.execute(select(AIProvider).order_by(AIProvider.created_at))
    providers = result.scalars().all()
    return [{
        "id": p.id, "name": p.name, "provider": p.provider, "model_id": p.model_id,
        "base_url": p.base_url, "has_key": bool(p.api_key), "is_active": p.is_active,
        "is_default": p.is_default, "created_at": p.created_at.isoformat()
    } for p in providers]


@router.post("/models")
async def add_model(req: AddModelRequest, db: AsyncSession = Depends(get_db), admin=Depends(get_admin_user)):
    # Mavjudligini tekshirish
    existing = await db.execute(select(AIProvider).where(AIProvider.model_id == req.model_id))
    if existing.scalar_one_or_none():
        raise HTTPException(400, f"'{req.model_id}' allaqachon mavjud")

    # Agar default bo'lsa, boshqalarni o'chirish
    if req.is_default:
        result = await db.execute(select(AIProvider).where(AIProvider.is_default == True))
        for p in result.scalars().all():
            p.is_default = False

    provider = AIProvider(
        name=req.name, provider=req.provider, model_id=req.model_id,
        api_key=req.api_key, base_url=req.base_url,
        is_active=req.is_active, is_default=req.is_default
    )
    db.add(provider)
    await db.commit()
    await db.refresh(provider)
    return {"success": True, "id": provider.id, "message": f"'{req.name}' qo'shildi"}


@router.put("/models/{model_id}")
async def update_model(model_id: int, req: UpdateModelRequest, db: AsyncSession = Depends(get_db), admin=Depends(get_admin_user)):
    result = await db.execute(select(AIProvider).where(AIProvider.id == model_id))
    provider = result.scalar_one_or_none()
    if not provider:
        raise HTTPException(404, "Model topilmadi")

    if req.name is not None: provider.name = req.name
    if req.api_key is not None: provider.api_key = req.api_key
    if req.base_url is not None: provider.base_url = req.base_url
    if req.is_active is not None: provider.is_active = req.is_active
    if req.is_default:
        result2 = await db.execute(select(AIProvider).where(AIProvider.is_default == True))
        for p in result2.scalars().all():
            p.is_default = False
        provider.is_default = True

    await db.commit()
    return {"success": True}


@router.delete("/models/{model_id}")
async def delete_model(model_id: int, db: AsyncSession = Depends(get_db), admin=Depends(get_admin_user)):
    result = await db.execute(select(AIProvider).where(AIProvider.id == model_id))
    provider = result.scalar_one_or_none()
    if provider:
        await db.delete(provider)
        await db.commit()
    return {"success": True}


@router.post("/models/{model_id}/test")
async def test_model(model_id: int, db: AsyncSession = Depends(get_db), admin=Depends(get_admin_user)):
    """Model ishlashini tekshirish"""
    from app.services.ai_providers import get_provider
    result = await db.execute(select(AIProvider).where(AIProvider.id == model_id))
    provider_row = result.scalar_one_or_none()
    if not provider_row:
        raise HTTPException(404, "Model topilmadi")
    if not provider_row.api_key:
        raise HTTPException(400, "API key kiritilmagan")

    try:
        provider = get_provider(provider_row.provider, provider_row.api_key, provider_row.model_id, provider_row.base_url)
        reply = await provider.chat([{"role": "user", "content": "Salom! 1+1 nechchi?"}])
        return {"success": True, "reply": reply[:200]}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ─── USERS ────────────────────────────────────────────────────────────────────

@router.get("/users")
async def get_users(db: AsyncSession = Depends(get_db), admin=Depends(get_admin_user)):
    result = await db.execute(select(User).order_by(User.created_at.desc()))
    users = result.scalars().all()
    return [{"id": u.id, "phone": u.phone, "name": u.name, "is_admin": u.is_admin,
             "is_active": u.is_active, "created_at": u.created_at.isoformat()} for u in users]


@router.put("/users/{user_id}/toggle")
async def toggle_user(user_id: int, db: AsyncSession = Depends(get_db), admin=Depends(get_admin_user)):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(404, "Foydalanuvchi topilmadi")
    user.is_active = not user.is_active
    await db.commit()
    return {"success": True, "is_active": user.is_active}


@router.delete("/users/{user_id}")
async def delete_user(user_id: int, db: AsyncSession = Depends(get_db), admin=Depends(get_admin_user)):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user:
        await db.delete(user)
        await db.commit()
    return {"success": True}


# ─── STATS ────────────────────────────────────────────────────────────────────

@router.get("/stats")
async def get_stats(db: AsyncSession = Depends(get_db), admin=Depends(get_admin_user)):
    from sqlalchemy import func
    from app.database import Chat, Message, AppConnection

    users_count = (await db.execute(select(func.count(User.id)))).scalar()
    chats_count = (await db.execute(select(func.count(Chat.id)))).scalar()
    messages_count = (await db.execute(select(func.count(Message.id)))).scalar()
    connections_count = (await db.execute(select(func.count(AppConnection.id)).where(AppConnection.is_active == True))).scalar()
    models_count = (await db.execute(select(func.count(AIProvider.id)).where(AIProvider.is_active == True))).scalar()

    return {
        "users": users_count,
        "chats": chats_count,
        "messages": messages_count,
        "connections": connections_count,
        "active_models": models_count,
    }


# ─── PROVIDER TEMPLATES (Admin uchun qo'shish shablon) ────────────────────────

@router.get("/provider-templates")
async def get_templates(admin=Depends(get_admin_user)):
    """Admin modellari qo'shish uchun tayyor shablonlar"""
    return [
        {"provider": "gemini",    "name": "Gemini 2.5 Flash",    "model_id": "gemini-2.5-flash",           "api_url": "https://aistudio.google.com/apikey"},
        {"provider": "gemini",    "name": "Gemini 2.5 Pro",      "model_id": "gemini-2.5-pro",             "api_url": "https://aistudio.google.com/apikey"},
        {"provider": "anthropic", "name": "Claude 3.5 Sonnet",   "model_id": "claude-sonnet-4-20250514",   "api_url": "https://console.anthropic.com"},
        {"provider": "anthropic", "name": "Claude 3 Haiku",      "model_id": "claude-haiku-4-5-20251001",  "api_url": "https://console.anthropic.com"},
        {"provider": "openai",    "name": "GPT-4o",              "model_id": "gpt-4o",                     "api_url": "https://platform.openai.com/api-keys"},
        {"provider": "openai",    "name": "GPT-4o Mini",         "model_id": "gpt-4o-mini",                "api_url": "https://platform.openai.com/api-keys"},
        {"provider": "deepseek",  "name": "DeepSeek Chat",       "model_id": "deepseek-chat",              "api_url": "https://platform.deepseek.com"},
        {"provider": "deepseek",  "name": "DeepSeek Reasoner",   "model_id": "deepseek-reasoner",          "api_url": "https://platform.deepseek.com"},
        {"provider": "mistral",   "name": "Mistral Large",       "model_id": "mistral-large-latest",       "api_url": "https://console.mistral.ai"},
        {"provider": "groq",      "name": "Llama 3.3 70B (Groq)","model_id": "llama-3.3-70b-versatile",   "api_url": "https://console.groq.com"},
        {"provider": "groq",      "name": "Mixtral 8x7B (Groq)", "model_id": "mixtral-8x7b-32768",        "api_url": "https://console.groq.com"},
        {"provider": "ollama",    "name": "Llama 3 (local VPS)", "model_id": "llama3",                     "api_url": "http://localhost:11434"},
    ]
