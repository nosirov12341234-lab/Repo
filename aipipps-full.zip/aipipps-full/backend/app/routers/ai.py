from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional
import json

from app.database import get_db, Chat, Message, AIProvider
from app.utils.auth import get_current_user
from app.services.ai_providers import get_provider

router = APIRouter()


class ChatRequest(BaseModel):
    chat_id: Optional[int] = None
    message: str
    app_ids: list = []
    role: str = ""
    task: str = ""
    model_id: Optional[str] = None
    stream: bool = False


class CreateChatRequest(BaseModel):
    title: str = "Yangi chat"
    app_ids: list = []
    model_id: Optional[str] = None


@router.get("/models")
async def get_models(db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    result = await db.execute(select(AIProvider).where(AIProvider.is_active == True))
    providers = result.scalars().all()
    return [{"id": p.model_id, "name": p.name, "provider": p.provider, "is_default": p.is_default} for p in providers]


@router.post("/chats")
async def create_chat(req: CreateChatRequest, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    chat = Chat(
        user_id=int(user["sub"]),
        title=req.title,
        app_ids=json.dumps(req.app_ids),
        model_id=req.model_id or "gemini-2.5-flash",
    )
    db.add(chat)
    await db.commit()
    await db.refresh(chat)
    return {"id": chat.id, "title": chat.title}


@router.get("/chats")
async def get_chats(db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    result = await db.execute(
        select(Chat).where(Chat.user_id == int(user["sub"])).order_by(Chat.created_at.desc())
    )
    chats = result.scalars().all()
    return [{"id": c.id, "title": c.title, "app_ids": json.loads(c.app_ids), "model_id": c.model_id,
             "role": c.role, "task": c.task, "created_at": c.created_at.isoformat()} for c in chats]


@router.get("/chats/{chat_id}/messages")
async def get_messages(chat_id: int, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    result = await db.execute(
        select(Message).where(Message.chat_id == chat_id).order_by(Message.created_at)
    )
    msgs = result.scalars().all()
    return [{"role": m.role, "content": m.content, "timestamp": m.created_at.isoformat()} for m in msgs]


@router.post("/chat")
async def chat(req: ChatRequest, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    # Chat topish yoki yaratish
    if req.chat_id:
        chat_result = await db.execute(select(Chat).where(Chat.id == req.chat_id))
        chat = chat_result.scalar_one_or_none()
    else:
        chat = Chat(
            user_id=int(user["sub"]),
            title=req.message[:40],
            app_ids=json.dumps(req.app_ids),
            role=req.role,
            task=req.task,
            model_id=req.model_id or "gemini-2.5-flash",
        )
        db.add(chat)
        await db.commit()
        await db.refresh(chat)

    if not chat:
        raise HTTPException(404, "Chat topilmadi")

    # Xabar saqlash
    user_msg = Message(chat_id=chat.id, role="user", content=req.message)
    db.add(user_msg)
    await db.commit()

    # Tarix olish
    history_result = await db.execute(
        select(Message).where(Message.chat_id == chat.id).order_by(Message.created_at).limit(40)
    )
    history = [{"role": m.role, "content": m.content} for m in history_result.scalars().all()]

    # AI provider olish
    model_id = req.model_id or chat.model_id or "gemini-2.5-flash"
    provider_result = await db.execute(select(AIProvider).where(AIProvider.model_id == model_id))
    provider_row = provider_result.scalar_one_or_none()

    if not provider_row:
        # Default (Gemini) ga qaytish
        provider_result = await db.execute(select(AIProvider).where(AIProvider.is_default == True))
        provider_row = provider_result.scalar_one_or_none()

    if not provider_row or not provider_row.api_key:
        raise HTTPException(400, "AI provider sozlanmagan. Admin paneldan API key kiriting.")

    provider = get_provider(provider_row.provider, provider_row.api_key, provider_row.model_id, provider_row.base_url)

    # System prompt
    system = f"Siz AI PIPS yordamchisisiz."
    if chat.role:
        system += f"\nRolingiz: {chat.role}"
    if chat.task:
        system += f"\nVazifangiz: {chat.task}"
    if req.app_ids:
        system += f"\nUlangan ilovalar: {', '.join(req.app_ids)}"
    system += "\nO'zbek tilida javob bering."

    if req.stream:
        async def generate():
            full = ""
            yield f"data: {json.dumps({'chat_id': chat.id})}\n\n"
            async for chunk in provider.stream(history, system):
                full += chunk
                yield f"data: {json.dumps({'chunk': chunk})}\n\n"
            # Javobni saqlash
            ai_msg = Message(chat_id=chat.id, role="assistant", content=full)
            db.add(ai_msg)
            await db.commit()
            yield f"data: {json.dumps({'done': True})}\n\n"

        return StreamingResponse(generate(), media_type="text/event-stream")

    # Oddiy chat
    reply = await provider.chat(history, system)

    ai_msg = Message(chat_id=chat.id, role="assistant", content=reply)
    db.add(ai_msg)
    await db.commit()

    return {"chat_id": chat.id, "reply": reply}


@router.put("/chats/{chat_id}")
async def update_chat(chat_id: int, data: dict, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    result = await db.execute(select(Chat).where(Chat.id == chat_id, Chat.user_id == int(user["sub"])))
    chat = result.scalar_one_or_none()
    if not chat:
        raise HTTPException(404, "Chat topilmadi")
    if "role" in data:
        chat.role = data["role"]
    if "task" in data:
        chat.task = data["task"]
    if "title" in data:
        chat.title = data["title"]
    await db.commit()
    return {"success": True}


@router.delete("/chats/{chat_id}")
async def delete_chat(chat_id: int, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    result = await db.execute(select(Chat).where(Chat.id == chat_id, Chat.user_id == int(user["sub"])))
    chat = result.scalar_one_or_none()
    if chat:
        await db.delete(chat)
        await db.commit()
    return {"success": True}
