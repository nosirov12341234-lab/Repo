from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
import json, httpx

from app.database import get_db, AppConnection
from app.utils.auth import get_current_user

router = APIRouter()


class GitHubConnectRequest(BaseModel):
    token: str


class CreateIssueRequest(BaseModel):
    connection_id: int
    owner: str
    repo: str
    title: str
    body: str = ""


class CreateRepoRequest(BaseModel):
    connection_id: int
    name: str
    description: str = ""
    private: bool = False


@router.post("/connect")
async def connect(req: GitHubConnectRequest, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    async with httpx.AsyncClient() as client:
        r = await client.get("https://api.github.com/user",
                             headers={"Authorization": f"token {req.token}", "Accept": "application/vnd.github.v3+json"})
        if r.status_code != 200:
            raise HTTPException(400, "GitHub token yaroqsiz")
        gh_user = r.json()

    account_info = {"username": gh_user["login"], "name": gh_user.get("name", ""), "avatar": gh_user.get("avatar_url", "")}

    conn = AppConnection(
        user_id=int(user["sub"]),
        app_type="github",
        credentials=req.token,
        account_info=json.dumps(account_info),
    )
    db.add(conn)
    await db.commit()
    await db.refresh(conn)
    return {"success": True, "connection_id": conn.id, "account": account_info}


@router.get("/connections")
async def get_connections(db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    result = await db.execute(select(AppConnection).where(
        AppConnection.user_id == int(user["sub"]), AppConnection.app_type == "github", AppConnection.is_active == True))
    conns = result.scalars().all()
    return [{"id": c.id, "account": json.loads(c.account_info)} for c in conns]


@router.get("/repos/{connection_id}")
async def get_repos(connection_id: int, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    conn = await _get_conn(connection_id, user["sub"], db)
    async with httpx.AsyncClient() as client:
        r = await client.get("https://api.github.com/user/repos?sort=updated&per_page=30",
                             headers=_headers(conn.credentials))
        r.raise_for_status()
        return [{"name": x["name"], "full_name": x["full_name"], "private": x["private"],
                 "stars": x["stargazers_count"], "description": x.get("description", "")} for x in r.json()]


@router.get("/repos/{connection_id}/{owner}/{repo}/issues")
async def get_issues(connection_id: int, owner: str, repo: str, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    conn = await _get_conn(connection_id, user["sub"], db)
    async with httpx.AsyncClient() as client:
        r = await client.get(f"https://api.github.com/repos/{owner}/{repo}/issues",
                             headers=_headers(conn.credentials))
        r.raise_for_status()
        return [{"number": x["number"], "title": x["title"], "state": x["state"], "body": x.get("body", "")} for x in r.json()]


@router.post("/issues")
async def create_issue(req: CreateIssueRequest, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    conn = await _get_conn(req.connection_id, user["sub"], db)
    async with httpx.AsyncClient() as client:
        r = await client.post(f"https://api.github.com/repos/{req.owner}/{req.repo}/issues",
                              headers=_headers(conn.credentials),
                              json={"title": req.title, "body": req.body})
        r.raise_for_status()
        data = r.json()
        return {"success": True, "issue_number": data["number"], "url": data["html_url"]}


@router.post("/repos")
async def create_repo(req: CreateRepoRequest, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    conn = await _get_conn(req.connection_id, user["sub"], db)
    async with httpx.AsyncClient() as client:
        r = await client.post("https://api.github.com/user/repos",
                              headers=_headers(conn.credentials),
                              json={"name": req.name, "description": req.description, "private": req.private})
        r.raise_for_status()
        data = r.json()
        return {"success": True, "url": data["html_url"], "clone_url": data["clone_url"]}


def _headers(token: str) -> dict:
    return {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}


async def _get_conn(conn_id: int, user_id: str, db: AsyncSession) -> AppConnection:
    result = await db.execute(select(AppConnection).where(
        AppConnection.id == conn_id, AppConnection.user_id == int(user_id), AppConnection.is_active == True))
    conn = result.scalar_one_or_none()
    if not conn:
        raise HTTPException(404, "Ulanish topilmadi")
    return conn
