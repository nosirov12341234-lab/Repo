from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import datetime, timedelta
from pydantic import BaseModel
import httpx, os

from app.database import get_db, User, OTPCode
from app.utils.auth import generate_otp, create_token

router = APIRouter()


class SendOTPRequest(BaseModel):
    phone: str


class VerifyOTPRequest(BaseModel):
    phone: str
    code: str
    name: str = ""


async def send_telegram_otp(phone: str, code: str):
    """Telegram bot orqali OTP yuboradi"""
    bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "")
    # Bu yerda Telegram bot orqali xabar yuboriladi
    # Hozircha log ga yozamiz — real botni ulash uchun
    # foydalanuvchi avval botga /start bosishi kerak
    print(f"[OTP] {phone} → {code}")
    # TODO: bot.send_message(chat_id, f"AI PIPS kodi: {code}")


@router.post("/send-otp")
async def send_otp(req: SendOTPRequest, db: AsyncSession = Depends(get_db)):
    phone = req.phone.strip()
    if not phone.startswith("+"):
        raise HTTPException(400, "Telefon raqam + bilan boshlanishi kerak")

    code = generate_otp()
    expires = datetime.utcnow() + timedelta(minutes=5)

    # Eski kodlarni o'chirish
    old = await db.execute(select(OTPCode).where(OTPCode.phone == phone, OTPCode.used == False))
    for o in old.scalars().all():
        o.used = True

    otp = OTPCode(phone=phone, code=code, expires_at=expires)
    db.add(otp)
    await db.commit()

    await send_telegram_otp(phone, code)

    return {"success": True, "message": "Kod Telegram botga yuborildi", "dev_code": code}  # prod da dev_code olib tashlanadi


@router.post("/verify-otp")
async def verify_otp(req: VerifyOTPRequest, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(OTPCode).where(
            OTPCode.phone == req.phone,
            OTPCode.code == req.code,
            OTPCode.used == False,
            OTPCode.expires_at > datetime.utcnow()
        )
    )
    otp = result.scalar_one_or_none()
    if not otp:
        raise HTTPException(400, "Kod noto'g'ri yoki muddati o'tgan")

    otp.used = True

    # User yaratish yoki topish
    user_result = await db.execute(select(User).where(User.phone == req.phone))
    user = user_result.scalar_one_or_none()

    admin_phone = os.getenv("ADMIN_PHONE", "+998900000000")
    is_admin = req.phone == admin_phone

    if not user:
        user = User(phone=req.phone, name=req.name or req.phone, is_admin=is_admin)
        db.add(user)
    elif req.name:
        user.name = req.name

    await db.commit()
    await db.refresh(user)

    token = create_token(user.id, user.phone, user.is_admin)
    return {
        "token": token,
        "user": {"id": user.id, "phone": user.phone, "name": user.name, "is_admin": user.is_admin}
    }
