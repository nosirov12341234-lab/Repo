from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
import json, os, httpx

from app.database import get_db, AppConnection
from app.utils.auth import get_current_user

router = APIRouter()

GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
SCOPES = " ".join([
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/userinfo.email",
])


@router.get("/auth-url")
async def get_auth_url(user=Depends(get_current_user)):
    client_id = os.getenv("GOOGLE_CLIENT_ID", "")
    redirect_uri = os.getenv("GOOGLE_REDIRECT_URI", "")
    if not client_id:
        raise HTTPException(400, "GOOGLE_CLIENT_ID .env ga kiriting")

    url = (f"{GOOGLE_AUTH_URL}?client_id={client_id}&redirect_uri={redirect_uri}"
           f"&response_type=code&scope={SCOPES.replace(' ', '%20')}"
           f"&access_type=offline&prompt=consent&state={user['sub']}")
    return {"url": url}


@router.get("/callback")
async def google_callback(code: str, state: str, db: AsyncSession = Depends(get_db)):
    """Google OAuth callback"""
    client_id = os.getenv("GOOGLE_CLIENT_ID", "")
    client_secret = os.getenv("GOOGLE_CLIENT_SECRET", "")
    redirect_uri = os.getenv("GOOGLE_REDIRECT_URI", "")

    async with httpx.AsyncClient() as client:
        # Token olish
        r = await client.post(GOOGLE_TOKEN_URL, data={
            "code": code, "client_id": client_id, "client_secret": client_secret,
            "redirect_uri": redirect_uri, "grant_type": "authorization_code"
        })
        tokens = r.json()
        if "error" in tokens:
            raise HTTPException(400, tokens["error"])

        # User info
        info_r = await client.get("https://www.googleapis.com/oauth2/v2/userinfo",
                                   headers={"Authorization": f"Bearer {tokens['access_token']}"})
        user_info = info_r.json()

    account_info = {"email": user_info.get("email", ""), "name": user_info.get("name", "")}

    conn = AppConnection(
        user_id=int(state),
        app_type="google",
        credentials=json.dumps(tokens),
        account_info=json.dumps(account_info),
    )
    db.add(conn)
    await db.commit()
    await db.refresh(conn)

    return {"success": True, "message": "Google ulandi! Oynani yoping.", "account": account_info}


@router.get("/connections")
async def get_connections(db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    result = await db.execute(select(AppConnection).where(
        AppConnection.user_id == int(user["sub"]), AppConnection.app_type == "google", AppConnection.is_active == True))
    conns = result.scalars().all()
    return [{"id": c.id, "account": json.loads(c.account_info)} for c in conns]


# ─── SHEETS ───────────────────────────────────────────────────────────────────

@router.get("/sheets/{connection_id}/{spreadsheet_id}")
async def read_sheet(connection_id: int, spreadsheet_id: str, range: str = "Sheet1!A1:Z100",
                     db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    token = await _get_access_token(connection_id, user["sub"], db)
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheet_id}/values/{range}",
            headers={"Authorization": f"Bearer {token}"}
        )
        r.raise_for_status()
        return r.json()


@router.post("/sheets/{connection_id}/{spreadsheet_id}/append")
async def append_sheet(connection_id: int, spreadsheet_id: str, data: dict,
                       db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    token = await _get_access_token(connection_id, user["sub"], db)
    range_name = data.get("range", "Sheet1!A1")
    values = data.get("values", [])
    async with httpx.AsyncClient() as client:
        r = await client.post(
            f"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheet_id}/values/{range_name}:append?valueInputOption=USER_ENTERED",
            headers={"Authorization": f"Bearer {token}"},
            json={"values": values}
        )
        r.raise_for_status()
        return {"success": True, "updated": r.json().get("updates", {})}


# ─── CALENDAR ─────────────────────────────────────────────────────────────────

@router.get("/calendar/{connection_id}/events")
async def get_events(connection_id: int, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    token = await _get_access_token(connection_id, user["sub"], db)
    async with httpx.AsyncClient() as client:
        r = await client.get(
            "https://www.googleapis.com/calendar/v3/calendars/primary/events?maxResults=20&orderBy=startTime&singleEvents=true",
            headers={"Authorization": f"Bearer {token}"}
        )
        r.raise_for_status()
        events = r.json().get("items", [])
        return [{"id": e["id"], "summary": e.get("summary", ""), "start": e.get("start", {}), "end": e.get("end", {})} for e in events]


@router.post("/calendar/{connection_id}/events")
async def create_event(connection_id: int, event: dict, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    token = await _get_access_token(connection_id, user["sub"], db)
    async with httpx.AsyncClient() as client:
        r = await client.post(
            "https://www.googleapis.com/calendar/v3/calendars/primary/events",
            headers={"Authorization": f"Bearer {token}"},
            json=event
        )
        r.raise_for_status()
        return {"success": True, "event_id": r.json().get("id")}


# ─── GMAIL ────────────────────────────────────────────────────────────────────

@router.get("/gmail/{connection_id}/inbox")
async def get_inbox(connection_id: int, limit: int = 10, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    token = await _get_access_token(connection_id, user["sub"], db)
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults={limit}&labelIds=INBOX",
            headers={"Authorization": f"Bearer {token}"}
        )
        r.raise_for_status()
        messages = r.json().get("messages", [])
        result = []
        for msg in messages[:5]:
            msg_r = await client.get(
                f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{msg['id']}?format=metadata&metadataHeaders=Subject&metadataHeaders=From",
                headers={"Authorization": f"Bearer {token}"}
            )
            meta = msg_r.json()
            headers = {h["name"]: h["value"] for h in meta.get("payload", {}).get("headers", [])}
            result.append({"id": msg["id"], "subject": headers.get("Subject", ""), "from": headers.get("From", ""), "snippet": meta.get("snippet", "")})
        return result


# ─── HELPERS ──────────────────────────────────────────────────────────────────

async def _get_access_token(conn_id: int, user_id: str, db: AsyncSession) -> str:
    result = await db.execute(select(AppConnection).where(
        AppConnection.id == conn_id, AppConnection.user_id == int(user_id), AppConnection.is_active == True))
    conn = result.scalar_one_or_none()
    if not conn:
        raise HTTPException(404, "Google ulanish topilmadi")

    tokens = json.loads(conn.credentials)
    access_token = tokens.get("access_token", "")

    # Token yangilash (agar muddati o'tgan bo'lsa)
    if not access_token:
        refresh_token = tokens.get("refresh_token", "")
        if refresh_token:
            async with httpx.AsyncClient() as client:
                r = await client.post(GOOGLE_TOKEN_URL, data={
                    "refresh_token": refresh_token,
                    "client_id": os.getenv("GOOGLE_CLIENT_ID"),
                    "client_secret": os.getenv("GOOGLE_CLIENT_SECRET"),
                    "grant_type": "refresh_token"
                })
                new_tokens = r.json()
                tokens.update(new_tokens)
                conn.credentials = json.dumps(tokens)
                await db.commit()
                access_token = new_tokens.get("access_token", "")

    return access_token
