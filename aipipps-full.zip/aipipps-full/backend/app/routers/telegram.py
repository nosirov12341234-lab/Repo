from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional
import json, os

from app.database import get_db, AppConnection
from app.utils.auth import get_current_user

router = APIRouter()

# Active Pyrogram sessions (memory da)
_sessions = {}


class TelegramLoginRequest(BaseModel):
    phone: str


class TelegramCodeRequest(BaseModel):
    phone: str
    code: str
    phone_code_hash: str
    password: Optional[str] = None


class SendMessageRequest(BaseModel):
    connection_id: int
    chat_username: str
    message: str


@router.post("/connect/start")
async def telegram_connect_start(req: TelegramLoginRequest, user=Depends(get_current_user)):
    """Telegram akkountga ulashni boshlash"""
    from pyrogram import Client

    api_id = int(os.getenv("TELEGRAM_API_ID", "0"))
    api_hash = os.getenv("TELEGRAM_API_HASH", "")

    if not api_id or not api_hash:
        raise HTTPException(400, "TELEGRAM_API_ID va TELEGRAM_API_HASH .env ga kiriting")

    session_name = f"user_{user['sub']}_{req.phone.replace('+', '')}"

    try:
        app = Client(session_name, api_id=api_id, api_hash=api_hash, in_memory=True)
        await app.connect()
        sent = await app.send_code(req.phone)
        _sessions[user["sub"]] = {"client": app, "phone": req.phone, "hash": sent.phone_code_hash}
        return {"success": True, "phone_code_hash": sent.phone_code_hash, "message": "Kod Telegramga yuborildi"}
    except Exception as e:
        raise HTTPException(400, f"Xatolik: {str(e)}")


@router.post("/connect/verify")
async def telegram_connect_verify(req: TelegramCodeRequest, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    """Kodni tasdiqlash va sessiyani saqlash"""
    session_data = _sessions.get(user["sub"])
    if not session_data:
        raise HTTPException(400, "Avval /connect/start ni chaqiring")

    app = session_data["client"]

    try:
        await app.sign_in(req.phone, req.phone_code_hash, req.code)
    except Exception as e:
        error = str(e)
        if "PASSWORD_HASH_INVALID" in error or "2FA" in error.upper():
            if not req.password:
                return {"need_2fa": True, "message": "2 bosqichli tasdiqlash paroli kerak"}
            try:
                await app.check_password(req.password)
            except Exception as e2:
                raise HTTPException(400, f"2FA xatolik: {str(e2)}")
        else:
            raise HTTPException(400, f"Kod xatolik: {error}")

    # Session stringini saqlash
    session_string = await app.export_session_string()
    me = await app.get_me()

    account_info = {
        "user_id": me.id,
        "username": me.username or "",
        "first_name": me.first_name or "",
        "phone": req.phone,
    }

    conn = AppConnection(
        user_id=int(user["sub"]),
        app_type="telegram",
        credentials=session_string,
        account_info=json.dumps(account_info),
    )
    db.add(conn)
    await db.commit()
    await db.refresh(conn)

    del _sessions[user["sub"]]

    return {
        "success": True,
        "connection_id": conn.id,
        "account": account_info,
        "message": f"@{me.username or me.first_name} akkountiga ulandi!"
    }


@router.get("/connections")
async def get_connections(db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    result = await db.execute(
        select(AppConnection).where(
            AppConnection.user_id == int(user["sub"]),
            AppConnection.app_type == "telegram",
            AppConnection.is_active == True
        )
    )
    conns = result.scalars().all()
    return [{"id": c.id, "account": json.loads(c.account_info)} for c in conns]


@router.get("/me/{connection_id}")
async def get_me(connection_id: int, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    conn = await _get_connection(connection_id, user["sub"], db)
    async with _get_client(conn) as app:
        me = await app.get_me()
        return {"id": me.id, "username": me.username, "first_name": me.first_name, "phone": me.phone_number}


@router.get("/dialogs/{connection_id}")
async def get_dialogs(connection_id: int, limit: int = 20, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    """Chatlar ro'yxatini olish"""
    conn = await _get_connection(connection_id, user["sub"], db)
    async with _get_client(conn) as app:
        dialogs = []
        async for dialog in app.get_dialogs(limit=limit):
            dialogs.append({
                "id": dialog.chat.id,
                "title": getattr(dialog.chat, "title", None) or getattr(dialog.chat, "first_name", ""),
                "username": getattr(dialog.chat, "username", ""),
                "unread_count": dialog.unread_messages_count,
                "last_message": dialog.top_message.text[:80] if dialog.top_message else "",
            })
        return dialogs


@router.get("/messages/{connection_id}/{chat_id}")
async def get_messages(connection_id: int, chat_id: int, limit: int = 30, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    conn = await _get_connection(connection_id, user["sub"], db)
    async with _get_client(conn) as app:
        msgs = []
        async for msg in app.get_chat_history(chat_id, limit=limit):
            msgs.append({
                "id": msg.id,
                "text": msg.text or "",
                "from": getattr(msg.from_user, "username", "") if msg.from_user else "",
                "date": msg.date.isoformat(),
                "outgoing": msg.outgoing,
            })
        return list(reversed(msgs))


@router.post("/send")
async def send_message(req: SendMessageRequest, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    conn = await _get_connection(req.connection_id, user["sub"], db)
    async with _get_client(conn) as app:
        msg = await app.send_message(req.chat_username, req.message)
        return {"success": True, "message_id": msg.id}


@router.delete("/connections/{connection_id}")
async def disconnect(connection_id: int, db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    conn = await _get_connection(connection_id, user["sub"], db)
    conn.is_active = False
    await db.commit()
    return {"success": True}


# ─── HELPERS ──────────────────────────────────────────────────────────────────
async def _get_connection(conn_id: int, user_id: str, db: AsyncSession) -> AppConnection:
    result = await db.execute(
        select(AppConnection).where(
            AppConnection.id == conn_id,
            AppConnection.user_id == int(user_id),
            AppConnection.is_active == True
        )
    )
    conn = result.scalar_one_or_none()
    if not conn:
        raise HTTPException(404, "Ulanish topilmadi")
    return conn


from contextlib import asynccontextmanager
from pyrogram import Client

@asynccontextmanager
async def _get_client(conn: AppConnection):
    api_id = int(os.getenv("TELEGRAM_API_ID", "0"))
    api_hash = os.getenv("TELEGRAM_API_HASH", "")
    app = Client("session", api_id=api_id, api_hash=api_hash,
                 session_string=conn.credentials, in_memory=True)
    await app.start()
    try:
        yield app
    finally:
        await app.stop()
