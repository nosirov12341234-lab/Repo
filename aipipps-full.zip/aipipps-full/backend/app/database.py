from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy import Column, Integer, String, Boolean, Text, DateTime, JSON
from datetime import datetime

DATABASE_URL = "sqlite+aiosqlite:///./data/aipipps.db"

engine = create_async_engine(DATABASE_URL, echo=False)
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
Base = declarative_base()


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    phone = Column(String, unique=True, index=True)
    name = Column(String, default="")
    is_admin = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class AppConnection(Base):
    __tablename__ = "app_connections"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, index=True)
    app_type = Column(String)          # telegram, github, google
    credentials = Column(Text)         # JSON encrypted
    account_info = Column(Text)        # JSON: username, email etc
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Chat(Base):
    __tablename__ = "chats"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, index=True)
    title = Column(String, default="Yangi chat")
    app_ids = Column(Text, default="[]")   # JSON list
    role = Column(String, default="")
    task = Column(String, default="")
    model_id = Column(String, default="gemini-2.5-flash")
    created_at = Column(DateTime, default=datetime.utcnow)


class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True)
    chat_id = Column(Integer, index=True)
    role = Column(String)              # user | assistant
    content = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


class AIProvider(Base):
    __tablename__ = "ai_providers"
    id = Column(Integer, primary_key=True)
    name = Column(String)              # GPT-4o, Claude 3.5...
    provider = Column(String)          # openai, anthropic, gemini, deepseek
    model_id = Column(String, unique=True)
    api_key = Column(Text)             # encrypted
    base_url = Column(String, default="")   # custom endpoint uchun
    is_active = Column(Boolean, default=True)
    is_default = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class OTPCode(Base):
    __tablename__ = "otp_codes"
    id = Column(Integer, primary_key=True)
    phone = Column(String, index=True)
    code = Column(String)
    expires_at = Column(DateTime)
    used = Column(Boolean, default=False)


async def init_db():
    import os
    os.makedirs("data", exist_ok=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    # Default AI providers qo'shish
    await seed_default_providers()


async def seed_default_providers():
    import os, json
    from sqlalchemy import select
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(AIProvider))
        if result.scalars().first():
            return
        defaults = [
            AIProvider(name="Gemini 2.5 Flash", provider="gemini", model_id="gemini-2.5-flash",
                      api_key=os.getenv("GEMINI_API_KEY", ""), is_active=True, is_default=True),
            AIProvider(name="Gemini 2.0 Flash", provider="gemini", model_id="gemini-2.0-flash",
                      api_key=os.getenv("GEMINI_API_KEY", ""), is_active=True),
            AIProvider(name="Claude 3.5 Sonnet", provider="anthropic", model_id="claude-sonnet-4-20250514",
                      api_key=os.getenv("ANTHROPIC_API_KEY", ""), is_active=False),
            AIProvider(name="GPT-4o", provider="openai", model_id="gpt-4o",
                      api_key=os.getenv("OPENAI_API_KEY", ""), is_active=False),
            AIProvider(name="DeepSeek Chat", provider="deepseek", model_id="deepseek-chat",
                      api_key=os.getenv("DEEPSEEK_API_KEY", ""),
                      base_url="https://api.deepseek.com", is_active=False),
        ]
        for p in defaults:
            db.add(p)
        await db.commit()


async def get_db():
    async with AsyncSessionLocal() as session:
        yield session
