import React from 'react';
import { useApp } from '../context/AppContext';
import {
  MessageSquare, Plus, LayoutGrid, Settings,
  Shield, LogOut, ChevronRight, Trash2, X
} from 'lucide-react';

export default function Sidebar({ page, setPage }) {
  const { user, isAdmin, settings, chats, activeChat, setActiveChat,
    createChat, deleteChat, logout, sidebarOpen, setSidebarOpen } = useApp();

  const nav = (p) => { setPage(p); setSidebarOpen(false); };

  const handleNewChat = () => { nav('apps'); };

  const formatTime = (iso) => {
    const d = new Date(iso);
    const now = new Date();
    const diff = (now - d) / 1000;
    if (diff < 60) return 'hozirgina';
    if (diff < 3600) return `${Math.floor(diff/60)}m`;
    if (diff < 86400) return `${Math.floor(diff/3600)}h`;
    return d.toLocaleDateString('uz');
  };

  return (
    <>
      {/* Overlay */}
      <div
        className={`sidebar-overlay ${sidebarOpen ? 'show' : ''}`}
        onClick={() => setSidebarOpen(false)}
      />

      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        {/* Header */}
        <div className="sidebar-header">
          <div className="logo-mark" style={{ background: settings.appLogo ? 'transparent' : 'var(--accent-dim)', border: '1px solid rgba(204,120,92,0.2)' }}>
            {settings.appLogo
              ? <img src={settings.appLogo} alt="logo" />
              : <span style={{ color: 'var(--accent)', fontWeight: 800, fontSize: '13px' }}>
                  {settings.appName?.charAt(0) || 'A'}
                </span>
            }
          </div>
          <span className="logo-name">{settings.appName}</span>
          <button
            className="mobile-menu-btn"
            style={{ marginLeft: 'auto' }}
            onClick={() => setSidebarOpen(false)}
          >
            <X size={18} />
          </button>
        </div>

        {/* New Chat */}
        <button className="sidebar-new-chat" onClick={handleNewChat}>
          <Plus size={15} />
          <span>Yangi chat</span>
        </button>

        {/* Nav */}
        <nav className="sidebar-nav">
          <button className={`nav-item ${page === 'dashboard' ? 'active' : ''}`} onClick={() => nav('dashboard')}>
            <LayoutGrid size={16} /> Ilovalar
          </button>
          <button className={`nav-item ${page === 'apps' ? 'active' : ''}`} onClick={() => nav('apps')}>
            <Plus size={16} /> Ilova qo'shish
          </button>

          {chats.length > 0 && (
            <>
              <div className="nav-divider" />
              <div className="sidebar-section">
                <span className="sidebar-section-label">Chatlar</span>
              </div>
              {chats.slice(0, 20).map(chat => (
                <div
                  key={chat.id}
                  className={`nav-item ${activeChat === chat.id && page === 'chat' ? 'active' : ''}`}
                  style={{ justifyContent: 'space-between', gap: '6px' }}
                  onClick={() => { setActiveChat(chat.id); nav('chat'); }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: 0, flex: 1 }}>
                    <MessageSquare size={14} style={{ flexShrink: 0 }} />
                    <span style={{ truncate: 'ellipsis', whiteSpace: 'nowrap', overflow: 'hidden', flex: 1, fontSize: '12px' }}>
                      {chat.title || 'Chat'}
                    </span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '4px', flexShrink: 0 }}>
                    <span style={{ fontSize: '10px', color: 'var(--text-tertiary)' }}>{formatTime(chat.createdAt)}</span>
                    <button
                      style={{ background: 'none', border: 'none', color: 'var(--text-tertiary)', cursor: 'pointer', padding: '2px', borderRadius: '4px', display: 'flex' }}
                      onClick={e => { e.stopPropagation(); deleteChat(chat.id); }}
                    >
                      <Trash2 size={11} />
                    </button>
                  </div>
                </div>
              ))}
            </>
          )}
        </nav>

        {/* Bottom */}
        <div className="sidebar-bottom">
          <button className={`nav-item ${page === 'settings' ? 'active' : ''}`} onClick={() => nav('settings')} style={{ width: '100%', marginBottom: '4px' }}>
            <Settings size={16} /> Sozlamalar
          </button>
          {isAdmin && (
            <button className={`nav-item ${page === 'admin' ? 'active' : ''}`} onClick={() => nav('admin')} style={{ width: '100%', marginBottom: '4px', color: 'var(--warning)' }}>
              <Shield size={16} /> Admin panel
            </button>
          )}
          <div className="nav-divider" />
          <div className="user-pill">
            <div className="user-avatar">{user?.name?.charAt(0)?.toUpperCase() || '?'}</div>
            <div className="user-info">
              <div className="user-name">{user?.name}</div>
              <div className="user-phone">{user?.phone}</div>
            </div>
            <button
              style={{ background: 'none', border: 'none', color: 'var(--text-tertiary)', cursor: 'pointer', padding: '4px', borderRadius: '6px' }}
              onClick={logout}
              title="Chiqish"
            >
              <LogOut size={14} />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
