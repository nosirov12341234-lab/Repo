import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Check, X, Eye, EyeOff, ArrowRight, MessageSquare } from 'lucide-react';

export const APP_DEFINITIONS = [
  { id: 'telegram', name: 'Telegram', icon: '✈️', color: '#2AABEE', category: 'messaging',
    fields: [
      { key: 'phone', label: 'Telefon raqam', placeholder: '+998901234567', type: 'tel' },
      { key: 'code', label: 'SMS/Telegram kodi', placeholder: '12345', type: 'text' },
      { key: 'password', label: '2FA parol (ixtiyoriy)', placeholder: 'Agar mavjud bo\'lsa', type: 'password', optional: true },
    ]
  },
  { id: 'instagram', name: 'Instagram', icon: '📸', color: '#E1306C', category: 'social',
    fields: [
      { key: 'username', label: 'Foydalanuvchi nomi', placeholder: '@username', type: 'text' },
      { key: 'password', label: 'Parol', placeholder: '••••••••', type: 'password' },
    ]
  },
  { id: 'twitter', name: 'Twitter / X', icon: '🐦', color: '#1DA1F2', category: 'social',
    fields: [
      { key: 'username', label: 'Foydalanuvchi nomi', placeholder: '@handle', type: 'text' },
      { key: 'password', label: 'Parol', placeholder: '••••••••', type: 'password' },
    ]
  },
  { id: 'tiktok', name: 'TikTok', icon: '🎵', color: '#010101', category: 'social',
    fields: [
      { key: 'username', label: 'Foydalanuvchi nomi', placeholder: '@username', type: 'text' },
      { key: 'password', label: 'Parol', placeholder: '••••••••', type: 'password' },
    ]
  },
  { id: 'github', name: 'GitHub', icon: '🐙', color: '#333333', category: 'dev',
    fields: [
      { key: 'token', label: 'Personal Access Token', placeholder: 'ghp_xxxxxxxxxxxx', type: 'password' },
    ]
  },
  { id: 'youtube', name: 'YouTube', icon: '▶️', color: '#FF0000', category: 'media',
    fields: [
      { key: 'email', label: 'Gmail', placeholder: 'user@gmail.com', type: 'email' },
      { key: 'password', label: 'Parol', placeholder: '••••••••', type: 'password' },
    ]
  },
  { id: 'gsheets', name: 'Google Sheets', icon: '📊', color: '#34A853', category: 'productivity',
    fields: [
      { key: 'email', label: 'Gmail', placeholder: 'user@gmail.com', type: 'email' },
      { key: 'apiKey', label: 'API Key', placeholder: 'AIzaSy...', type: 'password' },
    ]
  },
  { id: 'gcalendar', name: 'Google Calendar', icon: '📅', color: '#4285F4', category: 'productivity',
    fields: [
      { key: 'email', label: 'Gmail', placeholder: 'user@gmail.com', type: 'email' },
      { key: 'apiKey', label: 'API Key', placeholder: 'AIzaSy...', type: 'password' },
    ]
  },
  { id: 'gmail', name: 'Gmail', icon: '📧', color: '#EA4335', category: 'productivity',
    fields: [
      { key: 'email', label: 'Gmail manzil', placeholder: 'user@gmail.com', type: 'email' },
      { key: 'appPassword', label: 'App Password', placeholder: 'xxxx xxxx xxxx xxxx', type: 'password' },
    ]
  },
  { id: 'whatsapp', name: 'WhatsApp', icon: '💬', color: '#25D366', category: 'messaging',
    fields: [
      { key: 'phone', label: 'Telefon raqam', placeholder: '+998901234567', type: 'tel' },
    ]
  },
  { id: 'discord', name: 'Discord', icon: '🎮', color: '#5865F2', category: 'messaging',
    fields: [
      { key: 'token', label: 'Bot Token', placeholder: 'Bot token...', type: 'password' },
    ]
  },
  { id: 'notion', name: 'Notion', icon: '📝', color: '#000000', category: 'productivity',
    fields: [
      { key: 'token', label: 'Integration Token', placeholder: 'secret_...', type: 'password' },
    ]
  },
];

const CATEGORIES = {
  messaging: 'Xabar almashish',
  social: 'Ijtimoiy tarmoqlar',
  dev: 'Dasturlash',
  media: 'Media',
  productivity: 'Produktivlik',
};

function ConnectModal({ app, onClose, onConnect }) {
  const [values, setValues] = useState({});
  const [showPass, setShowPass] = useState({});
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(0);

  const handleConnect = async () => {
    const required = app.fields.filter(f => !f.optional);
    for (const f of required) {
      if (!values[f.key]) { alert(`${f.label} kiriting`); return; }
    }
    setLoading(true);
    await new Promise(r => setTimeout(r, 1500));
    setLoading(false);
    onConnect({ username: values.username || values.phone || values.email || 'Ulangan' });
  };

  return (
    <div className="modal-backdrop" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal animate-up">
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{
              width: '32px', height: '32px', borderRadius: '8px',
              background: app.color + '20',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px'
            }}>{app.icon}</div>
            <span className="modal-title">{app.name} ulash</span>
          </div>
          <button className="modal-close" onClick={onClose}><X size={18}/></button>
        </div>
        <div className="modal-body">
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {app.fields.map(field => (
              <div key={field.key} className="form-group">
                <label className="input-label">
                  {field.label}
                  {field.optional && <span style={{ color: 'var(--text-tertiary)', marginLeft: '4px' }}>(ixtiyoriy)</span>}
                </label>
                <div style={{ position: 'relative' }}>
                  <input
                    className="input"
                    type={showPass[field.key] ? 'text' : field.type}
                    placeholder={field.placeholder}
                    value={values[field.key] || ''}
                    onChange={e => setValues(v => ({ ...v, [field.key]: e.target.value }))}
                  />
                  {field.type === 'password' && (
                    <button
                      type="button"
                      onClick={() => setShowPass(s => ({ ...s, [field.key]: !s[field.key] }))}
                      style={{
                        position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)',
                        background: 'none', border: 'none', color: 'var(--text-tertiary)', cursor: 'pointer',
                      }}
                    >
                      {showPass[field.key] ? <EyeOff size={15}/> : <Eye size={15}/>}
                    </button>
                  )}
                </div>
              </div>
            ))}
            <div style={{ padding: '10px 12px', background: 'var(--bg-tertiary)', borderRadius: '8px', border: '1px solid var(--border)', fontSize: '11px', color: 'var(--text-tertiary)' }}>
              ℹ️ Ma'lumotlaringiz faqat sizning qurilmangizda saqlanadi
            </div>
            <button className="btn btn-primary btn-lg" style={{ width: '100%', justifyContent: 'center' }} onClick={handleConnect} disabled={loading}>
              {loading
                ? <><span className="spinner" style={{ width: '15px', height: '15px', borderWidth: '2px' }}/> Ulanmoqda...</>
                : <><Check size={15}/> Ulash</>
              }
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AppsPage({ setPage }) {
  const { connectedApps, connectApp, disconnectApp, createChat, setActiveChat } = useApp();
  const [selectedApp, setSelectedApp] = useState(null);
  const [filter, setFilter] = useState('all');
  const [selectedForChat, setSelectedForChat] = useState([]);

  const isConnected = (id) => connectedApps.some(a => a.id === id);

  const grouped = {};
  APP_DEFINITIONS.forEach(app => {
    const cat = app.category;
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(app);
  });

  const handleConnect = (accountInfo) => {
    connectApp({ ...selectedApp });
    const idx = connectedApps.findIndex(a => a.id === selectedApp.id);
    setTimeout(() => {
      const { updateAppAccount } = window.__aipipps || {};
    }, 100);
    setSelectedApp(null);
  };

  const toggleSelect = (id) => {
    setSelectedForChat(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  };

  const startSelectedChat = () => {
    if (selectedForChat.length === 0) return;
    const id = createChat(selectedForChat);
    setActiveChat(id);
    setPage('chat');
  };

  return (
    <div className="page-content animate-fade">
      <div style={{ marginBottom: '24px' }}>
        <h1 style={{ fontSize: '22px', fontWeight: 700, marginBottom: '6px' }}>Ilovalar qo'shish</h1>
        <p style={{ color: 'var(--text-tertiary)', fontSize: '13px' }}>
          Ilovangizni ulab AI orqali boshqaring
        </p>
      </div>

      {/* Multi-select bar */}
      {selectedForChat.length > 0 && (
        <div style={{
          background: 'var(--accent-dim)', border: '1px solid rgba(204,120,92,0.3)',
          borderRadius: '10px', padding: '12px 16px', marginBottom: '20px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px',
          animation: 'slideUp 0.2s ease',
        }}>
          <span style={{ fontSize: '13px' }}>
            <strong style={{ color: 'var(--accent)' }}>{selectedForChat.length}</strong> ta ilova tanlandi
          </span>
          <div style={{ display: 'flex', gap: '8px' }}>
            <button className="btn btn-ghost btn-sm" onClick={() => setSelectedForChat([])}>
              Bekor
            </button>
            <button className="btn btn-primary btn-sm" onClick={startSelectedChat}>
              <MessageSquare size={13}/> Chat boshlash
            </button>
          </div>
        </div>
      )}

      {/* Categories */}
      {Object.entries(grouped).map(([cat, apps]) => (
        <div key={cat} style={{ marginBottom: '24px' }}>
          <div style={{ fontSize: '11px', fontWeight: 600, color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.7px', marginBottom: '10px' }}>
            {CATEGORIES[cat]}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '10px' }}>
            {apps.map(app => {
              const connected = isConnected(app.id);
              const inChat = selectedForChat.includes(app.id);
              return (
                <div
                  key={app.id}
                  className="card"
                  style={{
                    display: 'flex', flexDirection: 'column', gap: '12px',
                    border: `1px solid ${inChat ? app.color + '60' : connected ? 'rgba(74,222,128,0.2)' : 'var(--border)'}`,
                    background: inChat ? app.color + '08' : 'var(--bg-secondary)',
                    transition: 'all 0.2s',
                    cursor: connected ? 'pointer' : 'default',
                  }}
                  onClick={connected ? () => toggleSelect(app.id) : undefined}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div style={{
                      width: '36px', height: '36px', borderRadius: '9px',
                      background: app.color + '18',
                      border: `1px solid ${app.color + '30'}`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: '18px', flexShrink: 0,
                    }}>
                      {app.icon}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontWeight: 600, fontSize: '13px' }}>{app.name}</div>
                      <div style={{ fontSize: '11px', color: connected ? 'var(--success)' : 'var(--text-tertiary)' }}>
                        {connected ? '✓ Ulangan' : 'Ulanmagan'}
                      </div>
                    </div>
                    {inChat && <Check size={14} style={{ color: app.color, flexShrink: 0 }} />}
                  </div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    {connected ? (
                      <>
                        <button
                          className="btn btn-secondary btn-sm"
                          style={{ flex: 1, justifyContent: 'center', fontSize: '11px' }}
                          onClick={e => { e.stopPropagation(); toggleSelect(app.id); }}
                        >
                          {inChat ? '✓ Tanlandi' : 'Chat uchun tanlash'}
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={e => { e.stopPropagation(); disconnectApp(app.id); }}
                        >
                          <X size={12}/>
                        </button>
                      </>
                    ) : (
                      <button
                        className="btn btn-ghost btn-sm"
                        style={{ flex: 1, justifyContent: 'center', fontSize: '11px' }}
                        onClick={e => { e.stopPropagation(); setSelectedApp(app); }}
                      >
                        <ArrowRight size={12}/> Ulash
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}

      {selectedApp && (
        <ConnectModal
          app={selectedApp}
          onClose={() => setSelectedApp(null)}
          onConnect={(info) => {
            connectApp(selectedApp);
            setSelectedApp(null);
          }}
        />
      )}
    </div>
  );
}
