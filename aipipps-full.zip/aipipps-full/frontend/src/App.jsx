import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import LoginPage from './pages/LoginPage';
import Dashboard from './pages/Dashboard';
import ChatPage from './pages/ChatPage';
import SettingsPage from './pages/SettingsPage';
import AdminPanel from './pages/AdminPanel';
import AppsPage from './components/apps/AppsPage';
import Sidebar from './components/layout/Sidebar';
import { Menu } from 'lucide-react';

function AppInner() {
  const { user, sidebarOpen, setSidebarOpen } = useApp();
  const [page, setPage] = useState('dashboard');

  if (!user) return <LoginPage />;

  const renderPage = () => {
    switch (page) {
      case 'dashboard': return <Dashboard setPage={setPage}/>;
      case 'chat':      return <ChatPage setPage={setPage}/>;
      case 'apps':      return <AppsPage setPage={setPage}/>;
      case 'settings':  return <SettingsPage />;
      case 'admin':     return <AdminPanel />;
      default:          return <Dashboard setPage={setPage}/>;
    }
  };

  const PAGE_TITLES = { dashboard: 'Ilovalar', chat: 'Chat', apps: "Qo'shish", settings: 'Sozlamalar', admin: 'Admin' };

  return (
    <div className="app-layout">
      <Sidebar page={page} setPage={setPage} />
      <div className="main-content">
        {/* Mobile topbar */}
        <div className="mobile-topbar" style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', display: 'none', alignItems: 'center', gap: '12px', background: 'var(--bg-primary)', flexShrink: 0 }}>
          <button className="mobile-menu-btn" style={{ display: 'flex' }} onClick={() => setSidebarOpen(true)}>
            <Menu size={20}/>
          </button>
          <span style={{ fontWeight: 600, fontSize: '15px' }}>{PAGE_TITLES[page]}</span>
        </div>
        {page === 'chat'
          ? <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>{renderPage()}</div>
          : <div style={{ flex: 1, overflowY: 'auto' }}>{renderPage()}</div>
        }
      </div>
    </div>
  );
}

export default function App() {
  return <AppProvider><AppInner /></AppProvider>;
}
