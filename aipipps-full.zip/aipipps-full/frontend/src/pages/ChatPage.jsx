import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../utils/api';
import { Send, Settings, Plus, Bot, User, Copy, Check, X } from 'lucide-react';
import { APP_DEFINITIONS } from '../components/apps/AppsPage';

function Message({ msg }) {
  const [copied, setCopied] = useState(false);
  const isUser = msg.role === 'user';
  const copy = () => { navigator.clipboard.writeText(msg.content); setCopied(true); setTimeout(() => setCopied(false), 1500); };
  return (
    <div className={`message ${isUser ? 'user' : ''}`}>
      <div className={`message-avatar ${isUser ? 'msg-user-avatar' : 'msg-ai-avatar'}`}>
        {isUser ? <User size={13}/> : <Bot size={13}/>}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="message-bubble" style={{ position: 'relative' }}
          onMouseEnter={e => { const b = e.currentTarget.querySelector('.copy-btn'); if(b) b.style.opacity='1'; }}
          onMouseLeave={e => { const b = e.currentTarget.querySelector('.copy-btn'); if(b) b.style.opacity='0'; }}>
          <span style={{ whiteSpace: 'pre-wrap' }}>{msg.content}</span>
          {!isUser && <button onClick={copy} className="copy-btn" style={{ position:'absolute',top:'8px',right:'8px',background:'none',border:'none',color:'var(--text-tertiary)',cursor:'pointer',padding:'3px',borderRadius:'4px',opacity:0,transition:'opacity 0.2s' }}>{copied?<Check size={12}/>:<Copy size={12}/>}</button>}
        </div>
        <div style={{ fontSize:'10px',color:'var(--text-tertiary)',marginTop:'4px',textAlign:isUser?'right':'left' }}>
          {msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString('uz',{hour:'2-digit',minute:'2-digit'}) : ''}
        </div>
      </div>
    </div>
  );
}

export default function ChatPage({ setPage }) {
  const { chats, activeChat, setActiveChat, selectedModel, setSelectedModel, settings, connectedApps, models, createChat, updateChat } = useApp();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [streaming, setStreaming] = useState('');
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [roleInput, setRoleInput] = useState('');
  const [taskInput, setTaskInput] = useState('');
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);
  const chat = chats.find(c => c.id === activeChat);

  useEffect(() => { if (activeChat) loadMessages(); }, [activeChat]);
  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, streaming]);
  useEffect(() => {
    if (chat && !chat.role && messages.length === 0) setTimeout(() => setShowRoleModal(true), 400);
    if (chat) { setRoleInput(chat.role||''); setTaskInput(chat.task||''); }
  }, [activeChat]);

  const loadMessages = async () => {
    try { const msgs = await api.getMessages(activeChat); setMessages(msgs); } catch {}
  };

  const activeApps = (chat?.app_ids||[]).map(id => connectedApps.find(a => a.id === id)).filter(Boolean);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const content = input.trim();
    setInput('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    setMessages(m => [...m, { role:'user', content, timestamp: new Date().toISOString() }]);
    setLoading(true); setStreaming('');
    try {
      let chatId = activeChat;
      if (!chatId) chatId = await createChat(connectedApps.map(a=>a.id));
      let fullReply = '';
      await api.streamChat(
        { chat_id: chatId, message: content, model_id: selectedModel },
        (chunk) => { fullReply += chunk; setStreaming(fullReply); },
        () => { setMessages(m => [...m, { role:'assistant', content:fullReply, timestamp:new Date().toISOString() }]); setStreaming(''); }
      );
    } catch {
      try {
        const res = await api.sendMessage({ chat_id: activeChat, message: content, model_id: selectedModel });
        setMessages(m => [...m, { role:'assistant', content:res.reply, timestamp:new Date().toISOString() }]);
      } catch (e2) {
        setMessages(m => [...m, { role:'assistant', content:`Xatolik: ${e2.message}`, timestamp:new Date().toISOString() }]);
      }
      setStreaming('');
    }
    setLoading(false);
  };

  const handleKeyDown = (e) => { if (e.key==='Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } };
  const autoResize = (e) => { const el=e.target; el.style.height='auto'; el.style.height=Math.min(el.scrollHeight,180)+'px'; };
  const saveRole = async () => { if (activeChat) await updateChat(activeChat, { role:roleInput, task:taskInput }); setShowRoleModal(false); };

  if (!activeChat) return (
    <div style={{ flex:1,display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column',gap:'16px',color:'var(--text-tertiary)',padding:'32px' }}>
      <Bot size={40} style={{ opacity:0.3 }}/>
      <div style={{ textAlign:'center' }}>
        <p style={{ fontWeight:600,marginBottom:'6px',color:'var(--text-secondary)' }}>Chat tanlanmagan</p>
        <p style={{ fontSize:'13px' }}>Yangi chat boshlang</p>
      </div>
      <button className="btn btn-primary" onClick={() => setPage('apps')}><Plus size={14}/> Yangi chat</button>
    </div>
  );

  return (
    <div className="chat-layout">
      <div className="topbar" style={{ justifyContent:'space-between' }}>
        <div style={{ display:'flex',alignItems:'center',gap:'8px',minWidth:0 }}>
          {activeApps.slice(0,3).map(app => {
            const def = APP_DEFINITIONS.find(d=>d.id===app.id);
            return <div key={app.id} style={{ width:'24px',height:'24px',borderRadius:'6px',background:(def?.color||'#888')+'20',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'12px',flexShrink:0 }}>{def?.icon}</div>;
          })}
          <span style={{ fontSize:'13px',fontWeight:500,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap' }}>{chat?.title||'Chat'}</span>
        </div>
        <div style={{ display:'flex',gap:'6px',flexShrink:0 }}>
          <select value={selectedModel} onChange={e=>setSelectedModel(e.target.value)} style={{ background:'var(--bg-tertiary)',border:'1px solid var(--border)',borderRadius:'7px',color:'var(--text-secondary)',fontFamily:'inherit',fontSize:'12px',padding:'5px 8px',cursor:'pointer',outline:'none' }}>
            {models.map(m=><option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
          <button className="btn btn-ghost btn-sm" onClick={()=>setShowRoleModal(true)}><Settings size={13}/></button>
          <button className="btn btn-ghost btn-sm" onClick={()=>setPage('apps')}><Plus size={13}/></button>
        </div>
      </div>

      {(chat?.role||chat?.task) && (
        <div style={{ padding:'8px 20px',background:'var(--accent-dim)',borderBottom:'1px solid rgba(204,120,92,0.15)',display:'flex',alignItems:'center',gap:'8px',fontSize:'12px',color:'var(--text-secondary)' }}>
          <Bot size={13} style={{ color:'var(--accent)',flexShrink:0 }}/>
          {chat.role && <span><strong>Rol:</strong> {chat.role}</span>}
          {chat.role && chat.task && <span style={{ color:'var(--text-tertiary)' }}>·</span>}
          {chat.task && <span><strong>Vazifa:</strong> {chat.task}</span>}
        </div>
      )}

      <div className="chat-messages">
        {messages.length === 0 && !streaming ? (
          <div style={{ display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',flex:1,gap:'12px',color:'var(--text-tertiary)',padding:'40px 20px' }}>
            <div style={{ width:'48px',height:'48px',borderRadius:'12px',background:'var(--accent-dim)',border:'1px solid rgba(204,120,92,0.2)',display:'flex',alignItems:'center',justifyContent:'center' }}>
              <Bot size={22} style={{ color:'var(--accent)' }}/>
            </div>
            <div style={{ textAlign:'center' }}>
              <p style={{ fontWeight:600,color:'var(--text-secondary)',marginBottom:'4px' }}>{settings.appName} tayyor</p>
              <p style={{ fontSize:'13px' }}>{activeApps.length>0 ? `${activeApps.map(a=>APP_DEFINITIONS.find(d=>d.id===a.id)?.name).join(', ')} bilan ishlashga tayyor` : 'Savolingizni yozing'}</p>
            </div>
          </div>
        ) : (
          <>
            {messages.map((msg,i) => <Message key={i} msg={msg}/>)}
            {streaming && (
              <div className="message">
                <div className="message-avatar msg-ai-avatar"><Bot size={13}/></div>
                <div className="message-bubble" style={{ whiteSpace:'pre-wrap' }}>{streaming}<span style={{ display:'inline-block',width:'2px',height:'14px',background:'var(--accent)',marginLeft:'2px',animation:'pulse 1s ease infinite',verticalAlign:'text-bottom' }}/></div>
              </div>
            )}
            {loading && !streaming && (
              <div className="message">
                <div className="message-avatar msg-ai-avatar"><Bot size={13}/></div>
                <div className="message-bubble" style={{ display:'flex',gap:'4px',padding:'14px 16px' }}>
                  {[0,1,2].map(i=><div key={i} style={{ width:'7px',height:'7px',borderRadius:'50%',background:'var(--accent)',animation:'pulse 1.4s ease infinite',animationDelay:`${i*0.2}s`,opacity:0.7 }}/>)}
                </div>
              </div>
            )}
          </>
        )}
        <div ref={messagesEndRef}/>
      </div>

      <div className="chat-input-area">
        <div className="chat-input-box">
          <textarea ref={textareaRef} className="chat-textarea" placeholder={`${settings.appName} ga yozing...`} value={input} onChange={e=>{setInput(e.target.value);autoResize(e);}} onKeyDown={handleKeyDown} rows={1}/>
          <button className="chat-send-btn" onClick={sendMessage} disabled={!input.trim()||loading}><Send size={14}/></button>
        </div>
        <p style={{ textAlign:'center',fontSize:'11px',color:'var(--text-tertiary)',marginTop:'8px' }}>Enter — yuborish · Shift+Enter — yangi qator</p>
      </div>

      {showRoleModal && (
        <div className="modal-backdrop" onClick={e=>e.target===e.currentTarget&&setShowRoleModal(false)}>
          <div className="modal animate-up">
            <div className="modal-header">
              <span className="modal-title">AI rol va vazifasi</span>
              <button className="modal-close" onClick={()=>setShowRoleModal(false)}><X size={18}/></button>
            </div>
            <div className="modal-body">
              <div style={{ display:'flex',flexDirection:'column',gap:'14px' }}>
                <div className="form-group">
                  <label className="input-label">AI roli</label>
                  <input className="input" placeholder="Masalan: Marketing mutaxassisi" value={roleInput} onChange={e=>setRoleInput(e.target.value)}/>
                </div>
                <div className="form-group">
                  <label className="input-label">Asosiy vazifa</label>
                  <textarea className="input" placeholder="Masalan: Foydalanuvchilarga yordam berish..." value={taskInput} onChange={e=>setTaskInput(e.target.value)} rows={3} style={{ resize:'vertical' }}/>
                </div>
                <div style={{ display:'flex',gap:'8px' }}>
                  <button className="btn btn-ghost" style={{ flex:1,justifyContent:'center' }} onClick={()=>setShowRoleModal(false)}>Bekor</button>
                  <button className="btn btn-primary" style={{ flex:2,justifyContent:'center' }} onClick={saveRole}><Check size={14}/> Saqlash</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
