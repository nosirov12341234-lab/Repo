import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../utils/api';
import { Shield, Users, Bot, Plus, Trash2, Check, X, Upload, Eye, EyeOff, AlertTriangle, Save, Play, RefreshCw } from 'lucide-react';

const ADMIN_SECRET = 'AIPIPPS_ADMIN_2024';

function AdminGuard({ children }) {
  const [secret, setSecret] = useState('');
  const [show, setShow] = useState(false);
  const [verified, setVerified] = useState(() => sessionStorage.getItem('admin_v') === '1');
  const [attempts, setAttempts] = useState(0);
  const [locked, setLocked] = useState(false);
  const [error, setError] = useState('');

  const verify = () => {
    if (locked) return;
    if (secret === ADMIN_SECRET) { sessionStorage.setItem('admin_v', '1'); setVerified(true); }
    else {
      const a = attempts + 1; setAttempts(a);
      setError(`Noto'g'ri. ${3 - a} ta urinish qoldi.`);
      if (a >= 3) { setLocked(true); setTimeout(() => { setLocked(false); setAttempts(0); setError(''); }, 30000); }
    }
  };

  if (verified) return children;

  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', padding: '20px' }}>
      <div style={{ width: '100%', maxWidth: '360px' }}>
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <div style={{ width: '52px', height: '52px', borderRadius: '14px', background: 'rgba(251,191,36,0.1)', border: '1px solid rgba(251,191,36,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px' }}>
            <Shield size={24} style={{ color: 'var(--warning)' }}/>
          </div>
          <h2 style={{ fontSize: '18px', fontWeight: 700, marginBottom: '4px' }}>Admin Panel</h2>
          <p style={{ color: 'var(--text-tertiary)', fontSize: '13px' }}>Maxfiy kalit kiriting</p>
        </div>
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {locked
            ? <div style={{ textAlign: 'center', padding: '12px', background: 'var(--danger-dim)', borderRadius: '8px' }}>
                <AlertTriangle size={18} style={{ color: 'var(--danger)', marginBottom: '6px' }}/>
                <p style={{ fontSize: '13px', color: 'var(--danger)' }}>30 soniya bloklangan</p>
              </div>
            : <>
                <div className="form-group">
                  <label className="input-label">Kalit</label>
                  <div style={{ position: 'relative' }}>
                    <input className="input" type={show ? 'text' : 'password'} placeholder="Admin kaliti" value={secret}
                      onChange={e => { setSecret(e.target.value); setError(''); }} onKeyDown={e => e.key === 'Enter' && verify()} style={{ paddingRight: '42px' }} autoFocus />
                    <button type="button" onClick={() => setShow(s => !s)} style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-tertiary)', cursor: 'pointer' }}>
                      {show ? <EyeOff size={15}/> : <Eye size={15}/>}
                    </button>
                  </div>
                  {error && <span className="form-error">{error}</span>}
                </div>
                <button className="btn btn-lg" style={{ width: '100%', justifyContent: 'center', background: 'linear-gradient(135deg, #d97706, #f59e0b)', color: 'white', border: 'none' }} onClick={verify}>
                  <Shield size={15}/> Kirish
                </button>
              </>
          }
        </div>
      </div>
    </div>
  );
}

export default function AdminPanel() {
  const { settings, updateSettings, loadModels } = useApp();
  const [tab, setTab] = useState('branding');
  const [models, setModels] = useState([]);
  const [users, setUsers] = useState([]);
  const [stats, setStats] = useState(null);
  const [templates, setTemplates] = useState([]);
  const [showAddModel, setShowAddModel] = useState(false);
  const [newModel, setNewModel] = useState({ name: '', provider: 'gemini', model_id: '', api_key: '', base_url: '', is_active: true, is_default: false });
  const [showKey, setShowKey] = useState({});
  const [testing, setTesting] = useState(null);
  const [testResult, setTestResult] = useState({});
  const [appName, setAppName] = useState(settings.appName);
  const [saved, setSaved] = useState('');
  const [loading, setLoading] = useState(false);
  const logoRef = useRef(null);

  useEffect(() => { loadData(); }, [tab]);

  const loadData = async () => {
    try {
      if (tab === 'models' || tab === 'branding') {
        const m = await api.adminModels();
        setModels(m);
        const t = await api.adminProviderTemplates();
        setTemplates(t);
      }
      if (tab === 'users') {
        const u = await api.adminUsers();
        setUsers(u);
      }
      if (tab === 'branding') {
        const s = await api.adminStats();
        setStats(s);
      }
    } catch {}
  };

  const handleAddModel = async () => {
    if (!newModel.name || !newModel.model_id || !newModel.api_key) {
      alert("Nom, Model ID va API key majburiy"); return;
    }
    setLoading(true);
    try {
      await api.adminAddModel(newModel);
      setShowAddModel(false);
      setNewModel({ name: '', provider: 'gemini', model_id: '', api_key: '', base_url: '', is_active: true, is_default: false });
      await loadData();
      await loadModels();
    } catch (e) { alert(e.message); }
    setLoading(false);
  };

  const handleDeleteModel = async (id) => {
    if (!window.confirm("Modelni o'chirilsinmi?")) return;
    await api.adminDeleteModel(id);
    await loadData();
    await loadModels();
  };

  const handleToggleModel = async (id, is_active) => {
    await api.adminUpdateModel(id, { is_active: !is_active });
    await loadData();
    await loadModels();
  };

  const handleSetDefault = async (id) => {
    await api.adminUpdateModel(id, { is_default: true });
    await loadData();
    await loadModels();
  };

  const handleTestModel = async (id) => {
    setTesting(id);
    const res = await api.adminTestModel(id);
    setTestResult(r => ({ ...r, [id]: res }));
    setTesting(null);
  };

  const handleToggleUser = async (id) => {
    await api.adminToggleUser(id);
    await loadData();
  };

  const handleDeleteUser = async (id) => {
    if (!window.confirm("Foydalanuvchini o'chirilsinmi?")) return;
    await api.adminDeleteUser(id);
    await loadData();
  };

  const saveBranding = () => {
    updateSettings({ appName });
    setSaved('ok');
    setTimeout(() => setSaved(''), 2000);
  };

  const handleLogo = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => updateSettings({ appLogo: ev.target.result });
    reader.readAsDataURL(file);
  };

  const applyTemplate = (t) => {
    setNewModel(m => ({ ...m, provider: t.provider, model_id: t.model_id, name: t.name }));
  };

  const PROVIDERS = ['gemini', 'anthropic', 'openai', 'deepseek', 'mistral', 'groq', 'ollama'];

  return (
    <AdminGuard>
      <div className="page-content animate-fade">
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '24px' }}>
          <Shield size={20} style={{ color: 'var(--warning)' }}/>
          <h1 style={{ fontSize: '20px', fontWeight: 700 }}>Admin Panel</h1>
          <span className="badge badge-orange">Admin</span>
          {stats && (
            <div style={{ marginLeft: 'auto', display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
              {[['Userlar', stats.users], ['Chatlar', stats.chats], ['Xabarlar', stats.messages], ['Modellar', stats.active_models]].map(([k, v]) => (
                <div key={k} style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: '16px', fontWeight: 700, color: 'var(--accent)' }}>{v}</div>
                  <div style={{ fontSize: '10px', color: 'var(--text-tertiary)' }}>{k}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="tabs" style={{ marginBottom: '24px' }}>
          {[['branding', '🎨 Branding'], ['models', '🤖 AI Modellar'], ['users', '👥 Userlar']].map(([k, l]) => (
            <button key={k} className={`tab ${tab === k ? 'active' : ''}`} onClick={() => setTab(k)}>{l}</button>
          ))}
        </div>

        {/* BRANDING */}
        {tab === 'branding' && (
          <div style={{ maxWidth: '560px', display: 'flex', flexDirection: 'column', gap: '16px', animation: 'fadeIn 0.2s ease' }}>
            <div className="card">
              <h3 style={{ fontWeight: 600, marginBottom: '16px' }}>Logo</h3>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flexWrap: 'wrap' }}>
                <div style={{ width: '64px', height: '64px', borderRadius: '14px', background: settings.appLogo ? 'transparent' : 'var(--accent-dim)', border: '1px solid var(--border-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
                  {settings.appLogo
                    ? <img src={settings.appLogo} alt="logo" style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
                    : <span style={{ fontSize: '26px', fontWeight: 800, color: 'var(--accent)' }}>{appName?.charAt(0)}</span>
                  }
                </div>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button className="btn btn-secondary btn-sm" onClick={() => logoRef.current?.click()}><Upload size={13}/> Yuklash</button>
                  {settings.appLogo && <button className="btn btn-danger btn-sm" onClick={() => updateSettings({ appLogo: null })}><X size={13}/></button>}
                </div>
                <input ref={logoRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleLogo}/>
              </div>
            </div>
            <div className="card">
              <h3 style={{ fontWeight: 600, marginBottom: '16px' }}>Ilova nomi</h3>
              <div className="form-group" style={{ marginBottom: '14px' }}>
                <label className="input-label">Nom</label>
                <input className="input" value={appName} onChange={e => setAppName(e.target.value)} placeholder="AI PIPS"/>
              </div>
              <button className="btn btn-primary" onClick={saveBranding}>
                {saved ? <><Check size={14}/> Saqlandi</> : <><Save size={14}/> Saqlash</>}
              </button>
            </div>
          </div>
        )}

        {/* MODELS */}
        {tab === 'models' && (
          <div style={{ maxWidth: '800px', animation: 'fadeIn 0.2s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <p style={{ color: 'var(--text-tertiary)', fontSize: '13px' }}>AI modellarni qo'shish, o'chirish, API key kiritish</p>
              <button className="btn btn-primary btn-sm" onClick={() => setShowAddModel(true)}><Plus size={13}/> Model qo'shish</button>
            </div>

            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <table className="table">
                <thead>
                  <tr><th>Model</th><th>Provider</th><th>Default</th><th>Holat</th><th>Test</th><th>Amal</th></tr>
                </thead>
                <tbody>
                  {models.map(m => (
                    <tr key={m.id}>
                      <td>
                        <div style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{m.name}</div>
                        <div style={{ fontSize: '11px', color: 'var(--text-tertiary)', fontFamily: 'monospace' }}>{m.model_id}</div>
                        {!m.has_key && <span className="badge badge-red" style={{ marginTop: '4px' }}>API key yo'q</span>}
                      </td>
                      <td><span className="badge badge-blue">{m.provider}</span></td>
                      <td>
                        {m.is_default
                          ? <span className="badge badge-green">Default</span>
                          : <button className="btn btn-ghost btn-sm" style={{ fontSize: '11px' }} onClick={() => handleSetDefault(m.id)}>Default qil</button>
                        }
                      </td>
                      <td>
                        <label className="toggle">
                          <input type="checkbox" checked={m.is_active} onChange={() => handleToggleModel(m.id, m.is_active)}/>
                          <span className="toggle-slider"/>
                        </label>
                      </td>
                      <td>
                        <button className="btn btn-secondary btn-sm" onClick={() => handleTestModel(m.id)} disabled={testing === m.id || !m.has_key}>
                          {testing === m.id ? <span className="spinner" style={{ width: '12px', height: '12px', borderWidth: '2px' }}/> : <Play size={11}/>}
                        </button>
                        {testResult[m.id] && (
                          <div style={{ fontSize: '11px', marginTop: '4px', color: testResult[m.id].success ? 'var(--success)' : 'var(--danger)', maxWidth: '150px' }}>
                            {testResult[m.id].success ? '✓ ' + testResult[m.id].reply?.slice(0, 30) : '✗ ' + testResult[m.id].error?.slice(0, 30)}
                          </div>
                        )}
                      </td>
                      <td>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDeleteModel(m.id)}><Trash2 size={12}/></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Add Model Modal */}
            {showAddModel && (
              <div className="modal-backdrop" onClick={e => e.target === e.currentTarget && setShowAddModel(false)}>
                <div className="modal animate-up" style={{ maxWidth: '520px' }}>
                  <div className="modal-header">
                    <span className="modal-title">AI Model qo'shish</span>
                    <button className="modal-close" onClick={() => setShowAddModel(false)}><X size={18}/></button>
                  </div>
                  <div className="modal-body">
                    {/* Tayyor shablonlar */}
                    <div style={{ marginBottom: '16px' }}>
                      <div className="input-label" style={{ marginBottom: '8px' }}>Tayyor shablonlar</div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                        {templates.map(t => (
                          <button key={t.model_id} className="btn btn-ghost btn-sm" style={{ fontSize: '11px' }} onClick={() => applyTemplate(t)}>
                            {t.name}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="divider"/>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      <div className="form-row">
                        <div className="form-group">
                          <label className="input-label">Ko'rsatma nomi *</label>
                          <input className="input" placeholder="GPT-4o" value={newModel.name} onChange={e => setNewModel(m => ({ ...m, name: e.target.value }))}/>
                        </div>
                        <div className="form-group">
                          <label className="input-label">Provider *</label>
                          <select className="input" value={newModel.provider} onChange={e => setNewModel(m => ({ ...m, provider: e.target.value }))}>
                            {PROVIDERS.map(p => <option key={p} value={p}>{p}</option>)}
                          </select>
                        </div>
                      </div>
                      <div className="form-group">
                        <label className="input-label">Model ID *</label>
                        <input className="input" placeholder="gpt-4o" value={newModel.model_id} onChange={e => setNewModel(m => ({ ...m, model_id: e.target.value }))}/>
                      </div>
                      <div className="form-group">
                        <label className="input-label">API Key *</label>
                        <div style={{ position: 'relative' }}>
                          <input className="input" type={showKey.new ? 'text' : 'password'} placeholder="sk-..." value={newModel.api_key}
                            onChange={e => setNewModel(m => ({ ...m, api_key: e.target.value }))} style={{ paddingRight: '42px' }}/>
                          <button type="button" onClick={() => setShowKey(s => ({ ...s, new: !s.new }))}
                            style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-tertiary)', cursor: 'pointer' }}>
                            {showKey.new ? <EyeOff size={14}/> : <Eye size={14}/>}
                          </button>
                        </div>
                      </div>
                      <div className="form-group">
                        <label className="input-label">Base URL (ixtiyoriy — custom endpoint uchun)</label>
                        <input className="input" placeholder="https://api.example.com/v1" value={newModel.base_url} onChange={e => setNewModel(m => ({ ...m, base_url: e.target.value }))}/>
                        <span className="form-hint">DeepSeek, Ollama, yoki custom API uchun</span>
                      </div>
                      <div style={{ display: 'flex', gap: '12px' }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '13px' }}>
                          <input type="checkbox" checked={newModel.is_active} onChange={e => setNewModel(m => ({ ...m, is_active: e.target.checked }))}/> Faol
                        </label>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '13px' }}>
                          <input type="checkbox" checked={newModel.is_default} onChange={e => setNewModel(m => ({ ...m, is_default: e.target.checked }))}/> Default model
                        </label>
                      </div>
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <button className="btn btn-ghost" style={{ flex: 1, justifyContent: 'center' }} onClick={() => setShowAddModel(false)}>Bekor</button>
                        <button className="btn btn-primary" style={{ flex: 2, justifyContent: 'center' }} onClick={handleAddModel} disabled={loading}>
                          {loading ? <span className="spinner" style={{ width: '14px', height: '14px', borderWidth: '2px' }}/> : <><Plus size={14}/> Qo'shish</>}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* USERS */}
        {tab === 'users' && (
          <div style={{ maxWidth: '700px', animation: 'fadeIn 0.2s ease' }}>
            <p style={{ color: 'var(--text-tertiary)', fontSize: '13px', marginBottom: '16px' }}>Jami {users.length} ta foydalanuvchi</p>
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <table className="table">
                <thead><tr><th>Ism</th><th>Telefon</th><th>Rol</th><th>Holat</th><th>Sana</th><th>Amal</th></tr></thead>
                <tbody>
                  {users.map(u => (
                    <tr key={u.id}>
                      <td style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{u.name}</td>
                      <td style={{ fontFamily: 'monospace', fontSize: '12px' }}>{u.phone}</td>
                      <td>{u.is_admin ? <span className="badge badge-orange">Admin</span> : <span className="badge">User</span>}</td>
                      <td>
                        <label className="toggle">
                          <input type="checkbox" checked={u.is_active} onChange={() => handleToggleUser(u.id)}/>
                          <span className="toggle-slider"/>
                        </label>
                      </td>
                      <td style={{ fontSize: '12px' }}>{u.created_at?.split('T')[0]}</td>
                      <td>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDeleteUser(u.id)} disabled={u.is_admin}><Trash2 size={12}/></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </AdminGuard>
  );
}
