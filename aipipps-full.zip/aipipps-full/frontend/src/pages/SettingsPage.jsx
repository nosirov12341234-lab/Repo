import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { User, Bell, Shield, Trash2, Check, Upload, Moon } from 'lucide-react';

export default function SettingsPage() {
  const { user, settings, updateSettings, chats, deleteChat, connectedApps, disconnectApp } = useApp();
  const [saved, setSaved] = useState(false);
  const [name, setName] = useState(user?.name || '');
  const fileRef = useRef(null);

  const save = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const clearAllChats = () => {
    if (window.confirm("Barcha chatlar o'chirilsinmi?")) {
      chats.forEach(c => deleteChat(c.id));
    }
  };

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => updateSettings({ appLogo: ev.target.result });
    reader.readAsDataURL(file);
  };

  return (
    <div className="page-content animate-fade" style={{ maxWidth: '640px' }}>
      <div style={{ marginBottom: '28px' }}>
        <h1 style={{ fontSize: '22px', fontWeight: 700, marginBottom: '6px' }}>Sozlamalar</h1>
        <p style={{ color: 'var(--text-tertiary)', fontSize: '13px' }}>Profil va ilova sozlamalari</p>
      </div>

      {/* Profile */}
      <div className="card" style={{ marginBottom: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
          <User size={16} style={{ color: 'var(--accent)' }}/>
          <span style={{ fontWeight: 600 }}>Profil</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div className="form-group">
            <label className="input-label">Ism</label>
            <input className="input" value={name} onChange={e => setName(e.target.value)} placeholder="Ismingiz"/>
          </div>
          <div className="form-group">
            <label className="input-label">Telefon</label>
            <input className="input" value={user?.phone || ''} disabled style={{ opacity: 0.5 }}/>
            <span className="form-hint">Telefon raqamni o'zgartirish mumkin emas</span>
          </div>
          <button className="btn btn-primary" style={{ alignSelf: 'flex-start' }} onClick={save}>
            {saved ? <><Check size={14}/> Saqlandi</> : 'Saqlash'}
          </button>
        </div>
      </div>

      {/* Connected apps summary */}
      {connectedApps.length > 0 && (
        <div className="card" style={{ marginBottom: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <span style={{ fontWeight: 600 }}>Ulangan ilovalar ({connectedApps.length})</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {connectedApps.map(app => (
              <div key={app.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                <span style={{ fontSize: '13px', fontWeight: 500 }}>{app.id}</span>
                <button className="btn btn-danger btn-sm" onClick={() => disconnectApp(app.id)}>
                  <Trash2 size={12}/> Uzish
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Data */}
      <div className="card">
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
          <Trash2 size={16} style={{ color: 'var(--danger)' }}/>
          <span style={{ fontWeight: 600 }}>Ma'lumotlar</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: '13px', fontWeight: 500 }}>Barcha chatlarni o'chirish</div>
              <div style={{ fontSize: '11px', color: 'var(--text-tertiary)' }}>{chats.length} ta chat</div>
            </div>
            <button className="btn btn-danger btn-sm" onClick={clearAllChats} disabled={chats.length === 0}>
              <Trash2 size={12}/> O'chirish
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
