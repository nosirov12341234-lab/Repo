import React from 'react';
import { useApp } from '../context/AppContext';
import { Plus, MessageSquare, Unplug, ExternalLink, Zap } from 'lucide-react';
import { APP_DEFINITIONS } from './AppsPage';

export default function Dashboard({ setPage }) {
  const { connectedApps, disconnectApp, createChat, setActiveChat } = useApp();

  const startChat = (appIds) => {
    const id = createChat(appIds);
    setActiveChat(id);
    setPage('chat');
  };

  const startMultiChat = () => {
    if (connectedApps.length === 0) return;
    const id = createChat(connectedApps.map(a => a.id));
    setActiveChat(id);
    setPage('chat');
  };

  return (
    <div className="page-content animate-fade">
      {/* Header */}
      <div style={{ marginBottom: '28px' }}>
        <h1 style={{ fontSize: '22px', fontWeight: 700, marginBottom: '6px' }}>Ilovalar</h1>
        <p style={{ color: 'var(--text-tertiary)', fontSize: '13px' }}>
          Ulangan ilovalaringiz va ular bilan AI chat
        </p>
      </div>

      {connectedApps.length === 0 ? (
        <div className="empty-state">
          <Zap size={40} />
          <h3>Hali ilovalar ulanmagan</h3>
          <p>Telegram, Instagram, va boshqa ilovalarni ulab AI orqali boshqaring</p>
          <button className="btn btn-primary" style={{ marginTop: '8px' }} onClick={() => setPage('apps')}>
            <Plus size={15}/> Ilova qo'shish
          </button>
        </div>
      ) : (
        <>
          {/* Multi-chat */}
          {connectedApps.length > 1 && (
            <div style={{
              background: 'linear-gradient(135deg, rgba(204,120,92,0.08) 0%, rgba(204,120,92,0.03) 100%)',
              border: '1px solid rgba(204,120,92,0.2)',
              borderRadius: '12px',
              padding: '16px 20px',
              marginBottom: '20px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: '12px',
              flexWrap: 'wrap',
            }}>
              <div>
                <div style={{ fontWeight: 600, marginBottom: '3px' }}>Barcha ilovalar bilan chat</div>
                <div style={{ fontSize: '12px', color: 'var(--text-tertiary)' }}>
                  {connectedApps.length} ta ilova — bitta chat orqali boshqarish
                </div>
              </div>
              <button className="btn btn-primary" onClick={startMultiChat}>
                <MessageSquare size={14}/> Chat boshlash
              </button>
            </div>
          )}

          {/* Apps grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '12px' }}>
            {connectedApps.map(app => {
              const def = APP_DEFINITIONS.find(d => d.id === app.id);
              return (
                <div key={app.id} className="card" style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                  {/* App header */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div style={{
                      width: '40px', height: '40px',
                      borderRadius: '10px',
                      background: def?.color + '18' || 'var(--bg-tertiary)',
                      border: `1px solid ${def?.color + '30' || 'var(--border)'}`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: '20px', flexShrink: 0,
                    }}>
                      {def?.icon || '📱'}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontWeight: 600, fontSize: '14px' }}>{def?.name || app.id}</div>
                      {app.accountInfo && (
                        <div style={{ fontSize: '12px', color: 'var(--text-tertiary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                          {app.accountInfo.username || app.accountInfo.phone || 'Ulangan'}
                        </div>
                      )}
                    </div>
                    <span className="badge badge-green" style={{ flexShrink: 0 }}>
                      <span className="status-dot online" style={{ width: '6px', height: '6px' }}/>
                      Faol
                    </span>
                  </div>

                  {/* Actions */}
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <button
                      className="btn btn-secondary"
                      style={{ flex: 1, justifyContent: 'center', fontSize: '12px' }}
                      onClick={() => startChat([app.id])}
                    >
                      <MessageSquare size={13}/> Chat
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => disconnectApp(app.id)}
                      title="Uzish"
                    >
                      <Unplug size={13}/>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Add more */}
          <div
            className="card card-hover"
            style={{
              marginTop: '12px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              gap: '8px', color: 'var(--text-tertiary)',
              border: '1px dashed var(--border)',
              cursor: 'pointer', padding: '20px',
            }}
            onClick={() => setPage('apps')}
          >
            <Plus size={16}/> <span style={{ fontSize: '13px' }}>Yangi ilova qo'shish</span>
          </div>
        </>
      )}
    </div>
  );
}
