import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../utils/api';
import { Send, Check, ArrowRight, Shield, RefreshCw } from 'lucide-react';

export default function LoginPage() {
  const { login, settings } = useApp();
  const [step, setStep] = useState('phone');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resendTimer, setResendTimer] = useState(0);
  const [devCode, setDevCode] = useState('');

  const formatPhone = (val) => {
    let v = val.replace(/\D/g, '');
    if (!v.startsWith('998')) v = '998' + v.replace(/^998/, '');
    return '+' + v.slice(0, 12);
  };

  const startResendTimer = () => {
    setResendTimer(60);
    const t = setInterval(() => setResendTimer(n => { if (n <= 1) { clearInterval(t); return 0; } return n - 1; }), 1000);
  };

  const sendCode = async () => {
    const p = phone.replace(/\D/g, '');
    if (p.length < 11) { setError("To'liq telefon raqam kiriting"); return; }
    setLoading(true); setError('');
    try {
      const res = await api.sendOTP(phone);
      // dev_code faqat development da keladi
      if (res.dev_code) {
        setDevCode(res.dev_code);
        alert(`📬 Tasdiqlash kodi: ${res.dev_code}\n(Bu faqat test rejimida ko'rinadi)`);
      }
      setStep('code');
      startResendTimer();
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  };

  const verifyCode = async () => {
    if (code.length !== 6) { setError("6 raqamli kod kiriting"); return; }
    setLoading(true); setError('');
    try {
      // Agar name yo'q bo'lsa, name bosqichiga o'tamiz
      // Avval name so'raymiz
      setLoading(false);
      setStep('name');
    } catch (e) {
      setError(e.message);
      setLoading(false);
    }
  };

  const finish = async () => {
    if (!name.trim()) { setError("Ismingizni kiriting"); return; }
    setLoading(true); setError('');
    try {
      await login(phone, code, name.trim());
    } catch (e) {
      setError(e.message);
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
      <div style={{ position: 'fixed', inset: 0, opacity: 0.03, backgroundImage: 'linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)', backgroundSize: '40px 40px', pointerEvents: 'none' }} />

      <div style={{ width: '100%', maxWidth: '400px', animation: 'slideUp 0.4s ease' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <div style={{ width: '56px', height: '56px', background: 'var(--bg-secondary)', border: '1px solid var(--border-light)', borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', overflow: 'hidden' }}>
            {settings.appLogo
              ? <img src={settings.appLogo} alt="logo" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              : <span style={{ fontSize: '22px', fontWeight: 800, color: 'var(--accent)' }}>{settings.appName?.charAt(0) || 'A'}</span>
            }
          </div>
          <h1 style={{ fontSize: '22px', fontWeight: 700, marginBottom: '6px' }}>{settings.appName}</h1>
          <p style={{ color: 'var(--text-tertiary)', fontSize: '13px' }}>Telegram orqali kirish</p>
        </div>

        {/* Steps */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', marginBottom: '32px' }}>
          {['phone', 'code', 'name'].map((s, i) => (
            <React.Fragment key={s}>
              <div style={{
                width: '28px', height: '28px', borderRadius: '50%',
                background: step === s ? 'var(--accent)' : (['phone','code','name'].indexOf(step) > i ? 'var(--success-dim)' : 'var(--bg-tertiary)'),
                border: `1px solid ${step === s ? 'var(--accent)' : (['phone','code','name'].indexOf(step) > i ? 'rgba(74,222,128,0.3)' : 'var(--border)')}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '11px', fontWeight: 700,
                color: step === s ? 'white' : (['phone','code','name'].indexOf(step) > i ? 'var(--success)' : 'var(--text-tertiary)'),
                transition: 'all 0.3s',
              }}>
                {['phone','code','name'].indexOf(step) > i ? <Check size={12}/> : i+1}
              </div>
              {i < 2 && <div style={{ flex: 1, height: '1px', background: 'var(--border)', maxWidth: '40px' }} />}
            </React.Fragment>
          ))}
        </div>

        <div className="card" style={{ borderRadius: '16px', padding: '28px' }}>
          {step === 'phone' && (
            <div style={{ animation: 'slideUp 0.25s ease' }}>
              <h2 style={{ fontSize: '17px', fontWeight: 600, marginBottom: '6px' }}>Telefon raqam</h2>
              <p style={{ color: 'var(--text-tertiary)', fontSize: '13px', marginBottom: '20px' }}>Telegram botimiz tasdiqlash kodi yuboradi</p>
              <div className="form-group" style={{ marginBottom: '16px' }}>
                <label className="input-label">Telefon</label>
                <input className="input" type="tel" placeholder="+998 90 123 45 67" value={phone}
                  onChange={e => { setPhone(formatPhone(e.target.value)); setError(''); }}
                  onKeyDown={e => e.key === 'Enter' && sendCode()}
                  style={{ fontSize: '16px', letterSpacing: '0.5px' }} />
              </div>
              {error && <p className="form-error" style={{ marginBottom: '12px' }}>{error}</p>}
              <button className="btn btn-primary btn-lg" style={{ width: '100%', justifyContent: 'center' }} onClick={sendCode} disabled={loading}>
                {loading ? <span className="spinner" style={{ width: '16px', height: '16px', borderWidth: '2px' }} /> : <><Send size={15}/> Kod yuborish</>}
              </button>
            </div>
          )}

          {step === 'code' && (
            <div style={{ animation: 'slideUp 0.25s ease' }}>
              <h2 style={{ fontSize: '17px', fontWeight: 600, marginBottom: '6px' }}>Tasdiqlash kodi</h2>
              <p style={{ color: 'var(--text-tertiary)', fontSize: '13px', marginBottom: '20px' }}>
                <strong style={{ color: 'var(--text-primary)' }}>{phone}</strong> ga Telegram orqali kod yuborildi
              </p>
              <div className="form-group" style={{ marginBottom: '16px' }}>
                <label className="input-label">6 raqamli kod</label>
                <input className="input" type="text" inputMode="numeric" maxLength={6} placeholder="_ _ _ _ _ _"
                  value={code} onChange={e => { setCode(e.target.value.replace(/\D/g,'').slice(0,6)); setError(''); }}
                  onKeyDown={e => e.key === 'Enter' && verifyCode()}
                  style={{ fontSize: '24px', letterSpacing: '10px', textAlign: 'center', fontFamily: 'monospace' }} autoFocus />
              </div>
              {error && <p className="form-error" style={{ marginBottom: '12px' }}>{error}</p>}
              <button className="btn btn-primary btn-lg" style={{ width: '100%', justifyContent: 'center', marginBottom: '12px' }} onClick={verifyCode} disabled={loading}>
                {loading ? <span className="spinner" style={{ width: '16px', height: '16px', borderWidth: '2px' }} /> : <><Check size={15}/> Davom etish</>}
              </button>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <button className="btn btn-ghost btn-sm" onClick={() => { setStep('phone'); setCode(''); setError(''); }}>← Orqaga</button>
                <button className="btn btn-ghost btn-sm" onClick={sendCode} disabled={resendTimer > 0}>
                  <RefreshCw size={12}/> {resendTimer > 0 ? `${resendTimer}s` : 'Qayta'}
                </button>
              </div>
            </div>
          )}

          {step === 'name' && (
            <div style={{ animation: 'slideUp 0.25s ease' }}>
              <h2 style={{ fontSize: '17px', fontWeight: 600, marginBottom: '6px' }}>Ismingiz</h2>
              <p style={{ color: 'var(--text-tertiary)', fontSize: '13px', marginBottom: '20px' }}>Profilingiz uchun ism kiriting</p>
              <div className="form-group" style={{ marginBottom: '16px' }}>
                <label className="input-label">Ism</label>
                <input className="input" type="text" placeholder="Masalan: Botir" value={name}
                  onChange={e => { setName(e.target.value); setError(''); }}
                  onKeyDown={e => e.key === 'Enter' && finish()}
                  style={{ fontSize: '15px' }} autoFocus />
              </div>
              {error && <p className="form-error" style={{ marginBottom: '12px' }}>{error}</p>}
              <button className="btn btn-primary btn-lg" style={{ width: '100%', justifyContent: 'center' }} onClick={finish} disabled={loading}>
                {loading ? <span className="spinner" style={{ width: '16px', height: '16px', borderWidth: '2px' }} /> : <><ArrowRight size={15}/> Kirish</>}
              </button>
            </div>
          )}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', marginTop: '24px' }}>
          <Shield size={12} style={{ color: 'var(--text-tertiary)' }}/>
          <p style={{ color: 'var(--text-tertiary)', fontSize: '11px' }}>Ma'lumotlaringiz xavfsiz saqlanadi</p>
        </div>
      </div>
    </div>
  );
}
