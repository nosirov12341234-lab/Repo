const BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const getToken = () => localStorage.getItem('aipipps_token');

const req = async (method, path, body = null) => {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : null,
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Xatolik' }));
    throw new Error(err.detail || 'Xatolik');
  }
  return res.json();
};

export const api = {
  // Auth
  sendOTP: (phone) => req('POST', '/api/auth/send-otp', { phone }),
  verifyOTP: (phone, code, name) => req('POST', '/api/auth/verify-otp', { phone, code, name }),

  // AI
  getModels: () => req('GET', '/api/ai/models'),
  getChats: () => req('GET', '/api/ai/chats'),
  createChat: (data) => req('POST', '/api/ai/chats', data),
  sendMessage: (data) => req('POST', '/api/ai/chat', data),
  updateChat: (id, data) => req('PUT', `/api/ai/chats/${id}`, data),
  deleteChat: (id) => req('DELETE', `/api/ai/chats/${id}`),
  getMessages: (chatId) => req('GET', `/api/ai/chats/${chatId}/messages`),

  // Telegram
  telegramStart: (phone) => req('POST', '/api/telegram/connect/start', { phone }),
  telegramVerify: (phone, code, phone_code_hash, password) =>
    req('POST', '/api/telegram/connect/verify', { phone, code, phone_code_hash, password }),
  telegramConnections: () => req('GET', '/api/telegram/connections'),
  telegramDialogs: (connId) => req('GET', `/api/telegram/dialogs/${connId}`),
  telegramMessages: (connId, chatId) => req('GET', `/api/telegram/messages/${connId}/${chatId}`),
  telegramSend: (connId, username, message) =>
    req('POST', '/api/telegram/send', { connection_id: connId, chat_username: username, message }),
  telegramDisconnect: (connId) => req('DELETE', `/api/telegram/connections/${connId}`),

  // GitHub
  githubConnect: (token) => req('POST', '/api/github/connect', { token }),
  githubConnections: () => req('GET', '/api/github/connections'),
  githubRepos: (connId) => req('GET', `/api/github/repos/${connId}`),
  githubIssues: (connId, owner, repo) => req('GET', `/api/github/repos/${connId}/${owner}/${repo}/issues`),
  githubCreateIssue: (connId, owner, repo, title, body) =>
    req('POST', '/api/github/issues', { connection_id: connId, owner, repo, title, body }),

  // Google
  googleAuthUrl: () => req('GET', '/api/google/auth-url'),
  googleConnections: () => req('GET', '/api/google/connections'),
  googleSheetRead: (connId, sheetId, range) => req('GET', `/api/google/sheets/${connId}/${sheetId}?range=${range}`),
  googleCalendarEvents: (connId) => req('GET', `/api/google/calendar/${connId}/events`),
  gmailInbox: (connId) => req('GET', `/api/google/gmail/${connId}/inbox`),

  // Admin
  adminStats: () => req('GET', '/api/admin/stats'),
  adminModels: () => req('GET', '/api/admin/models'),
  adminAddModel: (data) => req('POST', '/api/admin/models', data),
  adminUpdateModel: (id, data) => req('PUT', `/api/admin/models/${id}`, data),
  adminDeleteModel: (id) => req('DELETE', `/api/admin/models/${id}`),
  adminTestModel: (id) => req('POST', `/api/admin/models/${id}/test`),
  adminProviderTemplates: () => req('GET', '/api/admin/provider-templates'),
  adminUsers: () => req('GET', '/api/admin/users'),
  adminToggleUser: (id) => req('PUT', `/api/admin/users/${id}/toggle`),
  adminDeleteUser: (id) => req('DELETE', `/api/admin/users/${id}`),

  // Stream chat
  streamChat: async (data, onChunk, onDone) => {
    const token = getToken();
    const res = await fetch(`${BASE}/api/ai/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ ...data, stream: true }),
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let chatId = null;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const lines = decoder.decode(value).split('\n');
      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const d = JSON.parse(line.slice(6));
            if (d.chat_id) chatId = d.chat_id;
            if (d.chunk) onChunk(d.chunk);
            if (d.done) onDone(chatId);
          } catch {}
        }
      }
    }
  },
};
