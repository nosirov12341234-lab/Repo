import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../utils/api';

const AppContext = createContext(null);
export const useApp = () => useContext(AppContext);

const DEFAULT_SETTINGS = {
  appName: 'AI PIPS',
  appLogo: null,
};

export function AppProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('aipipps_user')); } catch { return null; }
  });
  const [settings, setSettings] = useState(() => {
    try { return JSON.parse(localStorage.getItem('aipipps_settings')) || DEFAULT_SETTINGS; } catch { return DEFAULT_SETTINGS; }
  });
  const [models, setModels] = useState([]);
  const [chats, setChats] = useState([]);
  const [activeChat, setActiveChat] = useState(null);
  const [selectedModel, setSelectedModel] = useState('gemini-2.5-flash');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [connectedApps, setConnectedApps] = useState(() => {
    try { return JSON.parse(localStorage.getItem('aipipps_apps')) || []; } catch { return []; }
  });

  const isAdmin = user?.is_admin || false;

  useEffect(() => {
    if (user) {
      loadModels();
      loadChats();
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('aipipps_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('aipipps_apps', JSON.stringify(connectedApps));
  }, [connectedApps]);

  const loadModels = async () => {
    try {
      const data = await api.getModels();
      setModels(data);
      const def = data.find(m => m.is_default);
      if (def) setSelectedModel(def.id);
    } catch {}
  };

  const loadChats = async () => {
    try {
      const data = await api.getChats();
      setChats(data);
    } catch {}
  };

  const login = async (phone, code, name) => {
    const data = await api.verifyOTP(phone, code, name);
    localStorage.setItem('aipipps_token', data.token);
    localStorage.setItem('aipipps_user', JSON.stringify(data.user));
    setUser(data.user);
    return data;
  };

  const logout = () => {
    localStorage.removeItem('aipipps_token');
    localStorage.removeItem('aipipps_user');
    setUser(null);
    setChats([]);
    setActiveChat(null);
  };

  const updateSettings = (patch) => setSettings(s => ({ ...s, ...patch }));

  const createChat = async (appIds = [], title = null) => {
    const chat = await api.createChat({
      title: title || 'Yangi chat',
      app_ids: appIds,
      model_id: selectedModel,
    });
    await loadChats();
    setActiveChat(chat.id);
    return chat.id;
  };

  const updateChat = async (id, patch) => {
    await api.updateChat(id, patch);
    setChats(c => c.map(chat => chat.id === id ? { ...chat, ...patch } : chat));
  };

  const deleteChat = async (id) => {
    await api.deleteChat(id);
    setChats(c => c.filter(chat => chat.id !== id));
    if (activeChat === id) setActiveChat(null);
  };

  const connectApp = (app) => {
    setConnectedApps(a => {
      if (a.find(x => x.id === app.id)) return a;
      return [...a, { ...app, connectedAt: new Date().toISOString() }];
    });
  };

  const disconnectApp = (appId) => setConnectedApps(a => a.filter(x => x.id !== appId));

  return (
    <AppContext.Provider value={{
      user, isAdmin, settings, models, chats, activeChat, setActiveChat,
      selectedModel, setSelectedModel, sidebarOpen, setSidebarOpen,
      connectedApps, updateSettings, login, logout,
      createChat, updateChat, deleteChat,
      connectApp, disconnectApp,
      loadModels, loadChats,
    }}>
      {children}
    </AppContext.Provider>
  );
}
