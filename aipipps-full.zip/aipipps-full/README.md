# AI PIPS — To'liq loyiha

## Tuzilma

```
aipipps-full/
├── backend/                  # Python FastAPI
│   ├── app/
│   │   ├── main.py           # Asosiy app
│   │   ├── database.py       # SQLite models
│   │   ├── routers/
│   │   │   ├── auth.py       # OTP login
│   │   │   ├── ai.py         # AI chat + streaming
│   │   │   ├── telegram.py   # Pyrogram real akkount
│   │   │   ├── github.py     # GitHub API
│   │   │   ├── google.py     # Sheets/Calendar/Gmail
│   │   │   └── admin.py      # Admin panel API
│   │   ├── services/
│   │   │   └── ai_providers.py  # Gemini/Claude/GPT/DeepSeek/...
│   │   └── utils/auth.py     # JWT, OTP
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/                 # React
│   ├── src/
│   │   ├── App.jsx
│   │   ├── context/AppContext.jsx
│   │   ├── utils/api.js      # Backend API chaqiruvlar
│   │   ├── pages/
│   │   │   ├── LoginPage.jsx
│   │   │   ├── Dashboard.jsx
│   │   │   ├── ChatPage.jsx
│   │   │   ├── SettingsPage.jsx
│   │   │   └── AdminPanel.jsx
│   │   └── components/
│   │       ├── layout/Sidebar.jsx
│   │       └── apps/AppsPage.jsx
│   ├── package.json
│   ├── Dockerfile
│   └── .env.example
├── nginx/nginx.conf
├── docker-compose.yml
└── setup.sh                  # Bir buyruq bilan o'rnatish
```

---

## VPS ga o'rnatish (Ubuntu 20/22)

### 1. Fayllarni VPS ga yuklash
```bash
scp -r aipipps-full/ root@YOUR_VPS_IP:/opt/aipipps
ssh root@YOUR_VPS_IP
cd /opt/aipipps
```

### 2. .env fayllarni to'ldirish
```bash
cp backend/.env.example backend/.env
nano backend/.env
```

```env
SECRET_KEY=random_uzun_kalit_bu_yerni_ozgartiring
ADMIN_PHONE=+998XXXXXXXXX
ADMIN_SECRET=AIPIPPS_ADMIN_2024

GEMINI_API_KEY=AIzaSy_...          # aistudio.google.com dan oling (BEPUL)
DEFAULT_AI_PROVIDER=gemini
DEFAULT_AI_MODEL=gemini-2.5-flash

TELEGRAM_API_ID=12345678           # my.telegram.org dan oling
TELEGRAM_API_HASH=abcdef...        # my.telegram.org dan oling
TELEGRAM_BOT_TOKEN=123:ABC...      # @BotFather dan oling

GOOGLE_CLIENT_ID=xxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-xxx
GOOGLE_REDIRECT_URI=http://YOUR_VPS_IP/api/google/callback
```

```bash
cp frontend/.env.example frontend/.env
echo "REACT_APP_API_URL=http://YOUR_VPS_IP" > frontend/.env
```

### 3. Ishga tushirish
```bash
bash setup.sh
# Yoki qo'lda:
docker-compose up -d --build
```

### 4. Tayyor!
- 🌐 Sayt: `http://YOUR_VPS_IP`
- 📚 API: `http://YOUR_VPS_IP/api/docs`

---

## API kalitlarini qayerdan olish

| Xizmat | URL | Narx |
|--------|-----|------|
| Gemini | https://aistudio.google.com/apikey | **Bepul** |
| Telegram API | https://my.telegram.org | **Bepul** |
| Telegram Bot | @BotFather da /newbot | **Bepul** |
| GitHub Token | github.com/settings/tokens | **Bepul** |
| Google API | console.cloud.google.com | **Bepul** (quota) |
| Claude API | console.anthropic.com | Pullik |
| OpenAI | platform.openai.com | Pullik |
| DeepSeek | platform.deepseek.com | Arzon |
| Groq | console.groq.com | **Bepul** (tez!) |

---

## Admin panelga kirish
1. Telefon: `.env` dagi `ADMIN_PHONE`
2. Kalit: `AIPIPPS_ADMIN_2024`

### Admin panelda nima qilsa bo'ladi:
- ✅ Logo va nom o'zgartirish
- ✅ AI modellar qo'shish/o'chirish (Gemini, Claude, GPT, DeepSeek, Mistral, Groq, Ollama)
- ✅ Har bir model uchun API key kiritish
- ✅ Model test qilish (1 klik)
- ✅ Default model tanlash
- ✅ Foydalanuvchilarni boshqarish

---

## Yangi AI model qo'shish (Admin dan)
1. Admin Panel → 🤖 AI Modellar → "Model qo'shish"
2. Tayyor shablondan tanlang (GPT-4o, Claude, DeepSeek...)
3. API key kiriting
4. "Qo'shish" — shu bo'ldi!

---

## Foydali buyruqlar
```bash
docker-compose logs -f          # Loglar
docker-compose restart backend  # Backend restart
docker-compose down             # To'xtatish
docker-compose up -d            # Ishga tushirish
```
