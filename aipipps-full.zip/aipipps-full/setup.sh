#!/bin/bash
# AI PIPS — VPS ga o'rnatish skripti
# Ubuntu 20/22 uchun
# Ishlatish: bash setup.sh

set -e
echo "======================================"
echo "  AI PIPS — VPS O'rnatish"
echo "======================================"

# 1. Docker o'rnatish
if ! command -v docker &> /dev/null; then
    echo "[1/5] Docker o'rnatilmoqda..."
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
else
    echo "[1/5] Docker allaqachon o'rnatilgan ✓"
fi

# 2. Docker Compose o'rnatish
if ! command -v docker-compose &> /dev/null; then
    echo "[2/5] Docker Compose o'rnatilmoqda..."
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
else
    echo "[2/5] Docker Compose allaqachon o'rnatilgan ✓"
fi

# 3. .env fayl yaratish
echo "[3/5] .env fayl sozlanmoqda..."
if [ ! -f "backend/.env" ]; then
    cp backend/.env.example backend/.env
    echo ""
    echo "⚠️  backend/.env faylini to'ldiring:"
    echo "   - GEMINI_API_KEY"
    echo "   - TELEGRAM_API_ID va TELEGRAM_API_HASH"
    echo "   - TELEGRAM_BOT_TOKEN"
    echo "   - SECRET_KEY (ixtiyoriy, o'zgartirilishi tavsiya)"
    echo ""
fi

if [ ! -f "frontend/.env" ]; then
    cp frontend/.env.example frontend/.env
    VPS_IP=$(curl -s ifconfig.me 2>/dev/null || echo "localhost")
    echo "REACT_APP_API_URL=http://$VPS_IP" > frontend/.env
    echo "   Frontend API URL: http://$VPS_IP"
fi

# 4. data papka yaratish
mkdir -p backend/data
echo "[4/5] Papkalar yaratildi ✓"

# 5. Docker build va ishga tushirish
echo "[5/5] Docker containers ishga tushirilmoqda..."
docker-compose up -d --build

echo ""
echo "======================================"
echo "  ✅ AI PIPS muvaffaqiyatli o'rnatildi!"
echo "======================================"
VPS_IP=$(curl -s ifconfig.me 2>/dev/null || echo "localhost")
echo ""
echo "  🌐 Sayt:     http://$VPS_IP"
echo "  📚 API docs: http://$VPS_IP/api/docs"
echo ""
echo "  Admin kirish:"
echo "  📱 Telefon:  +998900000000 (.env da o'zgartiriladi)"
echo "  🔑 Kalit:    AIPIPPS_ADMIN_2024"
echo ""
echo "  Loglar ko'rish: docker-compose logs -f"
echo "  To'xtatish:     docker-compose down"
echo "======================================"
