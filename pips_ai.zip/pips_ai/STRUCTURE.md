# Pips AI — Loyiha Strukturasi

```
pips_ai/
│
├── main.py                          # Asosiy entry point (bot + userbot runner)
├── .env                             # Muhit o'zgaruvchilari (secrets)
├── .env.example                     # Namuna env fayli
├── requirements.txt                 # Barcha kutubxonalar
├── alembic.ini                      # Alembic konfiguratsiyasi
├── docker-compose.yml               # Docker Compose (Postgres + Redis)
│
├── config/
│   ├── __init__.py
│   └── settings.py                  # Pydantic BaseSettings (env yuklash)
│
├── database/
│   ├── __init__.py
│   ├── models.py                    # SQLAlchemy async ORM modellari
│   ├── session.py                   # Async engine va SessionFactory
│   └── crud.py                      # Barcha DB operatsiyalari (CRUD)
│
├── services/
│   ├── __init__.py
│   ├── ai_service.py                # Gemini Key Pool + Round-Robin + 429 handler
│   ├── subscription_service.py      # Majburiy kanal obuna tekshiruvi
│   └── stars_service.py             # Telegram Stars to'lov logikasi
│
├── bot/
│   ├── __init__.py
│   ├── router.py                    # Barcha handler routerlarni birlashtirish
│   │
│   ├── handlers/
│   │   ├── __init__.py
│   │   ├── start.py                 # /start, onboarding
│   │   ├── profile.py               # Profil, stars balans
│   │   ├── accounts.py              # Akkaunt ulash/o'chirish (Pyrogram auth)
│   │   └── admin.py                 # Admin panel barcha buyruqlari
│   │
│   ├── keyboards/
│   │   ├── __init__.py
│   │   ├── inline.py                # InlineKeyboardMarkup lari
│   │   └── reply.py                 # ReplyKeyboardMarkup lari
│   │
│   ├── middlewares/
│   │   ├── __init__.py
│   │   ├── auth.py                  # Foydalanuvchini DB ga auto-register
│   │   └── subscription.py          # Har so'rovda kanal obuna gate
│   │
│   └── filters/
│       ├── __init__.py
│       └── is_admin.py              # Admin filteri
│
├── userbot/
│   ├── __init__.py
│   ├── manager.py                   # Barcha faol Pyrogram clientlarini boshqarish
│   ├── engine.py                    # Smart Reply, Trigger, Sleep Mode logikasi
│   └── scheduler.py                 # Scheduled Posting (APScheduler)
│
├── utils/
│   ├── __init__.py
│   ├── logger.py                    # Structured logging (loguru)
│   └── redis_client.py              # Redis connection pool
│
├── sessions/                        # .session fayllar (Pyrogram) — gitignore'd
├── logs/                            # Log fayllar — gitignore'd
└── alembic/
    ├── env.py
    └── versions/                    # Migration fayllar
```
