"""
userbot/manager.py
==================
Barcha faol Pyrogram userbot clientlarini boshqarish.
Bot ishga tushganda DB dagi barcha faol akkauntlarni yuklaydi.
"""

from __future__ import annotations

import asyncio
from typing import Dict, Optional

from loguru import logger
from pyrogram import Client

from config.settings import settings
from database.crud import get_all_active_accounts, get_account
from database.session import AsyncSessionFactory
from database.models import LinkedAccount


def _parse_proxy(proxy_url: Optional[str]) -> Optional[dict]:
    """
    'socks5://user:pass@host:1080' → Pyrogram proxy dict.
    """
    if not proxy_url:
        return None
    try:
        from urllib.parse import urlparse
        p = urlparse(proxy_url)
        scheme = p.scheme.lower()
        proxy_type = "SOCKS5" if "socks5" in scheme else "HTTP"
        return {
            "scheme": proxy_type,
            "hostname": p.hostname,
            "port": p.port,
            "username": p.username,
            "password": p.password,
        }
    except Exception as e:
        logger.warning(f"Proxy parse xatosi ({proxy_url}): {e}")
        return None


class UserbotManager:
    """
    Singleton: barcha faol Pyrogram clientlarini saqlaydi va boshqaradi.
    """

    def __init__(self) -> None:
        # account_id → Client
        self._clients: Dict[int, Client] = {}
        self._lock = asyncio.Lock()

    async def start_all(self) -> None:
        """
        Dastur ishga tushganda DB dagi barcha faol akkauntlarni yuklaydi.
        """
        async with AsyncSessionFactory() as session:
            accounts = await get_all_active_accounts(session)

        logger.info(f"Userbot manager: {len(accounts)} ta faol akkaunt topildi.")

        tasks = [self.start_account(acc.id, acc) for acc in accounts]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for acc, result in zip(accounts, results):
            if isinstance(result, Exception):
                logger.error(f"Akkaunt #{acc.id} ({acc.phone_number}) ishga tushmadi: {result}")

    async def start_account(
        self,
        account_id: int,
        account: Optional[LinkedAccount] = None,
    ) -> None:
        """Bitta akkauntni ishga tushiradi."""
        async with self._lock:
            if account_id in self._clients:
                logger.debug(f"Akkaunt #{account_id} allaqachon ishlamoqda.")
                return

        if account is None:
            async with AsyncSessionFactory() as session:
                account = await get_account(session, account_id)

        if not account or not account.session_file:
            logger.warning(f"Akkaunt #{account_id}: session fayl yo'q, o'tkazib yuborildi.")
            return

        proxy = _parse_proxy(account.proxy_url)
        session_path = f"{settings.SESSIONS_DIR}/{account.session_file}"

        client = Client(
            name=session_path,
            api_id=6,
            api_hash="eb06d4abfb49dc3eeb1aeb98ae0f581e",
            proxy=proxy,
            no_updates=False,
        )

        # Smart reply handlerini ro'yxatdan o'tkazish
        from userbot.engine import register_handlers
        register_handlers(client, account_id)

        try:
            await client.start()
            async with self._lock:
                self._clients[account_id] = client
            logger.success(f"Akkaunt #{account_id} ({account.phone_number}) ishga tushdi ✓")
        except Exception as e:
            logger.error(f"Akkaunt #{account_id} ishga tushmadi: {e}")
            raise

    async def stop_account(self, account_id: int) -> None:
        """Bitta akkauntni to'xtatadi."""
        async with self._lock:
            client = self._clients.pop(account_id, None)

        if client:
            try:
                await client.stop()
                logger.info(f"Akkaunt #{account_id} to'xtatildi.")
            except Exception as e:
                logger.warning(f"Akkaunt #{account_id} to'xtatishda xato: {e}")

    async def restart_account(self, account_id: int) -> None:
        """Akkauntni qayta ishga tushiradi (proxy yangilanishida)."""
        await self.stop_account(account_id)
        await asyncio.sleep(1)
        await self.start_account(account_id)

    async def stop_all(self) -> None:
        """Barcha clientlarni to'xtatadi (shutdown)."""
        async with self._lock:
            account_ids = list(self._clients.keys())

        logger.info(f"Barcha {len(account_ids)} ta userbot to'xtatilmoqda...")
        await asyncio.gather(
            *[self.stop_account(aid) for aid in account_ids],
            return_exceptions=True,
        )

    def get_client(self, account_id: int) -> Optional[Client]:
        return self._clients.get(account_id)

    def is_running(self, account_id: int) -> bool:
        return account_id in self._clients

    def active_count(self) -> int:
        return len(self._clients)


# Global singleton
userbot_manager = UserbotManager()
