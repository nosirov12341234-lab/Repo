"""
userbot/engine.py
=================
Userbot uchun Smart Reply logikasi:
  - Trigger so'z filtri
  - Smart Sleep Mode (Anti-Ban)
  - Random delay (3-7 soniya)
  - Human-in-the-loop ogohlantirish
  - Yozayotgan holati (typing...)
"""

from __future__ import annotations

import asyncio
import random
from datetime import datetime, timezone

from loguru import logger
from pyrogram import Client, filters
from pyrogram.types import Message as PyroMessage

from config.settings import settings
from database.crud import get_account, increment_account_messages
from database.models import AccountStatus
from database.session import AsyncSessionFactory
from services.ai_service import AIService


# ─── Yordamchi funksiyalar ───────────────────────────────────────────────────

def _is_sleeping(sleep_start: int, sleep_end: int) -> bool:
    """Hozirgi vaqt uxlash oralig'ida ekanligini tekshiradi (UTC+5)."""
    # O'zbekiston vaqti = UTC+5
    now_hour = (datetime.now(timezone.utc).hour + 5) % 24

    if sleep_start > sleep_end:
        # Masalan: 23:00 → 07:00 (tungi rejim)
        return now_hour >= sleep_start or now_hour < sleep_end
    else:
        return sleep_start <= now_hour < sleep_end


def _has_trigger(text: str, keywords: str | None) -> bool:
    """Xabarda trigger so'z bor-yo'qligini tekshiradi."""
    if not keywords:
        return True  # Trigger yo'q = barcha xabarlarga javob

    kw_list = [k.strip().lower() for k in keywords.split(",") if k.strip()]
    text_lower = text.lower()
    return any(kw in text_lower for kw in kw_list)


# ─── Handler ro'yxatdan o'tkazish ───────────────────────────────────────────

def register_handlers(client: Client, account_id: int) -> None:
    """Pyrogram clientga barcha handlerlarni biriktiradi."""

    @client.on_message(
        filters.private & ~filters.me & ~filters.bot
    )
    async def handle_private_message(c: Client, message: PyroMessage) -> None:
        await _process_message(c, message, account_id, is_group=False)

    @client.on_message(
        filters.group & filters.mentioned
    )
    async def handle_group_mention(c: Client, message: PyroMessage) -> None:
        await _process_message(c, message, account_id, is_group=True)


async def _process_message(
    client: Client,
    message: PyroMessage,
    account_id: int,
    is_group: bool,
) -> None:
    """
    Xabarni qayta ishlash:
    1. Akkaunt ma'lumotlarini yuklash
    2. Sleep mode tekshiruvi
    3. Trigger tekshiruvi
    4. AI dan javob olish
    5. Random delay + typing
    6. Javob yuborish
    7. Human-in-the-loop tekshiruvi
    """
    text = message.text or message.caption or ""
    if not text.strip():
        return

    async with AsyncSessionFactory() as session:
        account = await get_account(session, account_id)

    if not account:
        logger.warning(f"Akkaunt #{account_id} topilmadi, xabar o'tkazib yuborildi.")
        return

    # Avtomatik javob o'chirilganmi?
    if not account.is_auto_reply:
        return

    # Akkaunt faol emasmi?
    if account.status != AccountStatus.ACTIVE:
        return

    # ── Sleep Mode tekshiruvi ─────────────────────────────────────────────────
    if _is_sleeping(account.sleep_start_hour, account.sleep_end_hour):
        logger.debug(f"Akkaunt #{account_id} uxlash rejimida, xabar o'tkazildi.")
        return

    # ── Trigger so'z tekshiruvi ───────────────────────────────────────────────
    if not _has_trigger(text, account.trigger_keywords):
        logger.debug(f"Akkaunt #{account_id}: trigger topilmadi, xabar o'tkazildi.")
        return

    telegram_chat_id = message.chat.id

    logger.info(
        f"[Acc#{account_id}] Xabar qabul qilindi | "
        f"chat={telegram_chat_id} | "
        f"{'guruh' if is_group else 'shaxsiy'}"
    )

    try:
        # ── AI javob olish ────────────────────────────────────────────────────
        async with AsyncSessionFactory() as session:
            ai = AIService(session)
            response_text, needs_human = await ai.chat(
                account_id=account_id,
                telegram_chat_id=telegram_chat_id,
                user_message=text,
                system_prompt=account.system_prompt,
            )
            await increment_account_messages(session, account_id)
            await session.commit()

        # ── Random delay (Anti-Ban) ───────────────────────────────────────────
        delay = random.uniform(3.0, 7.0)
        logger.debug(f"Akkaunt #{account_id}: {delay:.1f}s kechikish...")

        # Typing animatsiyasini ko'rsatish
        async with client.action(telegram_chat_id, "typing"):
            await asyncio.sleep(delay)

        # ── Javob yuborish ────────────────────────────────────────────────────
        await message.reply(response_text)

        logger.success(
            f"[Acc#{account_id}] Javob yuborildi → chat={telegram_chat_id} "
            f"| {len(response_text)} belgi"
        )

        # ── Human-in-the-loop ─────────────────────────────────────────────────
        if needs_human:
            await _notify_owner(account, telegram_chat_id, text, response_text)

    except Exception as e:
        logger.exception(
            f"[Acc#{account_id}] Xabar qayta ishlashda xato: {e}"
        )


async def _notify_owner(
    account,
    chat_id: int,
    user_message: str,
    ai_response: str,
) -> None:
    """
    AI javob berishga qiynalsa, akkaunt egasiga asosiy bot orqali
    ogohlantirish yuboradi.
    """
    from aiogram import Bot

    try:
        bot = Bot(token=settings.BOT_TOKEN)
        chat_link = f"tg://openmessage?user_id={chat_id}"

        text = (
            f"⚠️ <b>Diqqat! AI javob berishga qiynaldi</b>\n\n"
            f"📱 Akkaunt: <code>{account.phone_number}</code>\n"
            f"💬 Chat ID: <code>{chat_id}</code>\n\n"
            f"📩 <b>Mijoz xabari:</b>\n{user_message[:300]}\n\n"
            f"🤖 <b>AI javobi:</b>\n{ai_response[:300]}\n\n"
            f"👆 Iltimos, chatni tekshiring!"
        )

        from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
        kb = InlineKeyboardMarkup(
            inline_keyboard=[[
                InlineKeyboardButton(text="💬 Chatni ochish", url=chat_link)
            ]]
        )

        await bot.send_message(
            chat_id=account.user_id,
            text=text,
            reply_markup=kb,
            parse_mode="HTML",
        )
        await bot.session.close()

    except Exception as e:
        logger.error(f"Human-in-the-loop ogohlantirish yuborishda xato: {e}")
