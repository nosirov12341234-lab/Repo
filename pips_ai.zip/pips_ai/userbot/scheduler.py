"""
userbot/scheduler.py
====================
APScheduler — Rejalashtirilgan postlarni yuborish.
Har daqiqada DB dagi PENDING postlarni tekshiradi.
"""

from __future__ import annotations

from datetime import datetime, timezone

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from loguru import logger

from database.crud import get_pending_posts, mark_post_sent, mark_post_failed
from database.session import AsyncSessionFactory
from services.ai_service import AIService
from userbot.manager import userbot_manager

scheduler = AsyncIOScheduler(timezone="UTC")


async def _send_scheduled_posts() -> None:
    """Har daqiqada ishga tushadigan vazifa."""
    now = datetime.now(timezone.utc)

    async with AsyncSessionFactory() as session:
        posts = await get_pending_posts(session, until=now)

        for post in posts:
            client = userbot_manager.get_client(post.account_id)

            if not client:
                logger.warning(
                    f"Post #{post.id}: akkaunt #{post.account_id} ishlamayapti."
                )
                continue

            try:
                content = post.content

                # AI tomonidan yaratiladigan post bo'lsa
                if post.ai_generated and post.ai_prompt:
                    ai = AIService(session)
                    content = await ai.generate_post(
                        prompt=post.ai_prompt,
                        system_prompt="Sen professional kontent yozuvchisisan. "
                                      "Telegram kanallar uchun qisqa, ta'sirchan postlar yoz.",
                    )

                await client.send_message(
                    chat_id=post.target_chat_id,
                    text=content,
                )
                await mark_post_sent(session, post.id)
                logger.success(
                    f"Post #{post.id} muvaffaqiyatli yuborildi → chat={post.target_chat_id}"
                )

            except Exception as e:
                error_msg = str(e)[:500]
                await mark_post_failed(session, post.id, error_msg)
                logger.error(f"Post #{post.id} yuborishda xato: {e}")

        await session.commit()


def start_scheduler() -> None:
    """Schedulerni ishga tushirish."""
    scheduler.add_job(
        _send_scheduled_posts,
        trigger="interval",
        minutes=1,
        id="send_scheduled_posts",
        replace_existing=True,
        max_instances=1,
    )
    scheduler.start()
    logger.info("Scheduler ishga tushdi ✓ (har daqiqada tekshiradi)")


def stop_scheduler() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
        logger.info("Scheduler to'xtatildi.")
