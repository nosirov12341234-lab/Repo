"""
database/crud.py
================
Pips AI — Barcha ma'lumotlar bazasi CRUD operatsiyalari.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional, List

from sqlalchemy import select, update, delete, func
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import (
    User, LinkedAccount, GeminiKey, ChatHistory,
    ScheduledPost, Channel, Setting,
    AccountStatus, KeyStatus, PostStatus,
)


# ═══════════════════════════════════════════════════════════
# USERS
# ═══════════════════════════════════════════════════════════

async def get_or_create_user(
    session: AsyncSession,
    tg_user_id: int,
    username: Optional[str],
    full_name: str,
    language_code: Optional[str] = None,
) -> tuple[User, bool]:
    """Foydalanuvchini topadi yoki yangi yaratadi. (user, created) qaytaradi."""
    result = await session.execute(select(User).where(User.id == tg_user_id))
    user = result.scalar_one_or_none()

    if user is not None:
        # Ma'lumotlarni yangilash
        user.username = username
        user.full_name = full_name
        return user, False

    user = User(
        id=tg_user_id,
        username=username,
        full_name=full_name,
        language_code=language_code,
    )
    session.add(user)
    await session.flush()
    return user, True


async def get_user(session: AsyncSession, tg_user_id: int) -> Optional[User]:
    result = await session.execute(select(User).where(User.id == tg_user_id))
    return result.scalar_one_or_none()


async def get_all_users(session: AsyncSession) -> List[User]:
    result = await session.execute(select(User).where(User.is_banned == False))
    return list(result.scalars().all())


async def ban_user(session: AsyncSession, tg_user_id: int) -> bool:
    result = await session.execute(
        update(User).where(User.id == tg_user_id).values(is_banned=True)
    )
    return result.rowcount > 0


async def get_users_count(session: AsyncSession) -> int:
    result = await session.execute(select(func.count(User.id)))
    return result.scalar_one()


async def update_stars_balance(
    session: AsyncSession, tg_user_id: int, delta: int
) -> int:
    """Stars balansini oshiradi yoki kamaytiradi. Yangi balansni qaytaradi."""
    user = await get_user(session, tg_user_id)
    if not user:
        raise ValueError(f"User {tg_user_id} topilmadi")
    user.stars_balance = max(0, user.stars_balance + delta)
    await session.flush()
    return user.stars_balance


async def mark_daily_payment(session: AsyncSession, tg_user_id: int) -> None:
    await session.execute(
        update(User)
        .where(User.id == tg_user_id)
        .values(last_paid_at=datetime.now(timezone.utc))
    )


# ═══════════════════════════════════════════════════════════
# LINKED ACCOUNTS
# ═══════════════════════════════════════════════════════════

async def get_user_accounts(
    session: AsyncSession, user_id: int
) -> List[LinkedAccount]:
    result = await session.execute(
        select(LinkedAccount)
        .where(LinkedAccount.user_id == user_id)
        .order_by(LinkedAccount.created_at.asc())
    )
    return list(result.scalars().all())


async def get_account(
    session: AsyncSession, account_id: int
) -> Optional[LinkedAccount]:
    result = await session.execute(
        select(LinkedAccount).where(LinkedAccount.id == account_id)
    )
    return result.scalar_one_or_none()


async def get_account_by_phone(
    session: AsyncSession, phone: str
) -> Optional[LinkedAccount]:
    result = await session.execute(
        select(LinkedAccount).where(LinkedAccount.phone_number == phone)
    )
    return result.scalar_one_or_none()


async def create_account(
    session: AsyncSession,
    user_id: int,
    phone_number: str,
    tg_user_id: Optional[int] = None,
    session_file: Optional[str] = None,
    proxy_url: Optional[str] = None,
    persona_name: Optional[str] = None,
    system_prompt: Optional[str] = None,
) -> LinkedAccount:
    account = LinkedAccount(
        user_id=user_id,
        phone_number=phone_number,
        tg_user_id=tg_user_id,
        session_file=session_file,
        proxy_url=proxy_url,
        persona_name=persona_name,
        system_prompt=system_prompt,
        status=AccountStatus.ACTIVE,
    )
    session.add(account)
    await session.flush()
    return account


async def update_account_session(
    session: AsyncSession,
    account_id: int,
    session_file: str,
    tg_user_id: int,
) -> None:
    await session.execute(
        update(LinkedAccount)
        .where(LinkedAccount.id == account_id)
        .values(session_file=session_file, tg_user_id=tg_user_id)
    )


async def update_account_settings(
    session: AsyncSession,
    account_id: int,
    persona_name: Optional[str] = None,
    system_prompt: Optional[str] = None,
    trigger_keywords: Optional[str] = None,
    proxy_url: Optional[str] = None,
    is_auto_reply: Optional[bool] = None,
    sleep_start_hour: Optional[int] = None,
    sleep_end_hour: Optional[int] = None,
) -> None:
    values: dict = {}
    if persona_name is not None:
        values["persona_name"] = persona_name
    if system_prompt is not None:
        values["system_prompt"] = system_prompt
    if trigger_keywords is not None:
        values["trigger_keywords"] = trigger_keywords
    if proxy_url is not None:
        values["proxy_url"] = proxy_url
    if is_auto_reply is not None:
        values["is_auto_reply"] = is_auto_reply
    if sleep_start_hour is not None:
        values["sleep_start_hour"] = sleep_start_hour
    if sleep_end_hour is not None:
        values["sleep_end_hour"] = sleep_end_hour

    if values:
        await session.execute(
            update(LinkedAccount)
            .where(LinkedAccount.id == account_id)
            .values(**values)
        )


async def delete_account(session: AsyncSession, account_id: int) -> bool:
    result = await session.execute(
        delete(LinkedAccount).where(LinkedAccount.id == account_id)
    )
    return result.rowcount > 0


async def set_account_status(
    session: AsyncSession, account_id: int, status: AccountStatus
) -> None:
    await session.execute(
        update(LinkedAccount)
        .where(LinkedAccount.id == account_id)
        .values(status=status)
    )


async def increment_account_messages(
    session: AsyncSession, account_id: int
) -> None:
    await session.execute(
        update(LinkedAccount)
        .where(LinkedAccount.id == account_id)
        .values(total_messages_sent=LinkedAccount.total_messages_sent + 1)
    )


async def get_all_active_accounts(
    session: AsyncSession,
) -> List[LinkedAccount]:
    result = await session.execute(
        select(LinkedAccount).where(
            LinkedAccount.status == AccountStatus.ACTIVE,
            LinkedAccount.session_file.isnot(None),
        )
    )
    return list(result.scalars().all())


async def count_user_accounts(session: AsyncSession, user_id: int) -> int:
    result = await session.execute(
        select(func.count(LinkedAccount.id)).where(
            LinkedAccount.user_id == user_id
        )
    )
    return result.scalar_one()


async def get_total_active_accounts(session: AsyncSession) -> int:
    result = await session.execute(
        select(func.count(LinkedAccount.id)).where(
            LinkedAccount.status == AccountStatus.ACTIVE
        )
    )
    return result.scalar_one()


async def get_total_messages_sent(session: AsyncSession) -> int:
    result = await session.execute(
        select(func.sum(LinkedAccount.total_messages_sent))
    )
    return result.scalar_one() or 0


# ═══════════════════════════════════════════════════════════
# CHANNELS
# ═══════════════════════════════════════════════════════════

async def get_active_channels(session: AsyncSession) -> List[Channel]:
    result = await session.execute(
        select(Channel).where(Channel.is_active == True)
    )
    return list(result.scalars().all())


async def add_channel(
    session: AsyncSession,
    channel_id: int,
    title: str,
    channel_username: Optional[str] = None,
    invite_link: Optional[str] = None,
    added_by: Optional[int] = None,
) -> Channel:
    ch = Channel(
        channel_id=channel_id,
        title=title,
        channel_username=channel_username,
        invite_link=invite_link,
        added_by=added_by,
        is_active=True,
    )
    session.add(ch)
    await session.flush()
    return ch


async def remove_channel(session: AsyncSession, channel_id: int) -> bool:
    result = await session.execute(
        delete(Channel).where(Channel.channel_id == channel_id)
    )
    return result.rowcount > 0


# ═══════════════════════════════════════════════════════════
# SETTINGS
# ═══════════════════════════════════════════════════════════

async def get_setting(
    session: AsyncSession, key: str, default: str = ""
) -> str:
    result = await session.execute(
        select(Setting.value).where(Setting.key == key)
    )
    val = result.scalar_one_or_none()
    return val if val is not None else default


async def set_setting(
    session: AsyncSession, key: str, value: str, description: str = ""
) -> None:
    result = await session.execute(
        select(Setting).where(Setting.key == key)
    )
    setting = result.scalar_one_or_none()

    if setting:
        setting.value = value
    else:
        setting = Setting(key=key, value=value, description=description)
        session.add(setting)
    await session.flush()


# ═══════════════════════════════════════════════════════════
# SCHEDULED POSTS
# ═══════════════════════════════════════════════════════════

async def create_scheduled_post(
    session: AsyncSession,
    account_id: int,
    target_chat_id: int,
    content: str,
    scheduled_at: datetime,
    ai_generated: bool = False,
    ai_prompt: Optional[str] = None,
) -> ScheduledPost:
    post = ScheduledPost(
        account_id=account_id,
        target_chat_id=target_chat_id,
        content=content,
        scheduled_at=scheduled_at,
        ai_generated=ai_generated,
        ai_prompt=ai_prompt,
        status=PostStatus.PENDING,
    )
    session.add(post)
    await session.flush()
    return post


async def get_pending_posts(
    session: AsyncSession, until: datetime
) -> List[ScheduledPost]:
    result = await session.execute(
        select(ScheduledPost).where(
            ScheduledPost.status == PostStatus.PENDING,
            ScheduledPost.scheduled_at <= until,
        )
    )
    return list(result.scalars().all())


async def mark_post_sent(session: AsyncSession, post_id: int) -> None:
    await session.execute(
        update(ScheduledPost)
        .where(ScheduledPost.id == post_id)
        .values(status=PostStatus.SENT, sent_at=datetime.now(timezone.utc))
    )


async def mark_post_failed(
    session: AsyncSession, post_id: int, error: str
) -> None:
    await session.execute(
        update(ScheduledPost)
        .where(ScheduledPost.id == post_id)
        .values(status=PostStatus.FAILED, error_message=error)
    )
