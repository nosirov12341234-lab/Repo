"""
database/models.py
==================
Pips AI — Barcha SQLAlchemy async ORM modellari.

Jadvallar:
  - users           : Bot foydalanuvchilari
  - linked_accounts : Ulangan Pyrogram userbot akkauntlari
  - gemini_keys     : API Key Pool
  - chat_history    : AI suhbat tarixi (per account, per chat)
  - scheduled_posts : Rejalashtirilgan postlar
  - channels        : Majburiy obuna kanallari
"""

from __future__ import annotations

import enum
from datetime import datetime
from typing import List, Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    mapped_column,
    relationship,
)


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------

class Base(DeclarativeBase):
    """Barcha modellar uchun umumiy base."""
    pass


# ---------------------------------------------------------------------------
# Enum turlari
# ---------------------------------------------------------------------------

class AccountStatus(str, enum.Enum):
    ACTIVE   = "active"     # Userbot ishlayapti
    SLEEPING = "sleeping"   # Smart Sleep Mode
    BANNED   = "banned"     # Telegram tomonidan ban
    DISABLED = "disabled"   # Foydalanuvchi o'zi o'chirgan


class KeyStatus(str, enum.Enum):
    ACTIVE    = "active"     # Ishlatish mumkin
    RATELIMIT = "ratelimit"  # 429 — vaqtinchalik bloklangan
    INVALID   = "invalid"    # Noto'g'ri / o'chirilgan


class MessageRole(str, enum.Enum):
    USER      = "user"
    ASSISTANT = "assistant"


class PostStatus(str, enum.Enum):
    PENDING   = "pending"
    SENT      = "sent"
    FAILED    = "failed"
    CANCELLED = "cancelled"


# ---------------------------------------------------------------------------
# 1. Users — Bot foydalanuvchilari
# ---------------------------------------------------------------------------

class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, comment="Telegram user_id"
    )
    username: Mapped[Optional[str]] = mapped_column(
        String(64), nullable=True, index=True
    )
    full_name: Mapped[str] = mapped_column(String(256), nullable=False)
    language_code: Mapped[Optional[str]] = mapped_column(String(8), nullable=True)

    # Stars tizimi
    stars_balance: Mapped[int] = mapped_column(
        Integer, default=0, nullable=False,
        comment="Foydalanuvchining joriy Stars balansi"
    )
    last_paid_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
        comment="Oxirgi marta kunlik to'lov qilingan sana"
    )

    # Admin flag
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    # Relationships
    linked_accounts: Mapped[List["LinkedAccount"]] = relationship(
        "LinkedAccount", back_populates="user",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    def __repr__(self) -> str:
        return f"<User id={self.id} username={self.username!r}>"


# ---------------------------------------------------------------------------
# 2. LinkedAccounts — Ulangan Pyrogram userbot akkauntlari
# ---------------------------------------------------------------------------

class LinkedAccount(Base):
    __tablename__ = "linked_accounts"
    __table_args__ = (
        UniqueConstraint("phone_number", name="uq_linked_accounts_phone"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Egasi
    user_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )

    # Akkaunt ma'lumotlari
    phone_number: Mapped[str] = mapped_column(
        String(20), nullable=False,
        comment="Xalqaro formatda: +998901234567"
    )
    tg_user_id: Mapped[Optional[int]] = mapped_column(
        BigInteger, nullable=True,
        comment="Akkauntning Telegram user_id si"
    )
    session_file: Mapped[Optional[str]] = mapped_column(
        String(256), nullable=True,
        comment="sessions/ papkasidagi .session fayl nomi"
    )

    # Proxy
    proxy_url: Mapped[Optional[str]] = mapped_column(
        String(512), nullable=True,
        comment="socks5://user:pass@host:port yoki http://..."
    )

    # Personaj va vazifa
    persona_name: Mapped[Optional[str]] = mapped_column(
        String(128), nullable=True,
        comment="Masalan: 'Aziz savdogar'"
    )
    system_prompt: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True,
        comment="AI uchun role/task tavsifi"
    )

    # Trigger so'zlar (vergul bilan ajratilgan)
    trigger_keywords: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True,
        comment="'narx,price,sotib' — faqat shu so'zlar bo'lsa javob beradi"
    )

    # Holat
    status: Mapped[AccountStatus] = mapped_column(
        Enum(AccountStatus), default=AccountStatus.ACTIVE, nullable=False
    )
    is_auto_reply: Mapped[bool] = mapped_column(
        Boolean, default=True, nullable=False,
        comment="Auto-javob yoqilgan/o'chirilgan"
    )
    sleep_start_hour: Mapped[int] = mapped_column(
        Integer, default=23, nullable=False,
        comment="Uxlash boshlanish soati (0-23)"
    )
    sleep_end_hour: Mapped[int] = mapped_column(
        Integer, default=7, nullable=False,
        comment="Uxlash tugash soati (0-23)"
    )

    # Statistika
    total_messages_sent: Mapped[int] = mapped_column(
        Integer, default=0, nullable=False
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="linked_accounts")
    chat_histories: Mapped[List["ChatHistory"]] = relationship(
        "ChatHistory", back_populates="account",
        cascade="all, delete-orphan",
        lazy="noload",
    )
    scheduled_posts: Mapped[List["ScheduledPost"]] = relationship(
        "ScheduledPost", back_populates="account",
        cascade="all, delete-orphan",
        lazy="noload",
    )

    def __repr__(self) -> str:
        return f"<LinkedAccount id={self.id} phone={self.phone_number!r} status={self.status}>"


# ---------------------------------------------------------------------------
# 3. GeminiKeys — API Key Pool
# ---------------------------------------------------------------------------

class GeminiKey(Base):
    __tablename__ = "gemini_keys"
    __table_args__ = (
        UniqueConstraint("api_key", name="uq_gemini_keys_api_key"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    api_key: Mapped[str] = mapped_column(
        String(256), nullable=False,
        comment="Google AI Studio dan olingan API kalit"
    )

    status: Mapped[KeyStatus] = mapped_column(
        Enum(KeyStatus), default=KeyStatus.ACTIVE, nullable=False
    )

    # Round-Robin tartib raqami
    usage_count: Mapped[int] = mapped_column(
        Integer, default=0, nullable=False,
        comment="Jami necha marta ishlatilgan"
    )

    # Rate limit — qachon blokdan chiqadi
    ratelimit_until: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
        comment="429 xatolikdan keyin qachon qayta ishlatish mumkin"
    )

    # Kalitni kim qo'shdi (admin)
    added_by: Mapped[Optional[int]] = mapped_column(
        BigInteger, nullable=True,
        comment="Admin Telegram user_id si"
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    def __repr__(self) -> str:
        masked = self.api_key[:8] + "..." + self.api_key[-4:]
        return f"<GeminiKey id={self.id} key={masked!r} status={self.status}>"


# ---------------------------------------------------------------------------
# 4. ChatHistory — AI Suhbat Tarixi
# ---------------------------------------------------------------------------

class ChatHistory(Base):
    __tablename__ = "chat_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Qaysi userbot akkaunt
    account_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("linked_accounts.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )

    # Telegram chat_id (shaxsiy yoki guruh)
    telegram_chat_id: Mapped[int] = mapped_column(
        BigInteger, nullable=False, index=True,
        comment="Suhbat olib borilayotgan Telegram chat ID si"
    )

    # Xabar
    role: Mapped[MessageRole] = mapped_column(
        Enum(MessageRole), nullable=False
    )
    content: Mapped[str] = mapped_column(
        Text, nullable=False,
        comment="Xabar matni"
    )

    # Token statistikasi (optional, Gemini qaytarsa)
    input_tokens: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    output_tokens: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(),
        nullable=False, index=True,
    )

    # Relationships
    account: Mapped["LinkedAccount"] = relationship(
        "LinkedAccount", back_populates="chat_histories"
    )

    def __repr__(self) -> str:
        return (
            f"<ChatHistory id={self.id} account={self.account_id} "
            f"chat={self.telegram_chat_id} role={self.role}>"
        )


# ---------------------------------------------------------------------------
# 5. ScheduledPosts — Rejalashtirilgan Postlar
# ---------------------------------------------------------------------------

class ScheduledPost(Base):
    __tablename__ = "scheduled_posts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Qaysi akkaunt yuboradi
    account_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("linked_accounts.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )

    # Manzil
    target_chat_id: Mapped[int] = mapped_column(
        BigInteger, nullable=False,
        comment="Post yuboriladigan guruh/kanal ID si"
    )

    # Kontent
    content: Mapped[str] = mapped_column(
        Text, nullable=False,
        comment="Post matni (AI tomonidan yoki qo'lda yozilgan)"
    )
    ai_generated: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False,
        comment="AI tomonidan yaratiladimi?"
    )
    ai_prompt: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True,
        comment="AI ga berilgan prompt (ai_generated=True bo'lsa)"
    )

    # Vaqt
    scheduled_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True,
        comment="Post yuborilishi kerak bo'lgan vaqt (UTC)"
    )

    # Holat
    status: Mapped[PostStatus] = mapped_column(
        Enum(PostStatus), default=PostStatus.PENDING, nullable=False
    )
    error_message: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True,
        comment="FAILED bo'lsa, xato xabari"
    )
    sent_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # Relationships
    account: Mapped["LinkedAccount"] = relationship(
        "LinkedAccount", back_populates="scheduled_posts"
    )

    def __repr__(self) -> str:
        return (
            f"<ScheduledPost id={self.id} account={self.account_id} "
            f"target={self.target_chat_id} status={self.status} "
            f"scheduled_at={self.scheduled_at}>"
        )


# ---------------------------------------------------------------------------
# 6. Channels — Majburiy Obuna Kanallari
# ---------------------------------------------------------------------------

class Channel(Base):
    __tablename__ = "channels"
    __table_args__ = (
        UniqueConstraint("channel_id", name="uq_channels_channel_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    channel_id: Mapped[int] = mapped_column(
        BigInteger, nullable=False,
        comment="Telegram kanal ID si (manfiy son)"
    )
    channel_username: Mapped[Optional[str]] = mapped_column(
        String(128), nullable=True,
        comment="@username (invite link bo'lmasa)"
    )
    invite_link: Mapped[Optional[str]] = mapped_column(
        String(512), nullable=True,
        comment="Xususiy kanal uchun invite link"
    )
    title: Mapped[Optional[str]] = mapped_column(
        String(256), nullable=True,
        comment="Kanal nomi (foydalanuvchiga ko'rsatish uchun)"
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean, default=True, nullable=False
    )

    added_by: Mapped[Optional[int]] = mapped_column(
        BigInteger, nullable=True,
        comment="Qo'shgan admin Telegram user_id si"
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    def __repr__(self) -> str:
        return f"<Channel id={self.id} channel_id={self.channel_id} title={self.title!r}>"


# ---------------------------------------------------------------------------
# 7. Settings — Admin sozlamalari (key-value store)
# ---------------------------------------------------------------------------

class Setting(Base):
    __tablename__ = "settings"
    __table_args__ = (
        UniqueConstraint("key", name="uq_settings_key"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    key: Mapped[str] = mapped_column(
        String(128), nullable=False,
        comment="Masalan: 'daily_stars_price'"
    )
    value: Mapped[str] = mapped_column(
        Text, nullable=False,
        comment="Qiymat (string sifatida saqlanadi, kerakli typega cast qilinadi)"
    )
    description: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    def __repr__(self) -> str:
        return f"<Setting key={self.key!r} value={self.value!r}>"
