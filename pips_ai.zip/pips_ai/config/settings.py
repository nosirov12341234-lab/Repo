"""
config/settings.py
==================
Barcha muhit o'zgaruvchilari .env dan yuklanadi.
"""

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # Bot
    BOT_TOKEN: str
    ADMIN_IDS: list[int] = [8516819733]

    # Database
    DATABASE_URL: str  # postgresql+asyncpg://user:pass@host:5432/pips_ai
    DB_ECHO: bool = False

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"

    # Celery
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"

    # Sessions papkasi (Pyrogram .session fayllar)
    SESSIONS_DIR: str = "sessions"

    # Gemini
    GEMINI_MODEL: str = "gemini-2.5-flash"
    GEMINI_RATELIMIT_COOLDOWN_MINUTES: int = 60

    # Stars narxi (0 = bepul)
    DAILY_STARS_PRICE: int = 0


settings = Settings()
