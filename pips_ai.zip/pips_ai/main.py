"""
main.py
=======
Pips AI — Asosiy entry point.
Bot + Userbot + Scheduler birgalikda ishga tushadi.
"""

from __future__ import annotations

import asyncio

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.redis import RedisStorage
from loguru import logger

from bot.middlewares.auth import AuthMiddleware
from bot.middlewares.subscription import SubscriptionMiddleware
from bot.router import main_router
from config.settings import settings
from database.session import create_all_tables
from userbot.manager import userbot_manager
from userbot.scheduler import start_scheduler, stop_scheduler
from utils.logger import setup_logger
from utils.redis_client import get_redis, close_redis


async def on_startup(bot: Bot) -> None:
    """Bot ishga tushganda bajariladi."""
    logger.info("Pips AI ishga tushmoqda...")

    # Jadvallarni yaratish (agar yo'q bo'lsa)
    await create_all_tables()
    logger.info("DB jadvallar tekshirildi ✓")

    # Barcha faol userbot akkauntlarni ishga tushirish
    await userbot_manager.start_all()
    logger.info(f"Userbotlar: {userbot_manager.active_count()} ta faol ✓")

    # Schedulerni ishga tushirish
    start_scheduler()

    # Admin larga xabar berish
    for admin_id in settings.ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id,
                f"✅ <b>Pips AI ishga tushdi!</b>\n\n"
                f"📱 Faol akkauntlar: {userbot_manager.active_count()}",
                parse_mode="HTML",
            )
        except Exception:
            pass

    logger.success("Pips AI tayyor! ✓")


async def on_shutdown(bot: Bot) -> None:
    """Bot to'xtatilganda bajariladi."""
    logger.info("Pips AI to'xtatilmoqda...")

    stop_scheduler()
    await userbot_manager.stop_all()
    await close_redis()

    logger.info("Pips AI to'xtatildi.")


async def main() -> None:
    setup_logger()

    # Redis storage (FSM uchun)
    redis = await get_redis()
    storage = RedisStorage(redis=redis)

    # Bot
    bot = Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )

    # Dispatcher
    dp = Dispatcher(storage=storage)

    # Middleware larni ulash
    dp.message.middleware(AuthMiddleware())
    dp.callback_query.middleware(AuthMiddleware())
    dp.message.middleware(SubscriptionMiddleware(bot))
    dp.callback_query.middleware(SubscriptionMiddleware(bot))

    # Handlerlarni ulash
    dp.include_router(main_router)

    # Lifecycle hooks
    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)

    # Polling
    logger.info("Bot polling boshlandi...")
    await dp.start_polling(
        bot,
        allowed_updates=dp.resolve_used_update_types(),
        drop_pending_updates=True,
    )


if __name__ == "__main__":
    asyncio.run(main())
