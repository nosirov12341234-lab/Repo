"""
bot/middlewares/subscription.py
================================
Har bir xabarda majburiy kanal obunasini tekshiradi.
A'zo bo'lmagan foydalanuvchiga kanal havolalarini ko'rsatadi.
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware, Bot
from aiogram.types import TelegramObject, Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

from database.session import AsyncSessionFactory
from services.subscription_service import check_user_subscriptions


SKIP_COMMANDS = {"/start"}


class SubscriptionMiddleware(BaseMiddleware):
    def __init__(self, bot: Bot) -> None:
        self.bot = bot

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        # Faqat Message va CallbackQuery uchun
        if not isinstance(event, (Message, CallbackQuery)):
            return await handler(event, data)

        tg_user = event.from_user
        if not tg_user or tg_user.is_bot:
            return await handler(event, data)

        # /start ga tekshiruv o'tkazilmaydi
        if isinstance(event, Message) and event.text in SKIP_COMMANDS:
            return await handler(event, data)

        async with AsyncSessionFactory() as session:
            ok, missing = await check_user_subscriptions(
                bot=self.bot,
                session=session,
                user_id=tg_user.id,
            )

        if ok:
            return await handler(event, data)

        # Kanal tugmalarini tuzish
        buttons = []
        for ch in missing:
            label = ch.title or f"Kanal {ch.channel_id}"
            url = ch.invite_link or (
                f"https://t.me/{ch.channel_username.lstrip('@')}"
                if ch.channel_username else None
            )
            if url:
                buttons.append([InlineKeyboardButton(text=f"📢 {label}", url=url)])

        buttons.append([
            InlineKeyboardButton(text="✅ A'zo bo'ldim", callback_data="check_subscription")
        ])

        markup = InlineKeyboardMarkup(inline_keyboard=buttons)
        text = (
            "⚠️ Botdan foydalanish uchun quyidagi kanallarga a'zo bo'lishingiz shart:\n\n"
            "A'zo bo'lgandan so'ng <b>«✅ A'zo bo'ldim»</b> tugmasini bosing."
        )

        if isinstance(event, Message):
            await event.answer(text, reply_markup=markup, parse_mode="HTML")
        elif isinstance(event, CallbackQuery):
            await event.message.answer(text, reply_markup=markup, parse_mode="HTML")
            await event.answer()

        return  # Handleri chaqirmaymiz
