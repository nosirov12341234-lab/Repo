"""
bot/middlewares/auth.py
=======================
Har bir so'rovda foydalanuvchini DB ga avtomatik ro'yxatdan o'tkazadi
va User obyektini handler ga uzatadi.
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message, CallbackQuery

from database.crud import get_or_create_user
from database.session import AsyncSessionFactory


class AuthMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        tg_user = None
        if isinstance(event, (Message, CallbackQuery)):
            tg_user = event.from_user

        if tg_user and not tg_user.is_bot:
            async with AsyncSessionFactory() as session:
                user, _ = await get_or_create_user(
                    session=session,
                    tg_user_id=tg_user.id,
                    username=tg_user.username,
                    full_name=tg_user.full_name,
                    language_code=tg_user.language_code,
                )
                await session.commit()
                data["db_user"] = user

        return await handler(event, data)
