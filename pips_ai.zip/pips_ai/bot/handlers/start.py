"""
bot/handlers/start.py
=====================
/start komandasi va asosiy menyu.
"""

from __future__ import annotations

from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery

from bot.keyboards.inline import main_menu_kb, check_sub_kb
from database.models import User

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, db_user: User) -> None:
    await message.answer(
        f"👋 Xush kelibsiz, <b>{message.from_user.full_name}</b>!\n\n"
        f"🤖 <b>Pips AI</b> — Telegram akkauntlaringizni AI bilan boshqaring.\n\n"
        f"Quyidagi menyudan foydalaning:",
        reply_markup=main_menu_kb(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "main_menu")
async def cb_main_menu(call: CallbackQuery, db_user: User) -> None:
    await call.message.edit_text(
        f"🏠 <b>Asosiy Menyu</b>\n\nNimani xohlaysiz?",
        reply_markup=main_menu_kb(),
        parse_mode="HTML",
    )
    await call.answer()


@router.callback_query(F.data == "check_subscription")
async def cb_check_subscription(call: CallbackQuery) -> None:
    """
    Foydalanuvchi 'A'zo bo'ldim' tugmasini bosdi.
    SubscriptionMiddleware qayta tekshiradi — agar a'zo bo'lgan bo'lsa o'tkazib yuboradi.
    """
    await call.answer("✅ Tekshirilmoqda...", show_alert=False)
    await call.message.answer(
        "Rahmat! Endi /start buyrug'ini yuboring.",
    )
