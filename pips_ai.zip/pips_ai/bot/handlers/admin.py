"""
bot/handlers/admin.py
=====================
Admin panel — statistika, kalitlar, kanallar, broadcast.
"""

from __future__ import annotations

import asyncio
from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from bot.filters.is_admin import IsAdmin
from bot.keyboards.inline import (
    admin_menu_kb, admin_keys_kb, admin_channels_kb, back_kb,
)
from database.crud import (
    get_users_count, get_total_active_accounts, get_total_messages_sent,
    add_channel, remove_channel, get_active_channels,
    set_setting, get_setting, get_all_users,
)
from database.session import AsyncSessionFactory
from services.ai_service import AIService

router = Router()
router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())


# ── FSM ──────────────────────────────────────────────────────────────────────

class AddKeysFSM(StatesGroup):
    waiting_keys = State()


class AddChannelFSM(StatesGroup):
    waiting_channel = State()


class SetStarsPriceFSM(StatesGroup):
    waiting_price = State()


class BroadcastFSM(StatesGroup):
    waiting_message = State()
    waiting_confirm = State()


# ── Admin panel ──────────────────────────────────────────────────────────────

@router.message(Command("admin"))
async def cmd_admin(message: Message) -> None:
    await message.answer(
        "🛠 <b>Admin Panel</b>\n\nNimani boshqarmoqchisiz?",
        reply_markup=admin_menu_kb(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "admin_menu")
async def cb_admin_menu(call: CallbackQuery) -> None:
    await call.message.edit_text(
        "🛠 <b>Admin Panel</b>",
        reply_markup=admin_menu_kb(),
        parse_mode="HTML",
    )
    await call.answer()


# ── Statistika ───────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin_stats")
async def cb_admin_stats(call: CallbackQuery) -> None:
    async with AsyncSessionFactory() as session:
        users      = await get_users_count(session)
        accounts   = await get_total_active_accounts(session)
        messages   = await get_total_messages_sent(session)
        ai_svc     = AIService(session)
        key_stats  = await ai_svc.get_keys_stats()

    text = (
        f"📊 <b>Tizim Statistikasi</b>\n\n"
        f"👥 Jami foydalanuvchilar: <b>{users}</b>\n"
        f"📱 Faol akkauntlar: <b>{accounts}</b>\n"
        f"📨 AI yuborgan xabarlar: <b>{messages}</b>\n\n"
        f"🔑 <b>Gemini Kalitlar</b>\n"
        f"  ✅ Faol: <b>{key_stats['active']}</b>\n"
        f"  ⏳ Rate-limited: <b>{key_stats['ratelimited']}</b>\n"
        f"  ❌ Noto'g'ri: <b>{key_stats['invalid']}</b>\n"
        f"  📈 Jami ishlatilgan: <b>{key_stats['total_usage']}</b>"
    )
    await call.message.edit_text(
        text,
        reply_markup=back_kb("admin_menu"),
        parse_mode="HTML",
    )
    await call.answer()


# ── Gemini kalitlar ───────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin_keys")
async def cb_admin_keys(call: CallbackQuery) -> None:
    async with AsyncSessionFactory() as session:
        ai_svc = AIService(session)
        stats  = await ai_svc.get_keys_stats()

    await call.message.edit_text(
        f"🔑 <b>Gemini API Kalitlar</b>\n\n"
        f"✅ Faol: {stats['active']} | "
        f"⏳ RL: {stats['ratelimited']} | "
        f"❌ Noto'g'ri: {stats['invalid']}",
        reply_markup=admin_keys_kb(),
        parse_mode="HTML",
    )
    await call.answer()


@router.callback_query(F.data == "admin_keys_add")
async def cb_admin_keys_add(call: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AddKeysFSM.waiting_keys)
    await call.message.edit_text(
        "🔑 <b>Kalitlarni kiriting</b>\n\n"
        "Har bir kalit alohida qatorda bo'lsin:\n\n"
        "<code>AIzaSyXXXXXXXXXXXXXXXXX\n"
        "AIzaSyYYYYYYYYYYYYYYYYY\n"
        "AIzaSyZZZZZZZZZZZZZZZZZ</code>",
        parse_mode="HTML",
    )
    await call.answer()


@router.message(AddKeysFSM.waiting_keys)
async def fsm_add_keys(message: Message, state: FSMContext) -> None:
    raw_keys = message.text.strip().split("\n")
    async with AsyncSessionFactory() as session:
        ai_svc = AIService(session)
        result = await ai_svc.add_keys_bulk(raw_keys, added_by=message.from_user.id)
        await session.commit()

    await state.clear()
    await message.answer(
        f"✅ <b>Kalitlar yuklandi!</b>\n\n"
        f"➕ Qo'shildi: <b>{result['added']}</b>\n"
        f"🔁 Takror: <b>{result['duplicates']}</b>",
        reply_markup=back_kb("admin_keys"),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "admin_keys_clean")
async def cb_admin_keys_clean(call: CallbackQuery) -> None:
    async with AsyncSessionFactory() as session:
        ai_svc = AIService(session)
        count  = await ai_svc.remove_invalid_keys()
        await session.commit()

    await call.answer(f"✅ {count} ta noto'g'ri kalit o'chirildi!", show_alert=True)


@router.callback_query(F.data == "admin_keys_stats")
async def cb_admin_keys_stats(call: CallbackQuery) -> None:
    async with AsyncSessionFactory() as session:
        ai_svc = AIService(session)
        stats  = await ai_svc.get_keys_stats()

    await call.answer(
        f"✅ {stats['active']} faol | ⏳ {stats['ratelimited']} RL | "
        f"❌ {stats['invalid']} noto'g'ri | 📈 {stats['total_usage']} jami",
        show_alert=True,
    )


# ── Kanallar ──────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin_channels")
async def cb_admin_channels(call: CallbackQuery) -> None:
    await call.message.edit_text(
        "📢 <b>Majburiy Obuna Kanallar</b>",
        reply_markup=admin_channels_kb(),
        parse_mode="HTML",
    )
    await call.answer()


@router.callback_query(F.data == "admin_channel_list")
async def cb_channel_list(call: CallbackQuery) -> None:
    async with AsyncSessionFactory() as session:
        channels = await get_active_channels(session)

    if not channels:
        await call.answer("Hech qanday kanal yo'q.", show_alert=True)
        return

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton

    builder = InlineKeyboardBuilder()
    lines = []
    for ch in channels:
        lines.append(f"• {ch.title or ch.channel_id} (<code>{ch.channel_id}</code>)")
        builder.row(
            InlineKeyboardButton(
                text=f"🗑 {ch.title or ch.channel_id}",
                callback_data=f"admin_channel_del:{ch.channel_id}",
            )
        )
    builder.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="admin_channels"))

    text = "📋 <b>Faol kanallar:</b>\n\n" + "\n".join(lines)
    await call.message.edit_text(text, reply_markup=builder.as_markup(), parse_mode="HTML")
    await call.answer()


@router.callback_query(F.data == "admin_channel_add")
async def cb_channel_add(call: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AddChannelFSM.waiting_channel)
    await call.message.edit_text(
        "📢 <b>Kanal ID sini kiriting</b>\n\n"
        "Botni kanalga admin qiling, so'ng kanal ID sini yuboring.\n"
        "Kanal ID ni bilish uchun @username_to_id_bot dan foydalaning.\n\n"
        "Format: <code>-1001234567890</code>",
        parse_mode="HTML",
    )
    await call.answer()


@router.message(AddChannelFSM.waiting_channel, F.text)
async def fsm_add_channel(message: Message, state: FSMContext, bot: Bot) -> None:
    text = message.text.strip()
    try:
        channel_id = int(text)
    except ValueError:
        await message.answer("❌ Noto'g'ri format. Faqat raqam kiriting: -1001234567890")
        return

    try:
        chat = await bot.get_chat(channel_id)
        async with AsyncSessionFactory() as session:
            ch = await add_channel(
                session=session,
                channel_id=channel_id,
                title=chat.title,
                channel_username=chat.username,
                invite_link=chat.invite_link,
                added_by=message.from_user.id,
            )
            await session.commit()
        await state.clear()
        await message.answer(
            f"✅ Kanal qo'shildi: <b>{chat.title}</b>",
            reply_markup=back_kb("admin_channels"),
            parse_mode="HTML",
        )
    except Exception as e:
        await message.answer(f"❌ Xato: {e}\n\nBot kanalda admin ekanligini tekshiring.")


@router.callback_query(F.data.startswith("admin_channel_del:"))
async def cb_channel_del(call: CallbackQuery) -> None:
    channel_id = int(call.data.split(":")[1])
    async with AsyncSessionFactory() as session:
        ok = await remove_channel(session, channel_id)
        await session.commit()
    await call.answer("✅ Kanal o'chirildi!" if ok else "❌ Topilmadi!", show_alert=True)
    # Ro'yxatni yangilash
    await cb_channel_list(call)


# ── Stars narxi ───────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin_stars_price")
async def cb_stars_price(call: CallbackQuery, state: FSMContext) -> None:
    async with AsyncSessionFactory() as session:
        price = await get_setting(session, "daily_stars_price", "0")

    await state.set_state(SetStarsPriceFSM.waiting_price)
    await call.message.edit_text(
        f"💰 <b>Kunlik Stars narxi</b>\n\n"
        f"Hozirgi narx: <b>{price} Stars</b>\n\n"
        f"Yangi narxni kiriting (0 = bepul):",
        parse_mode="HTML",
    )
    await call.answer()


@router.message(SetStarsPriceFSM.waiting_price)
async def fsm_stars_price(message: Message, state: FSMContext) -> None:
    try:
        price = int(message.text.strip())
        if price < 0:
            raise ValueError
    except ValueError:
        await message.answer("❌ Faqat 0 yoki musbat butun son kiriting.")
        return

    async with AsyncSessionFactory() as session:
        await set_setting(
            session, "daily_stars_price", str(price),
            description="Kunlik foydalanish narxi (Stars)"
        )
        await session.commit()

    await state.clear()
    price_text = f"{price} Stars/kun" if price > 0 else "Bepul"
    await message.answer(
        f"✅ Narx yangilandi: <b>{price_text}</b>",
        reply_markup=back_kb("admin_menu"),
        parse_mode="HTML",
    )


# ── Broadcast ─────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin_broadcast")
async def cb_broadcast(call: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(BroadcastFSM.waiting_message)
    await call.message.edit_text(
        "📣 <b>Broadcast</b>\n\n"
        "Barcha foydalanuvchilarga yuboriladigan xabarni kiriting\n"
        "(matn, rasm, video — istalgan format):",
        parse_mode="HTML",
    )
    await call.answer()


@router.message(BroadcastFSM.waiting_message)
async def fsm_broadcast_message(message: Message, state: FSMContext) -> None:
    await state.update_data(broadcast_message_id=message.message_id)
    await state.set_state(BroadcastFSM.waiting_confirm)

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Yuborish", callback_data="broadcast_confirm"),
        InlineKeyboardButton(text="❌ Bekor", callback_data="admin_menu"),
    )
    await message.answer(
        "⬆️ Yuqoridagi xabar barcha foydalanuvchilarga yuboriladi.\n\nTasdiqlaysizmi?",
        reply_markup=builder.as_markup(),
    )


@router.callback_query(BroadcastFSM.waiting_confirm, F.data == "broadcast_confirm")
async def cb_broadcast_confirm(call: CallbackQuery, state: FSMContext, bot: Bot) -> None:
    data = await state.get_data()
    msg_id = data.get("broadcast_message_id")
    await state.clear()

    async with AsyncSessionFactory() as session:
        users = await get_all_users(session)

    sent = 0
    failed = 0

    await call.message.edit_text(f"📣 Broadcast boshlandi. {len(users)} ta foydalanuvchi...")

    for user in users:
        try:
            await bot.copy_message(
                chat_id=user.id,
                from_chat_id=call.from_user.id,
                message_id=msg_id,
            )
            sent += 1
            await asyncio.sleep(0.05)  # Flood limit
        except Exception:
            failed += 1

    await call.message.answer(
        f"✅ <b>Broadcast yakunlandi!</b>\n\n"
        f"📤 Yuborildi: <b>{sent}</b>\n"
        f"❌ Xato: <b>{failed}</b>",
        parse_mode="HTML",
    )
