"""
bot/handlers/profile.py
========================
Profil va Stars tizimi.
"""

from __future__ import annotations

from aiogram import Router, F
from aiogram.types import CallbackQuery, Message, LabeledPrice
from aiogram.filters import Command

from bot.keyboards.inline import profile_kb, back_kb
from database.models import User
from database.session import AsyncSessionFactory
from services.stars_service import get_daily_price

router = Router()

STARS_PACKAGES = [
    (50,  "⭐ 50 Stars — 50 XTR"),
    (100, "⭐ 100 Stars — 100 XTR"),
    (250, "⭐ 250 Stars — 250 XTR"),
    (500, "⭐ 500 Stars — 500 XTR"),
]


@router.callback_query(F.data == "profile")
async def cb_profile(call: CallbackQuery, db_user: User) -> None:
    async with AsyncSessionFactory() as session:
        daily_price = await get_daily_price(session)

    price_text = f"{daily_price} ⭐ Stars/kun" if daily_price > 0 else "Bepul (cheksiz)"
    paid_text = (
        db_user.last_paid_at.strftime("%d.%m.%Y %H:%M") if db_user.last_paid_at else "—"
    )

    text = (
        f"👤 <b>Profilingiz</b>\n\n"
        f"🆔 ID: <code>{db_user.id}</code>\n"
        f"📛 Ism: {db_user.full_name}\n"
        f"⭐ Balans: <b>{db_user.stars_balance} Stars</b>\n\n"
        f"💰 Kunlik narx: {price_text}\n"
        f"📅 Oxirgi to'lov: {paid_text}"
    )

    await call.message.edit_text(text, reply_markup=profile_kb(), parse_mode="HTML")
    await call.answer()


@router.callback_query(F.data == "buy_stars")
async def cb_buy_stars(call: CallbackQuery) -> None:
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton

    builder = InlineKeyboardBuilder()
    for amount, label in STARS_PACKAGES:
        builder.row(
            InlineKeyboardButton(
                text=label,
                callback_data=f"stars_buy:{amount}",
            )
        )
    builder.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="profile"))

    await call.message.edit_text(
        "⭐ <b>Stars to'ldirish</b>\n\nQancha Stars sotib olmoqchisiz?",
        reply_markup=builder.as_markup(),
        parse_mode="HTML",
    )
    await call.answer()


@router.callback_query(F.data.startswith("stars_buy:"))
async def cb_stars_buy_amount(call: CallbackQuery) -> None:
    amount = int(call.data.split(":")[1])

    # Telegram Stars invoice yuborish
    await call.message.answer_invoice(
        title=f"⭐ {amount} Pips Stars",
        description=f"Pips AI uchun {amount} ta Stars sotib olish",
        payload=f"stars_{amount}_{call.from_user.id}",
        currency="XTR",
        prices=[LabeledPrice(label=f"{amount} Stars", amount=amount)],
    )
    await call.answer()


@router.pre_checkout_query()
async def pre_checkout(pre_checkout_query) -> None:
    await pre_checkout_query.answer(ok=True)


@router.message(F.successful_payment)
async def successful_payment(message: Message, db_user: User) -> None:
    payload = message.successful_payment.invoice_payload
    # payload: "stars_100_123456789"
    parts = payload.split("_")
    if len(parts) >= 2:
        try:
            amount = int(parts[1])
            async with AsyncSessionFactory() as session:
                from database.crud import update_stars_balance
                new_balance = await update_stars_balance(session, message.from_user.id, amount)
                await session.commit()

            await message.answer(
                f"✅ <b>To'lov qabul qilindi!</b>\n\n"
                f"⭐ +{amount} Stars qo'shildi\n"
                f"💰 Yangi balans: <b>{new_balance} Stars</b>",
                parse_mode="HTML",
            )
        except (ValueError, IndexError):
            pass
