"""
bot/handlers/accounts.py
=========================
Telegram akkauntlarini ulash, boshqarish va o'chirish.
FSM orqali: Telefon → SMS kod → 2FA parol → Yakunlash.
"""

from __future__ import annotations

import os
import asyncio
from typing import Optional

from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message
from pyrogram import Client
from pyrogram.errors import (
    PhoneNumberInvalid, PhoneCodeInvalid, PhoneCodeExpired,
    SessionPasswordNeeded, BadRequest, FloodWait,
)
from loguru import logger

from bot.keyboards.inline import (
    accounts_list_kb, account_detail_kb, account_settings_kb,
    confirm_delete_kb, back_kb,
)
from config.settings import settings
from database.crud import (
    get_user_accounts, get_account, create_account, delete_account,
    count_user_accounts, update_account_session, update_account_settings,
)
from database.models import User
from database.session import AsyncSessionFactory
from services.ai_service import AIService
from userbot.manager import userbot_manager

router = Router()

MAX_ACCOUNTS = 3


# ── FSM States ───────────────────────────────────────────────────────────────

class AddAccountFSM(StatesGroup):
    waiting_phone    = State()
    waiting_sms_code = State()
    waiting_2fa      = State()


class SetPersonaFSM(StatesGroup):
    waiting_persona  = State()


class SetPromptFSM(StatesGroup):
    waiting_prompt   = State()


class SetTriggersFSM(StatesGroup):
    waiting_triggers = State()


class SetProxyFSM(StatesGroup):
    waiting_proxy    = State()


# ── Pyrogram temp clients (keyin o'chiriladi) ───────────────────────────────
_pending_clients: dict[int, Client] = {}
_pending_phone: dict[int, str] = {}
_pending_phone_hash: dict[int, str] = {}


# ── Akkauntlar ro'yxati ──────────────────────────────────────────────────────

@router.callback_query(F.data == "accounts")
async def cb_accounts(call: CallbackQuery, db_user: User) -> None:
    async with AsyncSessionFactory() as session:
        accounts = await get_user_accounts(session, db_user.id)

    if not accounts:
        from aiogram.utils.keyboard import InlineKeyboardBuilder
        from aiogram.types import InlineKeyboardButton
        builder = InlineKeyboardBuilder()
        builder.row(InlineKeyboardButton(text="➕ Akkaunt ulash", callback_data="acc_add"))
        builder.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="main_menu"))
        await call.message.edit_text(
            "📱 <b>Ulangan akkauntlar yo'q</b>\n\nBirinchi akkauntingizni ulang:",
            reply_markup=builder.as_markup(),
            parse_mode="HTML",
        )
    else:
        await call.message.edit_text(
            f"📱 <b>Ulangan akkauntlar</b> ({len(accounts)}/{MAX_ACCOUNTS}):",
            reply_markup=accounts_list_kb(accounts),
            parse_mode="HTML",
        )
    await call.answer()


@router.callback_query(F.data.startswith("acc_view:"))
async def cb_account_view(call: CallbackQuery) -> None:
    account_id = int(call.data.split(":")[1])
    async with AsyncSessionFactory() as session:
        acc = await get_account(session, account_id)

    if not acc:
        await call.answer("Akkaunt topilmadi!", show_alert=True)
        return

    status_map = {
        "active": "🟢 Faol", "sleeping": "🌙 Uxlayapti",
        "banned": "🔴 Bloklangan", "disabled": "⚫ O'chirilgan",
    }
    status_text = status_map.get(acc.status.value, acc.status.value)

    text = (
        f"📱 <b>Akkaunt ma'lumotlari</b>\n\n"
        f"📞 Telefon: <code>{acc.phone_number}</code>\n"
        f"🔵 Holati: {status_text}\n"
        f"🎭 Personaj: {acc.persona_name or '—'}\n"
        f"🔑 Triggerlar: {acc.trigger_keywords or '—'}\n"
        f"🌐 Proxy: {'✅' if acc.proxy_url else '❌'}\n"
        f"📨 Yuborilgan xabarlar: {acc.total_messages_sent}\n"
        f"🤖 Avto-javob: {'✅' if acc.is_auto_reply else '❌'}"
    )

    await call.message.edit_text(
        text, reply_markup=account_detail_kb(account_id), parse_mode="HTML"
    )
    await call.answer()


# ── Yangi akkaunt qo'shish (FSM) ─────────────────────────────────────────────

@router.callback_query(F.data == "acc_add")
async def cb_acc_add(call: CallbackQuery, state: FSMContext, db_user: User) -> None:
    async with AsyncSessionFactory() as session:
        count = await count_user_accounts(session, db_user.id)

    if count >= MAX_ACCOUNTS:
        await call.answer(
            f"❌ Maksimal {MAX_ACCOUNTS} ta akkaunt ulanishi mumkin!",
            show_alert=True,
        )
        return

    await state.set_state(AddAccountFSM.waiting_phone)
    await call.message.edit_text(
        "📞 <b>Telefon raqamingizni kiriting</b>\n\n"
        "Format: <code>+998901234567</code>\n\n"
        "❌ Bekor qilish: /cancel",
        parse_mode="HTML",
    )
    await call.answer()


@router.message(AddAccountFSM.waiting_phone)
async def fsm_phone(message: Message, state: FSMContext, db_user: User) -> None:
    phone = message.text.strip().replace(" ", "")

    if not phone.startswith("+"):
        await message.answer("❌ Telefon raqam xalqaro formatda bo'lishi kerak: +998901234567")
        return

    # Telegram Pyrogram client yaratish
    session_name = f"sessions/pending_{db_user.id}"
    client = Client(
        name=session_name,
        api_id=6,
        api_hash="eb06d4abfb49dc3eeb1aeb98ae0f581e",
        no_updates=True,
    )

    try:
        await client.connect()
        sent = await client.send_code(phone)
        _pending_clients[db_user.id] = client
        _pending_phone[db_user.id] = phone
        _pending_phone_hash[db_user.id] = sent.phone_code_hash

        await state.set_state(AddAccountFSM.waiting_sms_code)
        await state.update_data(phone=phone)
        await message.answer(
            f"📲 <b>SMS kod yuborildi</b>\n\n"
            f"<code>{phone}</code> raqamiga kelgan kodni kiriting:\n\n"
            f"❌ Bekor qilish: /cancel",
            parse_mode="HTML",
        )
    except PhoneNumberInvalid:
        await client.disconnect()
        await message.answer("❌ Telefon raqam noto'g'ri. Qayta urinib ko'ring:")
    except FloodWait as e:
        await client.disconnect()
        await message.answer(f"⏳ Juda ko'p urinish. {e.value} soniya kuting.")
    except Exception as e:
        await client.disconnect()
        logger.error(f"SMS yuborishda xato: {e}")
        await message.answer("❌ Xato yuz berdi. Qayta urinib ko'ring.")


@router.message(AddAccountFSM.waiting_sms_code)
async def fsm_sms_code(message: Message, state: FSMContext, db_user: User) -> None:
    code = message.text.strip().replace(" ", "").replace("-", "")
    client = _pending_clients.get(db_user.id)
    phone = _pending_phone.get(db_user.id)
    phone_hash = _pending_phone_hash.get(db_user.id)

    if not client or not phone or not phone_hash:
        await state.clear()
        await message.answer("❌ Sessiya topilmadi. Qaytadan boshlang: /start")
        return

    try:
        user = await client.sign_in(phone, phone_hash, code)
        await _finalize_account(message, state, db_user, client, phone, user.id)

    except SessionPasswordNeeded:
        await state.set_state(AddAccountFSM.waiting_2fa)
        await message.answer(
            "🔐 <b>Ikki bosqichli himoya (2FA) yoqilgan</b>\n\n"
            "Parolingizni kiriting:\n\n❌ Bekor qilish: /cancel",
            parse_mode="HTML",
        )
    except PhoneCodeInvalid:
        await message.answer("❌ Kod noto'g'ri. Qayta kiriting:")
    except PhoneCodeExpired:
        await _cleanup_pending(db_user.id)
        await state.clear()
        await message.answer("❌ Kod muddati tugadi. Qaytadan boshlang.")
    except Exception as e:
        logger.error(f"Sign-in xatosi: {e}")
        await message.answer("❌ Xato. Qayta urinib ko'ring.")


@router.message(AddAccountFSM.waiting_2fa)
async def fsm_2fa(message: Message, state: FSMContext, db_user: User) -> None:
    password = message.text.strip()
    client = _pending_clients.get(db_user.id)
    phone = _pending_phone.get(db_user.id)

    if not client or not phone:
        await state.clear()
        await message.answer("❌ Sessiya topilmadi. Qaytadan boshlang: /start")
        return

    try:
        user = await client.check_password(password)
        await _finalize_account(message, state, db_user, client, phone, user.id)
    except BadRequest:
        await message.answer("❌ Parol noto'g'ri. Qayta kiriting:")
    except Exception as e:
        logger.error(f"2FA xatosi: {e}")
        await message.answer("❌ Xato yuz berdi.")


async def _finalize_account(
    message: Message,
    state: FSMContext,
    db_user: User,
    client: Client,
    phone: str,
    tg_user_id: int,
) -> None:
    """Muvaffaqiyatli autentifikatsiyadan keyin akkauntni saqlash."""
    session_file = f"acc_{db_user.id}_{phone.replace('+', '')}"

    # Session faylni to'g'ri joyga saqlash
    await client.export_session_string()
    await client.disconnect()

    # Pending client tozalash
    _cleanup_pending(db_user.id)

    # Pending fayl nomini qayta nomlash
    pending_path = f"sessions/pending_{db_user.id}.session"
    final_path = f"sessions/{session_file}.session"
    if os.path.exists(pending_path):
        os.rename(pending_path, final_path)

    async with AsyncSessionFactory() as session:
        acc = await create_account(
            session=session,
            user_id=db_user.id,
            phone_number=phone,
            tg_user_id=tg_user_id,
            session_file=session_file,
        )
        await session.commit()
        account_id = acc.id

    # Userbotni ishga tushirish
    await userbot_manager.start_account(account_id)

    await state.clear()
    await message.answer(
        f"✅ <b>Akkaunt muvaffaqiyatli ulandi!</b>\n\n"
        f"📞 Telefon: <code>{phone}</code>\n\n"
        f"Endi personaj va vazifani sozlang:",
        reply_markup=account_detail_kb(account_id),
        parse_mode="HTML",
    )


def _cleanup_pending(user_id: int) -> None:
    _pending_clients.pop(user_id, None)
    _pending_phone.pop(user_id, None)
    _pending_phone_hash.pop(user_id, None)


# ── Akkaunt o'chirish ────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("acc_delete:"))
async def cb_acc_delete(call: CallbackQuery) -> None:
    account_id = int(call.data.split(":")[1])
    async with AsyncSessionFactory() as session:
        acc = await get_account(session, account_id)
    if not acc:
        await call.answer("Topilmadi!", show_alert=True)
        return

    await call.message.edit_text(
        f"⚠️ <b>{acc.phone_number}</b> akkauntini o'chirishni tasdiqlaysizmi?\n\n"
        "Bu amalni qaytarib bo'lmaydi!",
        reply_markup=confirm_delete_kb(account_id),
        parse_mode="HTML",
    )
    await call.answer()


@router.callback_query(F.data.startswith("acc_delete_confirm:"))
async def cb_acc_delete_confirm(call: CallbackQuery, db_user: User) -> None:
    account_id = int(call.data.split(":")[1])

    # Userbotni to'xtatish
    await userbot_manager.stop_account(account_id)

    async with AsyncSessionFactory() as session:
        acc = await get_account(session, account_id)
        if acc and acc.session_file:
            session_path = f"sessions/{acc.session_file}.session"
            if os.path.exists(session_path):
                os.remove(session_path)
        await delete_account(session, account_id)
        await session.commit()

    await call.message.edit_text(
        "✅ Akkaunt o'chirildi.",
        reply_markup=back_kb("accounts"),
    )
    await call.answer()


# ── Akkaunt sozlamalari ──────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("acc_settings:"))
async def cb_acc_settings(call: CallbackQuery) -> None:
    account_id = int(call.data.split(":")[1])
    await call.message.edit_text(
        "⚙️ <b>Akkaunt sozlamalari</b>\n\nNimani sozlamoqchisiz?",
        reply_markup=account_settings_kb(account_id),
        parse_mode="HTML",
    )
    await call.answer()


# Personaj
@router.callback_query(F.data.startswith("acc_set_persona:"))
async def cb_set_persona(call: CallbackQuery, state: FSMContext) -> None:
    account_id = int(call.data.split(":")[1])
    await state.set_state(SetPersonaFSM.waiting_persona)
    await state.update_data(account_id=account_id)
    await call.message.edit_text(
        "🎭 <b>Personaj nomini kiriting</b>\n\nMasalan: <code>Aziz savdogar</code>",
        parse_mode="HTML",
    )
    await call.answer()


@router.message(SetPersonaFSM.waiting_persona)
async def fsm_set_persona(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    account_id = data["account_id"]
    async with AsyncSessionFactory() as session:
        await update_account_settings(session, account_id, persona_name=message.text.strip())
        await session.commit()
    await state.clear()
    await message.answer(
        "✅ Personaj saqlandi!",
        reply_markup=account_detail_kb(account_id),
    )


# Prompt
@router.callback_query(F.data.startswith("acc_set_prompt:"))
async def cb_set_prompt(call: CallbackQuery, state: FSMContext) -> None:
    account_id = int(call.data.split(":")[1])
    await state.set_state(SetPromptFSM.waiting_prompt)
    await state.update_data(account_id=account_id)
    await call.message.edit_text(
        "📝 <b>AI Vazifasini (System Prompt) kiriting</b>\n\n"
        "Masalan:\n<i>Sen fashion do'koni menejeri. Narxlar haqida ma'lumot ber va buyurtma qabul qil.</i>",
        parse_mode="HTML",
    )
    await call.answer()


@router.message(SetPromptFSM.waiting_prompt)
async def fsm_set_prompt(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    account_id = data["account_id"]
    async with AsyncSessionFactory() as session:
        await update_account_settings(session, account_id, system_prompt=message.text.strip())
        await session.commit()
    await state.clear()
    await message.answer("✅ Prompt saqlandi!", reply_markup=account_detail_kb(account_id))


# Triggerlar
@router.callback_query(F.data.startswith("acc_set_triggers:"))
async def cb_set_triggers(call: CallbackQuery, state: FSMContext) -> None:
    account_id = int(call.data.split(":")[1])
    await state.set_state(SetTriggersFSM.waiting_triggers)
    await state.update_data(account_id=account_id)
    await call.message.edit_text(
        "🔑 <b>Trigger so'zlarni kiriting</b>\n\n"
        "Vergul bilan ajrating:\n<code>narx,price,sotib ol,xarid</code>\n\n"
        "Bo'sh qoldirish uchun: <code>-</code>",
        parse_mode="HTML",
    )
    await call.answer()


@router.message(SetTriggersFSM.waiting_triggers)
async def fsm_set_triggers(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    account_id = data["account_id"]
    text = message.text.strip()
    keywords = None if text == "-" else text
    async with AsyncSessionFactory() as session:
        await update_account_settings(session, account_id, trigger_keywords=keywords)
        await session.commit()
    await state.clear()
    await message.answer("✅ Triggerlar saqlandi!", reply_markup=account_detail_kb(account_id))


# Proxy
@router.callback_query(F.data.startswith("acc_set_proxy:"))
async def cb_set_proxy(call: CallbackQuery, state: FSMContext) -> None:
    account_id = int(call.data.split(":")[1])
    await state.set_state(SetProxyFSM.waiting_proxy)
    await state.update_data(account_id=account_id)
    await call.message.edit_text(
        "🌐 <b>Proxy manzilini kiriting</b>\n\n"
        "Format: <code>socks5://user:pass@host:1080</code>\n"
        "yoki: <code>http://host:8080</code>\n\n"
        "O'chirish uchun: <code>-</code>",
        parse_mode="HTML",
    )
    await call.answer()


@router.message(SetProxyFSM.waiting_proxy)
async def fsm_set_proxy(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    account_id = data["account_id"]
    text = message.text.strip()
    proxy = None if text == "-" else text
    async with AsyncSessionFactory() as session:
        await update_account_settings(session, account_id, proxy_url=proxy)
        await session.commit()
    # Userbotni qayta ishga tushirish (yangi proxy bilan)
    await userbot_manager.restart_account(account_id)
    await state.clear()
    await message.answer("✅ Proxy saqlandi!", reply_markup=account_detail_kb(account_id))


# Tarix tozalash
@router.callback_query(F.data.startswith("acc_clear_history:"))
async def cb_clear_history(call: CallbackQuery) -> None:
    account_id = int(call.data.split(":")[1])
    async with AsyncSessionFactory() as session:
        ai = AIService(session)
        # Akkauntga tegishli barcha chatlar tarixini tozalash
        from sqlalchemy import delete
        from database.models import ChatHistory
        result = await session.execute(
            delete(ChatHistory).where(ChatHistory.account_id == account_id)
        )
        count = result.rowcount
        await session.commit()

    await call.answer(f"✅ {count} ta xabar tarixi o'chirildi!", show_alert=True)


# /cancel
@router.message(F.text == "/cancel")
async def cmd_cancel(message: Message, state: FSMContext) -> None:
    current = await state.get_state()
    if current:
        await state.clear()
        # Pending clientni tozalash
        _cleanup_pending(message.from_user.id)
        await message.answer("❌ Amal bekor qilindi.", reply_markup=back_kb("main_menu"))
    else:
        await message.answer("Hech qanday faol amal yo'q.")
