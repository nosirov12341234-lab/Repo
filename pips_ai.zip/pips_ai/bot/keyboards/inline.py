"""
bot/keyboards/inline.py
========================
Barcha InlineKeyboardMarkup lar.
"""

from __future__ import annotations

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database.models import LinkedAccount


def main_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="👤 Profilim", callback_data="profile"),
        InlineKeyboardButton(text="📱 Akkauntlar", callback_data="accounts"),
    )
    builder.row(
        InlineKeyboardButton(text="⭐ Stars To'ldirish", callback_data="buy_stars"),
    )
    return builder.as_markup()


def profile_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="⭐ Stars To'ldirish", callback_data="buy_stars"))
    builder.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="main_menu"))
    return builder.as_markup()


def accounts_list_kb(accounts: list[LinkedAccount]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for acc in accounts:
        status_icon = {"active": "🟢", "sleeping": "🌙", "banned": "🔴", "disabled": "⚫"}.get(
            acc.status.value, "⚪"
        )
        label = f"{status_icon} {acc.phone_number}"
        if acc.persona_name:
            label += f" — {acc.persona_name}"
        builder.row(
            InlineKeyboardButton(
                text=label,
                callback_data=f"acc_view:{acc.id}",
            )
        )
    builder.row(InlineKeyboardButton(text="➕ Yangi akkaunt ulash", callback_data="acc_add"))
    builder.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="main_menu"))
    return builder.as_markup()


def account_detail_kb(account_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="⚙️ Sozlamalar", callback_data=f"acc_settings:{account_id}"),
        InlineKeyboardButton(text="🗑 O'chirish", callback_data=f"acc_delete:{account_id}"),
    )
    builder.row(
        InlineKeyboardButton(text="🧹 Tarixni tozalash", callback_data=f"acc_clear_history:{account_id}"),
    )
    builder.row(InlineKeyboardButton(text="🔙 Akkauntlar", callback_data="accounts"))
    return builder.as_markup()


def account_settings_kb(account_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🎭 Personaj", callback_data=f"acc_set_persona:{account_id}"),
    )
    builder.row(
        InlineKeyboardButton(text="📝 Vazifa (Prompt)", callback_data=f"acc_set_prompt:{account_id}"),
    )
    builder.row(
        InlineKeyboardButton(text="🔑 Trigger so'zlar", callback_data=f"acc_set_triggers:{account_id}"),
    )
    builder.row(
        InlineKeyboardButton(text="🌐 Proxy sozlash", callback_data=f"acc_set_proxy:{account_id}"),
    )
    builder.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data=f"acc_view:{account_id}"))
    return builder.as_markup()


def confirm_delete_kb(account_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Ha, o'chirish", callback_data=f"acc_delete_confirm:{account_id}"),
        InlineKeyboardButton(text="❌ Bekor qilish", callback_data=f"acc_view:{account_id}"),
    )
    return builder.as_markup()


def back_kb(callback: str = "main_menu") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="🔙 Orqaga", callback_data=callback)]]
    )


def check_sub_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[
            InlineKeyboardButton(text="✅ A'zo bo'ldim", callback_data="check_subscription")
        ]]
    )


# ── Admin keyboards ─────────────────────────────────────────────────────────

def admin_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📊 Statistika", callback_data="admin_stats"),
        InlineKeyboardButton(text="📢 Kanallar", callback_data="admin_channels"),
    )
    builder.row(
        InlineKeyboardButton(text="🔑 Gemini Kalitlar", callback_data="admin_keys"),
        InlineKeyboardButton(text="💰 Stars Narxi", callback_data="admin_stars_price"),
    )
    builder.row(
        InlineKeyboardButton(text="📣 Broadcast", callback_data="admin_broadcast"),
    )
    return builder.as_markup()


def admin_keys_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="➕ Kalitlar qo'shish", callback_data="admin_keys_add"),
        InlineKeyboardButton(text="🗑 Invalidlarni tozalash", callback_data="admin_keys_clean"),
    )
    builder.row(
        InlineKeyboardButton(text="📊 Statistika", callback_data="admin_keys_stats"),
    )
    builder.row(InlineKeyboardButton(text="🔙 Admin panel", callback_data="admin_menu"))
    return builder.as_markup()


def admin_channels_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="➕ Kanal qo'shish", callback_data="admin_channel_add"),
        InlineKeyboardButton(text="📋 Ro'yxat", callback_data="admin_channel_list"),
    )
    builder.row(InlineKeyboardButton(text="🔙 Admin panel", callback_data="admin_menu"))
    return builder.as_markup()
