"""
bot/router.py
=============
Barcha handlerllarni bitta routerga birlashtirish.
"""

from aiogram import Router

from bot.handlers import start, profile, accounts, admin

main_router = Router()

main_router.include_router(start.router)
main_router.include_router(profile.router)
main_router.include_router(accounts.router)
main_router.include_router(admin.router)
