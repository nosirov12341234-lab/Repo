"""
services/subscription_service.py
=================================
Majburiy kanal obuna tekshiruvi.
"""

from __future__ import annotations

from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError, TelegramBadRequest
from sqlalchemy.ext.asyncio import AsyncSession

from database.crud import get_active_channels
from database.models import Channel


async def check_user_subscriptions(
    bot: Bot,
    session: AsyncSession,
    user_id: int,
) -> tuple[bool, list[Channel]]:
    """
    Foydalanuvchi barcha aktiv kanallarga a'zo ekanini tekshiradi.

    Returns:
        (all_subscribed, not_subscribed_channels)
    """
    channels = await get_active_channels(session)

    if not channels:
        return True, []

    not_subscribed: list[Channel] = []

    for channel in channels:
        try:
            member = await bot.get_chat_member(
                chat_id=channel.channel_id,
                user_id=user_id,
            )
            if member.status in ("left", "kicked", "restricted"):
                not_subscribed.append(channel)
        except (TelegramForbiddenError, TelegramBadRequest):
            # Bot kanalda admin emas yoki kanal topilmadi — o'tkazib yuborish
            pass

    return len(not_subscribed) == 0, not_subscribed
