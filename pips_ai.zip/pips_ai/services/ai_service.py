"""
services/ai_service.py
======================
Pips AI — Gemini API Key Pool + Round-Robin Rotatsiya + 429 Error Handling.

Xususiyatlar:
  - Redis yordamida global "current_key_index" saqlash (multi-process safe)
  - 429 xatolikda avtomatik keyingi kalitga o'tish
  - Blokdan chiqish vaqti (ratelimit_until) DB da saqlanadi
  - Thread-safe asyncio.Lock bilan himoyalangan rotatsiya
  - Context window (chat_history) qo'llab-quvvatlash
  - Human-in-the-loop ogohlantirish signal
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import AsyncGenerator, Optional

import google.generativeai as genai
from google.api_core.exceptions import ResourceExhausted, InvalidArgument
from sqlalchemy import select, update, func
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import GeminiKey, KeyStatus, ChatHistory, MessageRole

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Konstantalar
# ---------------------------------------------------------------------------

MODEL_NAME = "gemini-2.5-flash"

# 429 bo'lganda necha daqiqaga bloklansin
RATELIMIT_COOLDOWN_MINUTES = 60

# Bir suhbatda AI ga yuboriladigan maksimal tarix (token iqtisod qilish uchun)
MAX_HISTORY_PAIRS = 20

# AI javob berolmasa human-in-the-loop trigger bo'lsin
HUMAN_LOOP_PHRASES = [
    "bilmayman", "aniqlay olmadim", "tushunmadim",
    "i don't know", "unclear", "cannot determine",
]

# ---------------------------------------------------------------------------
# AIService
# ---------------------------------------------------------------------------

class AIService:
    """
    Gemini API Key Pool ni boshqaruvchi va Round-Robin rotatsiyani
    ta'minlovchi asosiy servis.

    Ishlatilishi:
        ai = AIService(db_session)
        result = await ai.chat(
            account_id=1,
            telegram_chat_id=123456,
            user_message="Salom, narx qancha?",
            system_prompt="Sen savdo yordamchisisiz..."
        )
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def chat(
        self,
        account_id: int,
        telegram_chat_id: int,
        user_message: str,
        system_prompt: Optional[str] = None,
    ) -> tuple[str, bool]:
        """
        Foydalanuvchi xabariga AI javob qaytaradi.

        Returns:
            (response_text, needs_human_attention)
            needs_human_attention=True bo'lsa, userbot egasiga ogohlantirish yuborilishi kerak
        """
        # Tarix yuklash
        history = await self._load_history(account_id, telegram_chat_id)

        # Yangi xabarni tarixga qo'shish (DB ga yozish)
        await self._save_message(
            account_id, telegram_chat_id, MessageRole.USER, user_message
        )

        # AI dan javob olish (Round-Robin + Retry)
        response_text = await self._generate_with_rotation(
            user_message=user_message,
            history=history,
            system_prompt=system_prompt,
        )

        # Javobni tarixga saqlash
        await self._save_message(
            account_id, telegram_chat_id, MessageRole.ASSISTANT, response_text
        )

        # Human-in-the-loop tekshiruvi
        needs_human = self._check_human_loop(response_text)

        return response_text, needs_human

    async def generate_post(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
    ) -> str:
        """
        Scheduled post uchun AI yordamida kontent yaratish.
        Tarix ishlatilmaydi.
        """
        result = await self._generate_with_rotation(
            user_message=prompt,
            history=[],
            system_prompt=system_prompt or "Sen professional kontent yozuvchisisiz.",
        )
        return result

    # ------------------------------------------------------------------
    # Key Rotation Core
    # ------------------------------------------------------------------

    async def _get_next_key(self) -> Optional[GeminiKey]:
        """
        Round-Robin algoritmi: bazadan keyingi ACTIVE kalitni oladi.
        Blok muddati o'tgan RATELIMIT kalitlarni avtomatik ACTIVE qiladi.
        """
        async with self._lock:
            now = datetime.now(timezone.utc)

            # 1) Muddati o'tgan RATELIMIT kalitlarni ACTIVE ga qaytarish
            await self._session.execute(
                update(GeminiKey)
                .where(
                    GeminiKey.status == KeyStatus.RATELIMIT,
                    GeminiKey.ratelimit_until <= now,
                )
                .values(status=KeyStatus.ACTIVE, ratelimit_until=None)
            )
            await self._session.flush()

            # 2) Eng kam ishlatilgan ACTIVE kalitni olish (fair Round-Robin)
            stmt = (
                select(GeminiKey)
                .where(GeminiKey.status == KeyStatus.ACTIVE)
                .order_by(GeminiKey.usage_count.asc(), GeminiKey.id.asc())
                .limit(1)
                .with_for_update(skip_locked=True)
            )
            result = await self._session.execute(stmt)
            key = result.scalar_one_or_none()

            if key is None:
                logger.critical(
                    "Hech qanday faol Gemini API kalit yo'q! "
                    "Admin panel orqali yangi kalitlar qo'shing."
                )
                return None

            # 3) usage_count ni oshirish
            key.usage_count += 1
            await self._session.flush()

            return key

    async def _mark_key_ratelimited(self, key_id: int) -> None:
        """429 xatolikda kalitni vaqtinchalik bloklash."""
        until = datetime.now(timezone.utc) + timedelta(
            minutes=RATELIMIT_COOLDOWN_MINUTES
        )
        await self._session.execute(
            update(GeminiKey)
            .where(GeminiKey.id == key_id)
            .values(
                status=KeyStatus.RATELIMIT,
                ratelimit_until=until,
            )
        )
        await self._session.flush()
        logger.warning(
            f"Gemini kalit #{key_id} rate-limited. "
            f"Blok tugashi: {until.isoformat()}"
        )

    async def _mark_key_invalid(self, key_id: int) -> None:
        """Noto'g'ri yoki o'chirilgan kalitni INVALID qilish."""
        await self._session.execute(
            update(GeminiKey)
            .where(GeminiKey.id == key_id)
            .values(status=KeyStatus.INVALID)
        )
        await self._session.flush()
        logger.error(f"Gemini kalit #{key_id} INVALID deb belgilandi.")

    # ------------------------------------------------------------------
    # Gemini SDK bilan muloqot
    # ------------------------------------------------------------------

    async def _generate_with_rotation(
        self,
        user_message: str,
        history: list[dict],
        system_prompt: Optional[str],
        max_retries: int = 5,
    ) -> str:
        """
        Round-Robin bilan kalitni aylantirib, Gemini dan javob oladi.
        429 xatolikda avtomatik keyingi kalitga o'tadi.
        """
        for attempt in range(max_retries):
            key = await self._get_next_key()

            if key is None:
                return (
                    "⚠️ Xizmat vaqtincha mavjud emas. "
                    "Iltimos, bir oz kutib qayta urinib ko'ring."
                )

            try:
                response_text = await self._call_gemini(
                    api_key=key.api_key,
                    user_message=user_message,
                    history=history,
                    system_prompt=system_prompt,
                )
                logger.debug(
                    f"Gemini javob olindi. Kalit #{key.id}, "
                    f"urinish {attempt + 1}/{max_retries}"
                )
                return response_text

            except ResourceExhausted:
                # 429 — Rate Limit
                logger.warning(
                    f"Gemini kalit #{key.id} 429 qaytardi. "
                    f"Keyingi kalitga o'tilmoqda... ({attempt + 1}/{max_retries})"
                )
                await self._mark_key_ratelimited(key.id)
                # Zudlik bilan keyingi kalitga o'tish (delay yo'q)
                continue

            except InvalidArgument as exc:
                # Noto'g'ri API kalit yoki request
                logger.error(f"Gemini kalit #{key.id} noto'g'ri: {exc}")
                await self._mark_key_invalid(key.id)
                continue

            except Exception as exc:
                logger.exception(
                    f"Gemini da kutilmagan xato (kalit #{key.id}): {exc}"
                )
                # Boshqa xatolarda ham keyingi kalitga o'tish
                await self._session.rollback()
                continue

        # Barcha urinishlar muvaffaqiyatsiz
        logger.critical(
            f"Gemini dan {max_retries} urinishdan keyin ham javob olinmadi!"
        )
        return (
            "⚠️ AI xizmati hozirda band. "
            "Keyinroq urinib ko'ring."
        )

    @staticmethod
    async def _call_gemini(
        api_key: str,
        user_message: str,
        history: list[dict],
        system_prompt: Optional[str],
    ) -> str:
        """
        Google GenAI SDK orqali Gemini ga so'rov yuboradi.
        Bloklashni oldini olish uchun to_thread da ishlatiladi.
        """
        def _sync_call() -> str:
            genai.configure(api_key=api_key)

            generation_config = genai.types.GenerationConfig(
                temperature=0.85,
                top_p=0.95,
                max_output_tokens=2048,
            )

            safety_settings = [
                {
                    "category": "HARM_CATEGORY_HARASSMENT",
                    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
                },
                {
                    "category": "HARM_CATEGORY_HATE_SPEECH",
                    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
                },
                {
                    "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
                },
                {
                    "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
                    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
                },
            ]

            model = genai.GenerativeModel(
                model_name=MODEL_NAME,
                system_instruction=system_prompt or (
                    "Sen foydali, samimiy va aqlli Telegram yordamchisisiz. "
                    "O'zbek tilida tabiiy, qisqa va aniq javob ber."
                ),
                generation_config=generation_config,
                safety_settings=safety_settings,
            )

            # Tarixni Gemini formatiga o'girish
            gemini_history = [
                {
                    "role": msg["role"],           # "user" | "model"
                    "parts": [{"text": msg["content"]}],
                }
                for msg in history
            ]

            chat = model.start_chat(history=gemini_history)
            response = chat.send_message(user_message)

            # Javob matnini olish
            if response.parts:
                return response.text
            else:
                # Safety filter yoki bo'sh javob
                return "Iltimos, savolingizni boshqacha tarzda yozing."

        # asyncio event loop ni bloklamamaslik uchun
        return await asyncio.get_event_loop().run_in_executor(None, _sync_call)

    # ------------------------------------------------------------------
    # Tarix boshqaruvi
    # ------------------------------------------------------------------

    async def _load_history(
        self,
        account_id: int,
        telegram_chat_id: int,
    ) -> list[dict]:
        """
        Berilgan akkaunt + chat uchun oxirgi N ta xabar juftini yuklaydi.
        Gemini format: role "user" | "model"
        """
        limit = MAX_HISTORY_PAIRS * 2  # har bir pair: user + assistant

        stmt = (
            select(ChatHistory)
            .where(
                ChatHistory.account_id == account_id,
                ChatHistory.telegram_chat_id == telegram_chat_id,
            )
            .order_by(ChatHistory.created_at.desc())
            .limit(limit)
        )
        result = await self._session.execute(stmt)
        rows = result.scalars().all()

        # Vaqt tartibida (eski → yangi) qaytarish
        rows_sorted = sorted(rows, key=lambda r: r.created_at)

        history = []
        for row in rows_sorted:
            # SQLAlchemy MessageRole → Gemini role
            gemini_role = "user" if row.role == MessageRole.USER else "model"
            history.append({
                "role": gemini_role,
                "content": row.content,
            })

        return history

    async def _save_message(
        self,
        account_id: int,
        telegram_chat_id: int,
        role: MessageRole,
        content: str,
        input_tokens: Optional[int] = None,
        output_tokens: Optional[int] = None,
    ) -> None:
        """Chat tarixiga yangi xabar saqlaydi."""
        msg = ChatHistory(
            account_id=account_id,
            telegram_chat_id=telegram_chat_id,
            role=role,
            content=content,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        )
        self._session.add(msg)
        await self._session.flush()

    async def clear_history(
        self,
        account_id: int,
        telegram_chat_id: int,
    ) -> int:
        """
        Berilgan akkaunt + chat tarixini tozalaydi.
        O'chirilgan xabarlar sonini qaytaradi.
        """
        from sqlalchemy import delete

        stmt = (
            select(func.count(ChatHistory.id))
            .where(
                ChatHistory.account_id == account_id,
                ChatHistory.telegram_chat_id == telegram_chat_id,
            )
        )
        count_result = await self._session.execute(stmt)
        count = count_result.scalar_one()

        del_stmt = (
            ChatHistory.__table__.delete()
            .where(
                ChatHistory.account_id == account_id,
                ChatHistory.telegram_chat_id == telegram_chat_id,
            )
        )
        await self._session.execute(del_stmt)
        await self._session.flush()

        logger.info(
            f"Tarix tozalandi: account={account_id}, "
            f"chat={telegram_chat_id}, o'chirildi={count}"
        )
        return count

    # ------------------------------------------------------------------
    # Yordamchi metodlar
    # ------------------------------------------------------------------

    @staticmethod
    def _check_human_loop(response_text: str) -> bool:
        """
        AI javobida noaniqlik belgilari bo'lsa True qaytaradi.
        Bu holda userbot egasiga ogohlantirish yuborilishi kerak.
        """
        lower = response_text.lower()
        return any(phrase in lower for phrase in HUMAN_LOOP_PHRASES)

    # ------------------------------------------------------------------
    # Admin yordamchi metodlar
    # ------------------------------------------------------------------

    async def add_keys_bulk(self, keys: list[str], added_by: int) -> dict[str, int]:
        """
        Admin panel uchun: kalitlarni ommaviy yuklash.

        Returns:
            {"added": N, "duplicates": M}
        """
        added = 0
        duplicates = 0

        for raw_key in keys:
            key_str = raw_key.strip()
            if not key_str:
                continue

            # Mavjudligini tekshirish
            exists = await self._session.execute(
                select(GeminiKey.id).where(GeminiKey.api_key == key_str)
            )
            if exists.scalar_one_or_none() is not None:
                duplicates += 1
                continue

            new_key = GeminiKey(
                api_key=key_str,
                status=KeyStatus.ACTIVE,
                added_by=added_by,
            )
            self._session.add(new_key)
            added += 1

        await self._session.flush()
        logger.info(f"Bulk key upload: {added} qo'shildi, {duplicates} takror.")
        return {"added": added, "duplicates": duplicates}

    async def remove_invalid_keys(self) -> int:
        """INVALID statusdagi kalitlarni bazadan o'chiradi."""
        from sqlalchemy import delete as sa_delete

        stmt = select(func.count(GeminiKey.id)).where(
            GeminiKey.status == KeyStatus.INVALID
        )
        count = (await self._session.execute(stmt)).scalar_one()

        del_stmt = GeminiKey.__table__.delete().where(
            GeminiKey.status == KeyStatus.INVALID
        )
        await self._session.execute(del_stmt)
        await self._session.flush()

        logger.info(f"{count} ta INVALID kalit o'chirildi.")
        return count

    async def get_keys_stats(self) -> dict[str, int]:
        """Admin panel uchun kalit statistikasi."""
        now = datetime.now(timezone.utc)

        active_count = (
            await self._session.execute(
                select(func.count(GeminiKey.id)).where(
                    GeminiKey.status == KeyStatus.ACTIVE
                )
            )
        ).scalar_one()

        ratelimit_count = (
            await self._session.execute(
                select(func.count(GeminiKey.id)).where(
                    GeminiKey.status == KeyStatus.RATELIMIT,
                    GeminiKey.ratelimit_until > now,
                )
            )
        ).scalar_one()

        invalid_count = (
            await self._session.execute(
                select(func.count(GeminiKey.id)).where(
                    GeminiKey.status == KeyStatus.INVALID
                )
            )
        ).scalar_one()

        total_usage = (
            await self._session.execute(
                select(func.sum(GeminiKey.usage_count))
            )
        ).scalar_one() or 0

        return {
            "active": active_count,
            "ratelimited": ratelimit_count,
            "invalid": invalid_count,
            "total_usage": total_usage,
        }
