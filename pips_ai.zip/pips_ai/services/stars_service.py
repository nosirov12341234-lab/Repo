"""
services/stars_service.py
==========================
Telegram Stars kunlik to'lov logikasi.
"""

from __future__ import annotations

from datetime import datetime, timezone, timedelta
from sqlalchemy.ext.asyncio import AsyncSession

from database.crud import get_user, mark_daily_payment, update_stars_balance, get_setting


async def get_daily_price(session: AsyncSession) -> int:
    """Admin tomonidan belgilangan kunlik narxni qaytaradi. 0 = bepul."""
    val = await get_setting(session, "daily_stars_price", "0")
    try:
        return int(val)
    except ValueError:
        return 0


async def check_daily_access(
    session: AsyncSession, user_id: int
) -> tuple[bool, int]:
    """
    Foydalanuvchi bugun uchun to'lagan yoki bepul rejimda ekanini tekshiradi.

    Returns:
        (has_access, required_stars)
        has_access=True bo'lsa foydalanuvchi davom etishi mumkin.
    """
    price = await get_daily_price(session)

    if price == 0:
        return True, 0

    user = await get_user(session, user_id)
    if not user:
        return False, price

    # Bugun allaqachon to'laganmi?
    if user.last_paid_at:
        today_start = datetime.now(timezone.utc).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        if user.last_paid_at >= today_start:
            return True, price

    # Balansi yetarlimi?
    if user.stars_balance >= price:
        return True, price

    return False, price


async def deduct_daily_payment(
    session: AsyncSession, user_id: int
) -> bool:
    """
    Kunlik to'lovni amalga oshiradi.
    Muvaffaqiyatli bo'lsa True qaytaradi.
    """
    price = await get_daily_price(session)
    if price == 0:
        return True

    user = await get_user(session, user_id)
    if not user or user.stars_balance < price:
        return False

    await update_stars_balance(session, user_id, -price)
    await mark_daily_payment(session, user_id)
    return True
